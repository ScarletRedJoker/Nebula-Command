--
-- PostgreSQL database cluster dump
--

\restrict ZrYQdolYI2udnJ303nVcxzyj4QmbtIMKq3fKemefrB9NiumA1vFJfm9aYIOLFPp

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE dashboard;
ALTER ROLE dashboard WITH NOSUPERUSER INHERIT NOCREATEROLE NOCREATEDB LOGIN NOREPLICATION NOBYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:elRrP4LoncZHh5Km0NeXPQ==$5RnA6XiRubuMSa+hsq6xsFkB5IybeDhhXRTl5UKbaqA=:22ofP8D2ZZN+usZwzl8JAXqu7vcKyyvH7HpiURTb9eE=';
CREATE ROLE jarvis;
ALTER ROLE jarvis WITH NOSUPERUSER INHERIT NOCREATEROLE NOCREATEDB LOGIN NOREPLICATION NOBYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:oneR6H2ckr1+yIWSP7UKnw==$x2EUWP2i2hQIKZushxCr5jjayTO6MrbjVA5HNSQgTmo=:uxsjSk2a/v4z/L+I4N8H2n7gN2iMqVcR6tgkWaEIfyk=';
CREATE ROLE postgres;
ALTER ROLE postgres WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:Pf+5pJGiswE0frG45uA8Bw==$ILGwhjzXmoNFHK209ByWzV7ROCxkS6cWKbSAF9vXnL8=:pdK5BVsnIH4U/BiTLykh04KcOmRI+XzFTmIF52jPLQg=';
CREATE ROLE streambot;
ALTER ROLE streambot WITH NOSUPERUSER INHERIT NOCREATEROLE NOCREATEDB LOGIN NOREPLICATION NOBYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:5ai73x4X+1t/U6yFm03G7g==$GtvG3Bn9qsZ9c4gCx4xfVPYisOVl7MKNP8XH3wDoA3E=:VqlwkoNLziiH/cxmMaCwPtgYyy4o4nKWm0zXpsDMMRk=';
CREATE ROLE ticketbot;
ALTER ROLE ticketbot WITH NOSUPERUSER INHERIT NOCREATEROLE NOCREATEDB LOGIN NOREPLICATION NOBYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:opSBLWeizsKTPk754LwExw==$XUqY4qZ1BGCxUoR3yzFDeNeGbZqRkQKjWZfleuo57YQ=:oKKYa4qcPMxbN0sJOxLVHLw06eiBG6rNDbHjCDObnzw=';

--
-- User Configurations
--








\unrestrict ZrYQdolYI2udnJ303nVcxzyj4QmbtIMKq3fKemefrB9NiumA1vFJfm9aYIOLFPp

--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

\restrict 2dDzeDVys8vTjplHoWzSHAdomvMGeu0xNdyZBY1r4vxRTRdVnVbcJtWzzYHvBHJ

-- Dumped from database version 16.11
-- Dumped by pg_dump version 16.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict 2dDzeDVys8vTjplHoWzSHAdomvMGeu0xNdyZBY1r4vxRTRdVnVbcJtWzzYHvBHJ

--
-- Database "dashboard" dump
--

--
-- PostgreSQL database dump
--

\restrict EPURcNK2oHg8yJrVR0sfV6qDDZieLXvCnNgXvW4QyK1MsrU6UyBkEZjw358y4DR

-- Dumped from database version 16.11
-- Dumped by pg_dump version 16.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: dashboard; Type: DATABASE; Schema: -; Owner: dashboard
--

CREATE DATABASE dashboard WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE dashboard OWNER TO dashboard;

\unrestrict EPURcNK2oHg8yJrVR0sfV6qDDZieLXvCnNgXvW4QyK1MsrU6UyBkEZjw358y4DR
\connect dashboard
\restrict EPURcNK2oHg8yJrVR0sfV6qDDZieLXvCnNgXvW4QyK1MsrU6UyBkEZjw358y4DR

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict EPURcNK2oHg8yJrVR0sfV6qDDZieLXvCnNgXvW4QyK1MsrU6UyBkEZjw358y4DR

--
-- Database "homelab_jarvis" dump
--

--
-- PostgreSQL database dump
--

\restrict 6yh8bTkJockx51ml10ZVLC75TY3uMVcCGoYEzkCMAuj7FRtDNBDJRJgg0A7heL9

-- Dumped from database version 16.11
-- Dumped by pg_dump version 16.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: homelab_jarvis; Type: DATABASE; Schema: -; Owner: jarvis
--

CREATE DATABASE homelab_jarvis WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE homelab_jarvis OWNER TO jarvis;

\unrestrict 6yh8bTkJockx51ml10ZVLC75TY3uMVcCGoYEzkCMAuj7FRtDNBDJRJgg0A7heL9
\connect homelab_jarvis
\restrict 6yh8bTkJockx51ml10ZVLC75TY3uMVcCGoYEzkCMAuj7FRtDNBDJRJgg0A7heL9

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: analysisstatus; Type: TYPE; Schema: public; Owner: jarvis
--

CREATE TYPE public.analysisstatus AS ENUM (
    'pending',
    'analyzing',
    'complete',
    'failed'
);


ALTER TYPE public.analysisstatus OWNER TO jarvis;

--
-- Name: automationstatus; Type: TYPE; Schema: public; Owner: jarvis
--

CREATE TYPE public.automationstatus AS ENUM (
    'active',
    'inactive',
    'error'
);


ALTER TYPE public.automationstatus OWNER TO jarvis;

--
-- Name: backupstatus; Type: TYPE; Schema: public; Owner: jarvis
--

CREATE TYPE public.backupstatus AS ENUM (
    'pending',
    'uploading',
    'completed',
    'failed'
);


ALTER TYPE public.backupstatus OWNER TO jarvis;

--
-- Name: builderprojectstatus; Type: TYPE; Schema: public; Owner: jarvis
--

CREATE TYPE public.builderprojectstatus AS ENUM (
    'planning',
    'scaffolding',
    'building',
    'reviewing',
    'deploying',
    'complete',
    'failed',
    'paused'
);


ALTER TYPE public.builderprojectstatus OWNER TO jarvis;

--
-- Name: buildertechstack; Type: TYPE; Schema: public; Owner: jarvis
--

CREATE TYPE public.buildertechstack AS ENUM (
    'static_html',
    'flask',
    'fastapi',
    'express',
    'react',
    'vue',
    'nextjs'
);


ALTER TYPE public.buildertechstack OWNER TO jarvis;

--
-- Name: checkpointstatus; Type: TYPE; Schema: public; Owner: jarvis
--

CREATE TYPE public.checkpointstatus AS ENUM (
    'pending',
    'approved',
    'rejected'
);


ALTER TYPE public.checkpointstatus OWNER TO jarvis;

--
-- Name: deploymentstatus; Type: TYPE; Schema: public; Owner: jarvis
--

CREATE TYPE public.deploymentstatus AS ENUM (
    'deploying',
    'running',
    'stopped',
    'failed',
    'removed'
);


ALTER TYPE public.deploymentstatus OWNER TO jarvis;

--
-- Name: emailnotificationstatus; Type: TYPE; Schema: public; Owner: jarvis
--

CREATE TYPE public.emailnotificationstatus AS ENUM (
    'pending',
    'sent',
    'failed'
);


ALTER TYPE public.emailnotificationstatus OWNER TO jarvis;

--
-- Name: filetype; Type: TYPE; Schema: public; Owner: jarvis
--

CREATE TYPE public.filetype AS ENUM (
    'zip',
    'tar',
    'directory',
    'single_file'
);


ALTER TYPE public.filetype OWNER TO jarvis;

--
-- Name: healthstatus; Type: TYPE; Schema: public; Owner: jarvis
--

CREATE TYPE public.healthstatus AS ENUM (
    'healthy',
    'unhealthy',
    'unknown'
);


ALTER TYPE public.healthstatus OWNER TO jarvis;

--
-- Name: queuedeploymentstatus; Type: TYPE; Schema: public; Owner: jarvis
--

CREATE TYPE public.queuedeploymentstatus AS ENUM (
    'pending',
    'queued',
    'pulling_image',
    'creating_container',
    'configuring',
    'starting',
    'running',
    'completed',
    'failed',
    'rolling_back',
    'rolled_back',
    'cancelled'
);


ALTER TYPE public.queuedeploymentstatus OWNER TO jarvis;

--
-- Name: recordstatus; Type: TYPE; Schema: public; Owner: jarvis
--

CREATE TYPE public.recordstatus AS ENUM (
    'pending',
    'active',
    'failed',
    'removed'
);


ALTER TYPE public.recordstatus OWNER TO jarvis;

--
-- Name: recordtype; Type: TYPE; Schema: public; Owner: jarvis
--

CREATE TYPE public.recordtype AS ENUM (
    'A',
    'CNAME',
    'TXT',
    'MX',
    'AAAA'
);


ALTER TYPE public.recordtype OWNER TO jarvis;

--
-- Name: remediationstatus; Type: TYPE; Schema: public; Owner: jarvis
--

CREATE TYPE public.remediationstatus AS ENUM (
    'pending',
    'in_progress',
    'completed',
    'failed',
    'rolled_back',
    'skipped'
);


ALTER TYPE public.remediationstatus OWNER TO jarvis;

--
-- Name: serviceconnectionstatus; Type: TYPE; Schema: public; Owner: jarvis
--

CREATE TYPE public.serviceconnectionstatus AS ENUM (
    'connected',
    'disconnected',
    'error',
    'pending'
);


ALTER TYPE public.serviceconnectionstatus OWNER TO jarvis;

--
-- Name: subscriptionstatus; Type: TYPE; Schema: public; Owner: jarvis
--

CREATE TYPE public.subscriptionstatus AS ENUM (
    'active',
    'trialing',
    'past_due',
    'canceled',
    'expired'
);


ALTER TYPE public.subscriptionstatus OWNER TO jarvis;

--
-- Name: subscriptiontier; Type: TYPE; Schema: public; Owner: jarvis
--

CREATE TYPE public.subscriptiontier AS ENUM (
    'free',
    'pro',
    'team'
);


ALTER TYPE public.subscriptiontier OWNER TO jarvis;

--
-- Name: taskpriority; Type: TYPE; Schema: public; Owner: jarvis
--

CREATE TYPE public.taskpriority AS ENUM (
    'low',
    'medium',
    'high',
    'critical'
);


ALTER TYPE public.taskpriority OWNER TO jarvis;

--
-- Name: taskstatus; Type: TYPE; Schema: public; Owner: jarvis
--

CREATE TYPE public.taskstatus AS ENUM (
    'pending',
    'in_progress',
    'completed',
    'cancelled'
);


ALTER TYPE public.taskstatus OWNER TO jarvis;

--
-- Name: tasktype; Type: TYPE; Schema: public; Owner: jarvis
--

CREATE TYPE public.tasktype AS ENUM (
    'dns_manual',
    'approval_required',
    'verification'
);


ALTER TYPE public.tasktype OWNER TO jarvis;

--
-- Name: userrole; Type: TYPE; Schema: public; Owner: jarvis
--

CREATE TYPE public.userrole AS ENUM (
    'admin',
    'operator',
    'viewer'
);


ALTER TYPE public.userrole OWNER TO jarvis;

--
-- Name: workflowstatus; Type: TYPE; Schema: public; Owner: jarvis
--

CREATE TYPE public.workflowstatus AS ENUM (
    'pending',
    'running',
    'completed',
    'failed',
    'paused'
);


ALTER TYPE public.workflowstatus OWNER TO jarvis;

--
-- Name: update_marketplace_deployments_updated_at(); Type: FUNCTION; Schema: public; Owner: jarvis
--

CREATE FUNCTION public.update_marketplace_deployments_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
        BEGIN
            NEW.updated_at = NOW();
            RETURN NEW;
        END;
        $$;


ALTER FUNCTION public.update_marketplace_deployments_updated_at() OWNER TO jarvis;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: activity_logs; Type: TABLE; Schema: public; Owner: jarvis
--

CREATE TABLE public.activity_logs (
    id integer NOT NULL,
    user_id character varying(100),
    username character varying(100),
    session_id character varying(100),
    activity_type character varying(50) NOT NULL,
    action character varying(100) NOT NULL,
    resource_type character varying(50),
    resource_id character varying(255),
    resource_name character varying(255),
    description text,
    previous_state json,
    new_state json,
    ip_address character varying(45),
    user_agent character varying(500),
    duration_ms integer,
    success character varying(10) DEFAULT 'true'::character varying,
    "timestamp" timestamp without time zone DEFAULT now() NOT NULL,
    year_month character varying(7),
    metadata_json json
);


ALTER TABLE public.activity_logs OWNER TO jarvis;

--
-- Name: activity_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: jarvis
--

CREATE SEQUENCE public.activity_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.activity_logs_id_seq OWNER TO jarvis;

--
-- Name: activity_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jarvis
--

ALTER SEQUENCE public.activity_logs_id_seq OWNED BY public.activity_logs.id;


--
-- Name: agent_conversations; Type: TABLE; Schema: public; Owner: jarvis
--

CREATE TABLE public.agent_conversations (
    id integer NOT NULL,
    task_id integer NOT NULL,
    from_agent_id uuid NOT NULL,
    to_agent_id uuid NOT NULL,
    message text NOT NULL,
    message_type character varying(50) DEFAULT 'consultation'::character varying NOT NULL,
    "timestamp" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.agent_conversations OWNER TO jarvis;

--
-- Name: agent_conversations_id_seq; Type: SEQUENCE; Schema: public; Owner: jarvis
--

CREATE SEQUENCE public.agent_conversations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.agent_conversations_id_seq OWNER TO jarvis;

--
-- Name: agent_conversations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jarvis
--

ALTER SEQUENCE public.agent_conversations_id_seq OWNED BY public.agent_conversations.id;


--
-- Name: agent_messages; Type: TABLE; Schema: public; Owner: jarvis
--

CREATE TABLE public.agent_messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    from_agent_id uuid,
    to_agent_id uuid,
    message_type character varying(50) NOT NULL,
    content jsonb NOT NULL,
    priority integer DEFAULT 5 NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    response_to uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    processed_at timestamp with time zone
);


ALTER TABLE public.agent_messages OWNER TO jarvis;

--
-- Name: agent_tasks; Type: TABLE; Schema: public; Owner: jarvis
--

CREATE TABLE public.agent_tasks (
    id integer NOT NULL,
    task_type character varying(50) DEFAULT 'diagnose'::character varying NOT NULL,
    description text NOT NULL,
    priority integer DEFAULT 5 NOT NULL,
    status character varying(50) DEFAULT 'pending'::character varying NOT NULL,
    assigned_agent_id uuid,
    parent_task_id integer,
    context jsonb,
    result jsonb,
    execution_log jsonb,
    requires_collaboration boolean DEFAULT false NOT NULL,
    collaborating_agents jsonb,
    requires_approval boolean DEFAULT true NOT NULL,
    approved boolean DEFAULT false NOT NULL,
    approved_by character varying(100),
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    started_at timestamp without time zone,
    completed_at timestamp without time zone
);


ALTER TABLE public.agent_tasks OWNER TO jarvis;

--
-- Name: agent_tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: jarvis
--

CREATE SEQUENCE public.agent_tasks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.agent_tasks_id_seq OWNER TO jarvis;

--
-- Name: agent_tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jarvis
--

ALTER SEQUENCE public.agent_tasks_id_seq OWNED BY public.agent_tasks.id;


--
-- Name: agents; Type: TABLE; Schema: public; Owner: jarvis
--

CREATE TABLE public.agents (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(100) NOT NULL,
    agent_type character varying(50) NOT NULL,
    description text,
    status character varying(20) DEFAULT 'idle'::character varying NOT NULL,
    capabilities jsonb DEFAULT '[]'::jsonb NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    last_active timestamp with time zone,
    tasks_completed integer DEFAULT 0 NOT NULL,
    tasks_failed integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    system_prompt text,
    model character varying(50),
    current_task_id integer
);


ALTER TABLE public.agents OWNER TO jarvis;

--
-- Name: ai_sessions; Type: TABLE; Schema: public; Owner: jarvis
--

CREATE TABLE public.ai_sessions (
    id uuid NOT NULL,
    user_id character varying(100),
    session_type character varying(50) NOT NULL,
    state character varying(20) NOT NULL,
    current_step character varying(100),
    context jsonb,
    messages jsonb,
    intent character varying(100),
    target_project_id uuid,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    completed_at timestamp without time zone
);


ALTER TABLE public.ai_sessions OWNER TO jarvis;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: jarvis
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO jarvis;

--
-- Name: anomaly_baselines; Type: TABLE; Schema: public; Owner: jarvis
--

CREATE TABLE public.anomaly_baselines (
    id integer NOT NULL,
    service_name character varying(100) NOT NULL,
    metric_name character varying(100) NOT NULL,
    mean_value double precision NOT NULL,
    std_dev double precision NOT NULL,
    min_value double precision,
    max_value double precision,
    percentile_25 double precision,
    percentile_50 double precision,
    percentile_75 double precision,
    percentile_95 double precision,
    percentile_99 double precision,
    sample_count integer DEFAULT 0,
    last_sample_value double precision,
    anomaly_threshold_low double precision,
    anomaly_threshold_high double precision,
    sensitivity double precision DEFAULT '2'::double precision,
    time_window_hours integer DEFAULT 24,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    metadata_json json
);


ALTER TABLE public.anomaly_baselines OWNER TO jarvis;

--
-- Name: anomaly_baselines_id_seq; Type: SEQUENCE; Schema: public; Owner: jarvis
--

CREATE SEQUENCE public.anomaly_baselines_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.anomaly_baselines_id_seq OWNER TO jarvis;

--
-- Name: anomaly_baselines_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jarvis
--

ALTER SEQUENCE public.anomaly_baselines_id_seq OWNED BY public.anomaly_baselines.id;


--
-- Name: anomaly_events; Type: TABLE; Schema: public; Owner: jarvis
--

CREATE TABLE public.anomaly_events (
    id integer NOT NULL,
    service_name character varying(100) NOT NULL,
    metric_name character varying(100) NOT NULL,
    value double precision NOT NULL,
    baseline_mean double precision,
    baseline_std double precision,
    anomaly_score double precision NOT NULL,
    direction character varying(20),
    severity character varying(20) NOT NULL,
    is_acknowledged boolean DEFAULT false,
    acknowledged_by character varying(100),
    acknowledged_at timestamp without time zone,
    auto_remediated boolean DEFAULT false,
    remediation_id integer,
    "timestamp" timestamp without time zone DEFAULT now() NOT NULL,
    metadata_json json
);


ALTER TABLE public.anomaly_events OWNER TO jarvis;

--
-- Name: anomaly_events_id_seq; Type: SEQUENCE; Schema: public; Owner: jarvis
--

CREATE SEQUENCE public.anomaly_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.anomaly_events_id_seq OWNER TO jarvis;

--
-- Name: anomaly_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jarvis
--

ALTER SEQUENCE public.anomaly_events_id_seq OWNED BY public.anomaly_events.id;


--
-- Name: artifact_builds; Type: TABLE; Schema: public; Owner: jarvis
--

CREATE TABLE public.artifact_builds (
    id uuid NOT NULL,
    project_id uuid NOT NULL,
    workflow_id uuid,
    status character varying(20) NOT NULL,
    image_ref text,
    image_tag character varying(100),
    dockerfile_content text,
    build_logs text,
    build_duration_ms integer,
    image_size_bytes bigint,
    build_metadata jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    completed_at timestamp without time zone
);


ALTER TABLE public.artifact_builds OWNER TO jarvis;

--
-- Name: artifacts; Type: TABLE; Schema: public; Owner: jarvis
--

CREATE TABLE public.artifacts (
    id uuid NOT NULL,
    filename character varying(255) NOT NULL,
    original_filename character varying(255) NOT NULL,
    file_type public.filetype NOT NULL,
    storage_path character varying(512) NOT NULL,
    file_size bigint NOT NULL,
    checksum_sha256 character varying(64) NOT NULL,
    uploaded_by character varying(255) NOT NULL,
    uploaded_at timestamp with time zone DEFAULT now(),
    detected_service_type character varying(100),
    analysis_complete boolean NOT NULL,
    metadata json,
    analysis_status public.analysisstatus DEFAULT 'pending'::public.analysisstatus NOT NULL,
    analysis_result json,
    detected_framework character varying(100),
    requires_database boolean DEFAULT false NOT NULL
);


ALTER TABLE public.artifacts OWNER TO jarvis;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: jarvis
--

CREATE TABLE public.audit_logs (
    id integer NOT NULL,
    user_id character varying(100),
    username character varying(100),
    action character varying(100) NOT NULL,
    action_category character varying(50),
    target_type character varying(100),
    target_id character varying(255),
    target_name character varying(255),
    method character varying(10),
    endpoint character varying(500),
    request_data json,
    response_status integer,
    response_message text,
    ip_address character varying(45),
    user_agent character varying(500),
    duration_ms integer,
    success character varying(10) DEFAULT 'true'::character varying,
    error_message text,
    "timestamp" timestamp without time zone DEFAULT now() NOT NULL,
    metadata_json json
);


ALTER TABLE public.audit_logs OWNER TO jarvis;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: jarvis
--

CREATE SEQUENCE public.audit_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_logs_id_seq OWNER TO jarvis;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jarvis
--

ALTER SEQUENCE public.audit_logs_id_seq OWNED BY public.audit_logs.id;


--
-- Name: builder_checkpoints; Type: TABLE; Schema: public; Owner: jarvis
--

CREATE TABLE public.builder_checkpoints (
    id uuid NOT NULL,
    project_id uuid NOT NULL,
    stage character varying(50) NOT NULL,
    step_name character varying(100) NOT NULL,
    message text NOT NULL,
    context jsonb,
    preview_data jsonb,
    status public.checkpointstatus,
    user_response text,
    user_feedback text,
    responded_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.builder_checkpoints OWNER TO jarvis;

--
-- Name: builder_pages; Type: TABLE; Schema: public; Owner: jarvis
--

CREATE TABLE public.builder_pages (
    id uuid NOT NULL,
    project_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    path character varying(255) NOT NULL,
    page_type character varying(50),
    html_content text,
    css_content text,
    js_content text,
    component_code text,
    page_meta jsonb,
    is_generated boolean,
    generation_prompt text,
    generated_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.builder_pages OWNER TO jarvis;

--
-- Name: builder_projects; Type: TABLE; Schema: public; Owner: jarvis
--

CREATE TABLE public.builder_projects (
    id uuid NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    domain character varying(255),
    preview_domain character varying(255),
    status public.builderprojectstatus,
    tech_stack public.buildertechstack,
    project_path text,
    plan jsonb,
    features jsonb,
    generated_files jsonb,
    ai_messages jsonb,
    current_step character varying(100),
    error_message text,
    build_logs text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    deployed_at timestamp without time zone
);


ALTER TABLE public.builder_projects OWNER TO jarvis;

--
-- Name: calendar_automations; Type: TABLE; Schema: public; Owner: jarvis
--

CREATE TABLE public.calendar_automations (
    id uuid NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    calendar_id character varying(255) DEFAULT 'primary'::character varying NOT NULL,
    event_keywords json NOT NULL,
    ha_automation_id character varying(255),
    ha_service_domain character varying(100),
    ha_service_name character varying(100),
    ha_service_data json,
    lead_time_minutes integer DEFAULT 15 NOT NULL,
    lag_time_minutes integer DEFAULT 0 NOT NULL,
    status public.automationstatus DEFAULT 'active'::public.automationstatus NOT NULL,
    last_triggered timestamp with time zone,
    trigger_count integer DEFAULT 0 NOT NULL,
    last_error text,
    created_by character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.calendar_automations OWNER TO jarvis;

--
-- Name: chat_history; Type: TABLE; Schema: public; Owner: jarvis
--

CREATE TABLE public.chat_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    session_id character varying(255) NOT NULL,
    user_id character varying(255),
    role character varying(20) NOT NULL,
    content text NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.chat_history OWNER TO jarvis;

--
-- Name: compose_specs; Type: TABLE; Schema: public; Owner: jarvis
--

CREATE TABLE public.compose_specs (
    id uuid NOT NULL,
    project_id uuid NOT NULL,
    version integer NOT NULL,
    yaml_content text NOT NULL,
    checksum character varying(64) NOT NULL,
    services jsonb,
    networks jsonb,
    volumes jsonb,
    is_active boolean NOT NULL,
    created_by character varying(100),
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.compose_specs OWNER TO jarvis;

--
-- Name: db_backup_jobs; Type: TABLE; Schema: public; Owner: jarvis
--

CREATE TABLE public.db_backup_jobs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    db_name character varying(255) NOT NULL,
    backup_type character varying(50) NOT NULL,
    status character varying(50) DEFAULT 'pending'::character varying NOT NULL,
    storage_path character varying(1000),
    file_size bigint,
    compression character varying(50),
    error_message text,
    backup_metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    started_at timestamp with time zone,
    completed_at timestamp with time zone
);


ALTER TABLE public.db_backup_jobs OWNER TO jarvis;

--
-- Name: db_credentials; Type: TABLE; Schema: public; Owner: jarvis
--

CREATE TABLE public.db_credentials (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    db_name character varying(255) NOT NULL,
    username character varying(255) NOT NULL,
    password_hash character varying(500) NOT NULL,
    host character varying(255) DEFAULT 'discord-bot-db'::character varying NOT NULL,
    port integer DEFAULT 5432 NOT NULL,
    connection_string text,
    is_active boolean DEFAULT true NOT NULL,
    last_tested_at timestamp with time zone,
    test_status character varying(50),
    credential_metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.db_credentials OWNER TO jarvis;

--
-- Name: deployed_apps; Type: TABLE; Schema: public; Owner: jarvis
--

CREATE TABLE public.deployed_apps (
    id integer NOT NULL,
    app_id integer NOT NULL,
    container_name character varying(200) NOT NULL,
    domain character varying(200),
    port integer NOT NULL,
    env_vars json NOT NULL,
    status character varying(50) DEFAULT 'deploying'::character varying NOT NULL,
    health_status character varying(50) DEFAULT 'unknown'::character varying NOT NULL,
    deployed_at timestamp with time zone DEFAULT now() NOT NULL,
    last_check timestamp with time zone,
    error_message text
);


ALTER TABLE public.deployed_apps OWNER TO jarvis;

--
-- Name: deployed_apps_id_seq; Type: SEQUENCE; Schema: public; Owner: jarvis
--

CREATE SEQUENCE public.deployed_apps_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.deployed_apps_id_seq OWNER TO jarvis;

--
-- Name: deployed_apps_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jarvis
--

ALTER SEQUENCE public.deployed_apps_id_seq OWNED BY public.deployed_apps.id;


--
-- Name: deployment_logs; Type: TABLE; Schema: public; Owner: jarvis
--

CREATE TABLE public.deployment_logs (
    id integer NOT NULL,
    deployment_id character varying(100) NOT NULL,
    level character varying(20) DEFAULT 'info'::character varying,
    message text NOT NULL,
    step character varying(100),
    "timestamp" timestamp without time zone DEFAULT now() NOT NULL,
    metadata_json json
);


ALTER TABLE public.deployment_logs OWNER TO jarvis;

--
-- Name: deployment_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: jarvis
--

CREATE SEQUENCE public.deployment_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.deployment_logs_id_seq OWNER TO jarvis;

--
-- Name: deployment_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jarvis
--

ALTER SEQUENCE public.deployment_logs_id_seq OWNED BY public.deployment_logs.id;


--
-- Name: deployment_queue; Type: TABLE; Schema: public; Owner: jarvis
--

CREATE TABLE public.deployment_queue (
    id integer NOT NULL,
    deployment_id character varying(100) NOT NULL,
    template_id character varying(100) NOT NULL,
    category character varying(50),
    app_name character varying(100) NOT NULL,
    status public.queuedeploymentstatus DEFAULT 'pending'::public.queuedeploymentstatus NOT NULL,
    progress double precision DEFAULT '0'::double precision,
    current_step character varying(200),
    total_steps integer DEFAULT 5,
    current_step_number integer DEFAULT 0,
    variables json,
    compose_path character varying(500),
    container_id character varying(100),
    container_name character varying(100),
    started_by character varying(100),
    celery_task_id character varying(100),
    rollback_available boolean DEFAULT false,
    rollback_snapshot json,
    previous_state json,
    error_message text,
    error_details json,
    logs text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    metadata_json json
);


ALTER TABLE public.deployment_queue OWNER TO jarvis;

--
-- Name: deployment_queue_id_seq; Type: SEQUENCE; Schema: public; Owner: jarvis
--

CREATE SEQUENCE public.deployment_queue_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.deployment_queue_id_seq OWNER TO jarvis;

--
-- Name: deployment_queue_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jarvis
--

ALTER SEQUENCE public.deployment_queue_id_seq OWNED BY public.deployment_queue.id;


--
-- Name: deployments; Type: TABLE; Schema: public; Owner: jarvis
--

CREATE TABLE public.deployments (
    id uuid NOT NULL,
    workflow_id uuid NOT NULL,
    artifact_id uuid,
    service_name character varying(255) NOT NULL,
    service_type character varying(100) NOT NULL,
    domain character varying(255),
    status public.deploymentstatus NOT NULL,
    deployed_at timestamp with time zone DEFAULT now(),
    configuration json,
    health_status public.healthstatus NOT NULL,
    last_health_check timestamp with time zone,
    rollout_strategy character varying(50) DEFAULT 'rolling'::character varying,
    previous_deployment_id uuid,
    ssl_certificate_id uuid,
    compose_spec_id uuid,
    health_check_url text,
    health_check_status character varying(20)
);


ALTER TABLE public.deployments OWNER TO jarvis;

--
-- Name: domain_records; Type: TABLE; Schema: public; Owner: jarvis
--

CREATE TABLE public.domain_records (
    id uuid NOT NULL,
    deployment_id uuid,
    domain character varying(255) NOT NULL,
    subdomain character varying(255) NOT NULL,
    record_type public.recordtype NOT NULL,
    record_value character varying(512) NOT NULL,
    ttl integer NOT NULL,
    auto_managed boolean NOT NULL,
    dns_provider character varying(100) NOT NULL,
    status public.recordstatus NOT NULL,
    verified_at timestamp with time zone,
    metadata json,
    managed_by character varying(20) DEFAULT 'automatic'::character varying,
    verification_token character varying(255),
    priority integer,
    provider character varying(50),
    provider_record_id character varying(255),
    last_verified timestamp without time zone
);


ALTER TABLE public.domain_records OWNER TO jarvis;

--
-- Name: drive_backups; Type: TABLE; Schema: public; Owner: jarvis
--

CREATE TABLE public.drive_backups (
    id uuid NOT NULL,
    drive_file_id character varying(255) NOT NULL,
    file_name character varying(500) NOT NULL,
    description text,
    file_size integer DEFAULT 0 NOT NULL,
    local_path character varying(1000),
    drive_folder_id character varying(255),
    status public.backupstatus DEFAULT 'pending'::public.backupstatus NOT NULL,
    uploaded_at timestamp with time zone,
    web_view_link character varying(1000),
    backup_type character varying(100) DEFAULT 'manual'::character varying NOT NULL,
    retention_days integer,
    auto_delete_at timestamp with time zone,
    deleted boolean DEFAULT false NOT NULL,
    error_message text,
    metadata json,
    created_by character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.drive_backups OWNER TO jarvis;

--
-- Name: email_notifications; Type: TABLE; Schema: public; Owner: jarvis
--

CREATE TABLE public.email_notifications (
    id uuid NOT NULL,
    recipient character varying(255) NOT NULL,
    subject character varying(500) NOT NULL,
    template_type character varying(50) DEFAULT 'custom'::character varying NOT NULL,
    status public.emailnotificationstatus DEFAULT 'pending'::public.emailnotificationstatus NOT NULL,
    gmail_message_id character varying(255),
    gmail_thread_id character varying(255),
    sent_at timestamp with time zone,
    error_message text,
    retry_count integer DEFAULT 0 NOT NULL,
    metadata json,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.email_notifications OWNER TO jarvis;

--
-- Name: game_sessions; Type: TABLE; Schema: public; Owner: jarvis
--

CREATE TABLE public.game_sessions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    session_type character varying(50) NOT NULL,
    user_id character varying(255),
    host_ip character varying(100) NOT NULL,
    host_name character varying(255),
    status character varying(50) NOT NULL,
    client_device character varying(255),
    resolution character varying(50),
    fps integer,
    bitrate_mbps double precision,
    latency_ms double precision,
    game_name character varying(255),
    game_metadata jsonb,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    ended_at timestamp with time zone,
    host_id uuid,
    app_name character varying(255),
    avg_bitrate double precision,
    avg_fps double precision,
    avg_latency double precision,
    dropped_frames_pct double precision,
    session_outcome character varying(50)
);


ALTER TABLE public.game_sessions OWNER TO jarvis;

--
-- Name: google_service_status; Type: TABLE; Schema: public; Owner: jarvis
--

CREATE TABLE public.google_service_status (
    id uuid NOT NULL,
    service_name character varying(50) NOT NULL,
    status public.serviceconnectionstatus DEFAULT 'disconnected'::public.serviceconnectionstatus NOT NULL,
    last_connected timestamp with time zone,
    last_error text,
    error_count integer DEFAULT 0 NOT NULL,
    connection_metadata json,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.google_service_status OWNER TO jarvis;

--
-- Name: license_activations; Type: TABLE; Schema: public; Owner: jarvis
--

CREATE TABLE public.license_activations (
    id integer NOT NULL,
    subscription_id integer NOT NULL,
    server_id character varying(255) NOT NULL,
    server_hostname character varying(255),
    server_ip character varying(45),
    activated_at timestamp without time zone NOT NULL,
    last_verified timestamp without time zone NOT NULL,
    active boolean NOT NULL
);


ALTER TABLE public.license_activations OWNER TO jarvis;

--
-- Name: license_activations_id_seq; Type: SEQUENCE; Schema: public; Owner: jarvis
--

CREATE SEQUENCE public.license_activations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.license_activations_id_seq OWNER TO jarvis;

--
-- Name: license_activations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jarvis
--

ALTER SEQUENCE public.license_activations_id_seq OWNED BY public.license_activations.id;


--
-- Name: marketplace_apps; Type: TABLE; Schema: public; Owner: jarvis
--

CREATE TABLE public.marketplace_apps (
    id integer NOT NULL,
    slug character varying(100) NOT NULL,
    name character varying(200) NOT NULL,
    category character varying(50),
    description text,
    long_description text,
    icon_url character varying(500),
    screenshot_url character varying(500),
    docker_image character varying(200) NOT NULL,
    default_port integer NOT NULL,
    requires_database boolean DEFAULT false NOT NULL,
    db_type character varying(50),
    config_template json NOT NULL,
    env_template json NOT NULL,
    popularity integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.marketplace_apps OWNER TO jarvis;

--
-- Name: marketplace_apps_id_seq; Type: SEQUENCE; Schema: public; Owner: jarvis
--

CREATE SEQUENCE public.marketplace_apps_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.marketplace_apps_id_seq OWNER TO jarvis;

--
-- Name: marketplace_apps_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jarvis
--

ALTER SEQUENCE public.marketplace_apps_id_seq OWNED BY public.marketplace_apps.id;


--
-- Name: marketplace_deployments; Type: TABLE; Schema: public; Owner: jarvis
--

CREATE TABLE public.marketplace_deployments (
    id character varying(36) NOT NULL,
    template_id character varying(100) NOT NULL,
    category character varying(50) NOT NULL,
    variables json NOT NULL,
    compose_path character varying(500) NOT NULL,
    status character varying(50) DEFAULT 'installing'::character varying NOT NULL,
    error_message text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.marketplace_deployments OWNER TO jarvis;

--
-- Name: model_usage; Type: TABLE; Schema: public; Owner: jarvis
--

CREATE TABLE public.model_usage (
    id integer NOT NULL,
    model_id character varying(100) NOT NULL,
    provider character varying(50) NOT NULL,
    request_type character varying(50),
    prompt_tokens integer DEFAULT 0,
    completion_tokens integer DEFAULT 0,
    total_tokens integer DEFAULT 0,
    estimated_cost_usd double precision DEFAULT '0'::double precision,
    response_time_ms integer,
    success boolean DEFAULT true,
    error_message text,
    user_id character varying(100),
    session_id character varying(100),
    "timestamp" timestamp without time zone DEFAULT now() NOT NULL,
    year_month character varying(7),
    metadata_json json
);


ALTER TABLE public.model_usage OWNER TO jarvis;

--
-- Name: model_usage_id_seq; Type: SEQUENCE; Schema: public; Owner: jarvis
--

CREATE SEQUENCE public.model_usage_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.model_usage_id_seq OWNER TO jarvis;

--
-- Name: model_usage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jarvis
--

ALTER SEQUENCE public.model_usage_id_seq OWNED BY public.model_usage.id;


--
-- Name: nas_backup_jobs; Type: TABLE; Schema: public; Owner: jarvis
--

CREATE TABLE public.nas_backup_jobs (
    id integer NOT NULL,
    source_path character varying(512) NOT NULL,
    dest_share character varying(255) NOT NULL,
    backup_name character varying(255) NOT NULL,
    status character varying(50),
    error_message text,
    created_at timestamp with time zone DEFAULT now(),
    completed_at timestamp with time zone
);


ALTER TABLE public.nas_backup_jobs OWNER TO jarvis;

--
-- Name: nas_backup_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: jarvis
--

CREATE SEQUENCE public.nas_backup_jobs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.nas_backup_jobs_id_seq OWNER TO jarvis;

--
-- Name: nas_backup_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jarvis
--

ALTER SEQUENCE public.nas_backup_jobs_id_seq OWNED BY public.nas_backup_jobs.id;


--
-- Name: nas_mounts; Type: TABLE; Schema: public; Owner: jarvis
--

CREATE TABLE public.nas_mounts (
    id integer NOT NULL,
    share_name character varying(255) NOT NULL,
    mount_point character varying(512) NOT NULL,
    is_active boolean,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.nas_mounts OWNER TO jarvis;

--
-- Name: nas_mounts_id_seq; Type: SEQUENCE; Schema: public; Owner: jarvis
--

CREATE SEQUENCE public.nas_mounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.nas_mounts_id_seq OWNER TO jarvis;

--
-- Name: nas_mounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jarvis
--

ALTER SEQUENCE public.nas_mounts_id_seq OWNED BY public.nas_mounts.id;


--
-- Name: plex_import_items; Type: TABLE; Schema: public; Owner: jarvis
--

CREATE TABLE public.plex_import_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    job_id uuid NOT NULL,
    filename character varying(500) NOT NULL,
    original_filename character varying(500) NOT NULL,
    file_size bigint NOT NULL,
    mime_type character varying(100),
    storage_path character varying(1000) NOT NULL,
    final_path character varying(1000),
    status character varying(50) DEFAULT 'pending'::character varying NOT NULL,
    item_metadata jsonb,
    error_message text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    processed_at timestamp with time zone
);


ALTER TABLE public.plex_import_items OWNER TO jarvis;

--
-- Name: plex_import_jobs; Type: TABLE; Schema: public; Owner: jarvis
--

CREATE TABLE public.plex_import_jobs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(255) NOT NULL,
    job_type character varying(50) NOT NULL,
    status character varying(50) DEFAULT 'pending'::character varying NOT NULL,
    total_files integer DEFAULT 0 NOT NULL,
    processed_files integer DEFAULT 0 NOT NULL,
    target_directory character varying(500),
    job_metadata jsonb,
    error_message text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone
);


ALTER TABLE public.plex_import_jobs OWNER TO jarvis;

--
-- Name: projects; Type: TABLE; Schema: public; Owner: jarvis
--

CREATE TABLE public.projects (
    id uuid NOT NULL,
    name character varying(255) NOT NULL,
    path text NOT NULL,
    project_type character varying(50) NOT NULL,
    framework character varying(50),
    detected_at timestamp without time zone DEFAULT now() NOT NULL,
    last_scanned timestamp without time zone,
    config jsonb,
    status character varying(20) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.projects OWNER TO jarvis;

--
-- Name: remediation_history; Type: TABLE; Schema: public; Owner: jarvis
--

CREATE TABLE public.remediation_history (
    id integer NOT NULL,
    service_name character varying(100) NOT NULL,
    container_name character varying(100),
    trigger_type character varying(50) NOT NULL,
    trigger_details json,
    issue_summary text,
    ai_diagnosis text,
    ai_plan json,
    ai_model_used character varying(100),
    actions_taken json,
    actions_count integer DEFAULT 0,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    success boolean,
    result_message text,
    logs_before text,
    logs_after text,
    initiated_by character varying(100),
    is_automatic boolean DEFAULT false,
    started_at timestamp without time zone DEFAULT now() NOT NULL,
    completed_at timestamp without time zone,
    duration_seconds integer,
    rollback_available boolean DEFAULT false,
    rollback_data json,
    metadata_json json
);


ALTER TABLE public.remediation_history OWNER TO jarvis;

--
-- Name: remediation_history_id_seq; Type: SEQUENCE; Schema: public; Owner: jarvis
--

CREATE SEQUENCE public.remediation_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.remediation_history_id_seq OWNER TO jarvis;

--
-- Name: remediation_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jarvis
--

ALTER SEQUENCE public.remediation_history_id_seq OWNED BY public.remediation_history.id;


--
-- Name: request_queue; Type: TABLE; Schema: public; Owner: jarvis
--

CREATE TABLE public.request_queue (
    id integer NOT NULL,
    request_type character varying(50) NOT NULL,
    user_id character varying(100),
    session_id character varying(100),
    query text NOT NULL,
    context json,
    preferred_model character varying(100),
    priority integer DEFAULT 5,
    status character varying(20) DEFAULT 'pending'::character varying,
    response text,
    error_message text,
    retry_count integer DEFAULT 0,
    max_retries integer DEFAULT 3,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    processed_at timestamp without time zone,
    expires_at timestamp without time zone,
    callback_url character varying(500),
    metadata_json json
);


ALTER TABLE public.request_queue OWNER TO jarvis;

--
-- Name: request_queue_id_seq; Type: SEQUENCE; Schema: public; Owner: jarvis
--

CREATE SEQUENCE public.request_queue_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.request_queue_id_seq OWNER TO jarvis;

--
-- Name: request_queue_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jarvis
--

ALTER SEQUENCE public.request_queue_id_seq OWNED BY public.request_queue.id;


--
-- Name: response_cache; Type: TABLE; Schema: public; Owner: jarvis
--

CREATE TABLE public.response_cache (
    id integer NOT NULL,
    query_hash character varying(64) NOT NULL,
    query_pattern character varying(500),
    query_category character varying(50),
    original_query text NOT NULL,
    response text NOT NULL,
    response_model character varying(100),
    hit_count integer DEFAULT 1,
    last_hit_at timestamp without time zone,
    quality_score double precision,
    is_verified boolean DEFAULT false,
    verified_by character varying(100),
    verified_at timestamp without time zone,
    expires_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    metadata_json json
);


ALTER TABLE public.response_cache OWNER TO jarvis;

--
-- Name: response_cache_id_seq; Type: SEQUENCE; Schema: public; Owner: jarvis
--

CREATE SEQUENCE public.response_cache_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.response_cache_id_seq OWNER TO jarvis;

--
-- Name: response_cache_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jarvis
--

ALTER SEQUENCE public.response_cache_id_seq OWNED BY public.response_cache.id;


--
-- Name: role_assignments; Type: TABLE; Schema: public; Owner: jarvis
--

CREATE TABLE public.role_assignments (
    id integer NOT NULL,
    user_id integer NOT NULL,
    previous_role public.userrole,
    new_role public.userrole NOT NULL,
    assigned_by character varying(100),
    reason text,
    assigned_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.role_assignments OWNER TO jarvis;

--
-- Name: role_assignments_id_seq; Type: SEQUENCE; Schema: public; Owner: jarvis
--

CREATE SEQUENCE public.role_assignments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.role_assignments_id_seq OWNER TO jarvis;

--
-- Name: role_assignments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jarvis
--

ALTER SEQUENCE public.role_assignments_id_seq OWNED BY public.role_assignments.id;


--
-- Name: service_configs; Type: TABLE; Schema: public; Owner: jarvis
--

CREATE TABLE public.service_configs (
    id integer NOT NULL,
    service_name character varying(100) NOT NULL,
    display_name character varying(200),
    description text,
    container_name character varying(100),
    image_name character varying(255),
    image_tag character varying(100),
    category character varying(50),
    ports json,
    volumes json,
    environment json,
    labels json,
    health_check_url character varying(500),
    health_check_interval integer DEFAULT 60,
    health_check_timeout integer DEFAULT 10,
    restart_policy character varying(50) DEFAULT 'unless-stopped'::character varying,
    max_restarts integer DEFAULT 3,
    dependencies json,
    is_enabled boolean DEFAULT true,
    is_critical boolean DEFAULT false,
    public_url character varying(500),
    internal_url character varying(500),
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    metadata_json json
);


ALTER TABLE public.service_configs OWNER TO jarvis;

--
-- Name: service_configs_id_seq; Type: SEQUENCE; Schema: public; Owner: jarvis
--

CREATE SEQUENCE public.service_configs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.service_configs_id_seq OWNER TO jarvis;

--
-- Name: service_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jarvis
--

ALTER SEQUENCE public.service_configs_id_seq OWNED BY public.service_configs.id;


--
-- Name: service_dependencies; Type: TABLE; Schema: public; Owner: jarvis
--

CREATE TABLE public.service_dependencies (
    id integer NOT NULL,
    service_name character varying(100) NOT NULL,
    depends_on character varying(100) NOT NULL,
    dependency_type character varying(50) DEFAULT 'required'::character varying,
    startup_order integer,
    health_check_required boolean DEFAULT true,
    timeout_seconds integer DEFAULT 60,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.service_dependencies OWNER TO jarvis;

--
-- Name: service_dependencies_id_seq; Type: SEQUENCE; Schema: public; Owner: jarvis
--

CREATE SEQUENCE public.service_dependencies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.service_dependencies_id_seq OWNER TO jarvis;

--
-- Name: service_dependencies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jarvis
--

ALTER SEQUENCE public.service_dependencies_id_seq OWNED BY public.service_dependencies.id;


--
-- Name: service_health_alerts; Type: TABLE; Schema: public; Owner: jarvis
--

CREATE TABLE public.service_health_alerts (
    id integer NOT NULL,
    service_name character varying(100) NOT NULL,
    severity character varying(20) NOT NULL,
    message character varying(500) NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    triggered_at timestamp with time zone DEFAULT now() NOT NULL,
    resolved_at timestamp with time zone
);


ALTER TABLE public.service_health_alerts OWNER TO jarvis;

--
-- Name: service_health_alerts_id_seq; Type: SEQUENCE; Schema: public; Owner: jarvis
--

CREATE SEQUENCE public.service_health_alerts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.service_health_alerts_id_seq OWNER TO jarvis;

--
-- Name: service_health_alerts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jarvis
--

ALTER SEQUENCE public.service_health_alerts_id_seq OWNED BY public.service_health_alerts.id;


--
-- Name: service_health_checks; Type: TABLE; Schema: public; Owner: jarvis
--

CREATE TABLE public.service_health_checks (
    id integer NOT NULL,
    service_name character varying(100) NOT NULL,
    status character varying(20) NOT NULL,
    checks json,
    response_time_ms integer,
    "timestamp" timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.service_health_checks OWNER TO jarvis;

--
-- Name: service_health_checks_id_seq; Type: SEQUENCE; Schema: public; Owner: jarvis
--

CREATE SEQUENCE public.service_health_checks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.service_health_checks_id_seq OWNER TO jarvis;

--
-- Name: service_health_checks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jarvis
--

ALTER SEQUENCE public.service_health_checks_id_seq OWNED BY public.service_health_checks.id;


--
-- Name: service_ownerships; Type: TABLE; Schema: public; Owner: jarvis
--

CREATE TABLE public.service_ownerships (
    id integer NOT NULL,
    user_id integer NOT NULL,
    service_name character varying(100) NOT NULL,
    container_name character varying(100),
    permission_level public.userrole DEFAULT 'viewer'::public.userrole NOT NULL,
    granted_at timestamp without time zone DEFAULT now() NOT NULL,
    granted_by character varying(100),
    notes text
);


ALTER TABLE public.service_ownerships OWNER TO jarvis;

--
-- Name: service_ownerships_id_seq; Type: SEQUENCE; Schema: public; Owner: jarvis
--

CREATE SEQUENCE public.service_ownerships_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.service_ownerships_id_seq OWNER TO jarvis;

--
-- Name: service_ownerships_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jarvis
--

ALTER SEQUENCE public.service_ownerships_id_seq OWNED BY public.service_ownerships.id;


--
-- Name: service_settings; Type: TABLE; Schema: public; Owner: jarvis
--

CREATE TABLE public.service_settings (
    id integer NOT NULL,
    service_id integer NOT NULL,
    key character varying(100) NOT NULL,
    value text,
    value_type character varying(20) DEFAULT 'string'::character varying,
    is_secret boolean DEFAULT false,
    is_required boolean DEFAULT false,
    description text,
    default_value text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone
);


ALTER TABLE public.service_settings OWNER TO jarvis;

--
-- Name: service_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: jarvis
--

CREATE SEQUENCE public.service_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.service_settings_id_seq OWNER TO jarvis;

--
-- Name: service_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jarvis
--

ALTER SEQUENCE public.service_settings_id_seq OWNED BY public.service_settings.id;


--
-- Name: service_telemetry; Type: TABLE; Schema: public; Owner: jarvis
--

CREATE TABLE public.service_telemetry (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    service_name character varying(255) NOT NULL,
    container_id character varying(255),
    status character varying(50) NOT NULL,
    cpu_percent double precision,
    memory_usage bigint,
    memory_limit bigint,
    network_rx bigint,
    network_tx bigint,
    health_status character varying(50),
    restart_count integer,
    uptime_seconds integer,
    service_metadata jsonb,
    "timestamp" timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.service_telemetry OWNER TO jarvis;

--
-- Name: ssl_certificates; Type: TABLE; Schema: public; Owner: jarvis
--

CREATE TABLE public.ssl_certificates (
    id uuid NOT NULL,
    domain character varying(255) NOT NULL,
    status character varying(20) NOT NULL,
    provider character varying(50) NOT NULL,
    cert_path text,
    key_path text,
    chain_path text,
    issued_at timestamp without time zone,
    expires_at timestamp without time zone,
    auto_renew boolean NOT NULL,
    last_renewal_attempt timestamp without time zone,
    renewal_logs text,
    cert_metadata jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.ssl_certificates OWNER TO jarvis;

--
-- Name: storage_alerts; Type: TABLE; Schema: public; Owner: jarvis
--

CREATE TABLE public.storage_alerts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    metric_type character varying(50) NOT NULL,
    metric_name character varying(255) NOT NULL,
    threshold_percent double precision DEFAULT '80'::double precision NOT NULL,
    alert_enabled boolean DEFAULT true NOT NULL,
    last_alerted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.storage_alerts OWNER TO jarvis;

--
-- Name: storage_metrics; Type: TABLE; Schema: public; Owner: jarvis
--

CREATE TABLE public.storage_metrics (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    metric_type character varying(50) NOT NULL,
    metric_name character varying(255) NOT NULL,
    path character varying(1000),
    size_bytes bigint NOT NULL,
    file_count integer,
    usage_percent double precision,
    storage_metadata jsonb,
    "timestamp" timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.storage_metrics OWNER TO jarvis;

--
-- Name: subscriptions; Type: TABLE; Schema: public; Owner: jarvis
--

CREATE TABLE public.subscriptions (
    id integer NOT NULL,
    user_email character varying(255) NOT NULL,
    license_key character varying(64) NOT NULL,
    tier public.subscriptiontier NOT NULL,
    status public.subscriptionstatus NOT NULL,
    amount_cents integer,
    currency character varying(3),
    billing_interval character varying(20),
    trial_ends_at timestamp without time zone,
    current_period_start timestamp without time zone,
    current_period_end timestamp without time zone,
    canceled_at timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    max_servers integer,
    ai_requests_per_month integer,
    marketplace_deployments integer,
    priority_support boolean,
    white_label boolean,
    stripe_customer_id character varying(255),
    stripe_subscription_id character varying(255)
);


ALTER TABLE public.subscriptions OWNER TO jarvis;

--
-- Name: subscriptions_id_seq; Type: SEQUENCE; Schema: public; Owner: jarvis
--

CREATE SEQUENCE public.subscriptions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.subscriptions_id_seq OWNER TO jarvis;

--
-- Name: subscriptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jarvis
--

ALTER SEQUENCE public.subscriptions_id_seq OWNED BY public.subscriptions.id;


--
-- Name: sunshine_hosts; Type: TABLE; Schema: public; Owner: jarvis
--

CREATE TABLE public.sunshine_hosts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    host_ip character varying(100) NOT NULL,
    host_name character varying(255),
    api_url character varying(500) NOT NULL,
    is_paired boolean DEFAULT false NOT NULL,
    pairing_pin character varying(20),
    last_online timestamp with time zone,
    gpu_model character varying(255),
    applications jsonb,
    host_metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.sunshine_hosts OWNER TO jarvis;

--
-- Name: system_logs; Type: TABLE; Schema: public; Owner: jarvis
--

CREATE TABLE public.system_logs (
    id integer NOT NULL,
    source character varying(100) NOT NULL,
    source_type character varying(50) NOT NULL,
    level character varying(20) NOT NULL,
    category character varying(50),
    message text NOT NULL,
    details json,
    container_id character varying(64),
    container_name character varying(100),
    host character varying(100),
    process_id integer,
    stack_trace text,
    error_code character varying(50),
    cpu_percent double precision,
    memory_percent double precision,
    disk_percent double precision,
    "timestamp" timestamp without time zone DEFAULT now() NOT NULL,
    year_month character varying(7),
    metadata_json json
);


ALTER TABLE public.system_logs OWNER TO jarvis;

--
-- Name: system_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: jarvis
--

CREATE SEQUENCE public.system_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.system_logs_id_seq OWNER TO jarvis;

--
-- Name: system_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jarvis
--

ALTER SEQUENCE public.system_logs_id_seq OWNED BY public.system_logs.id;


--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: jarvis
--

CREATE TABLE public.system_settings (
    id integer NOT NULL,
    key character varying(200) NOT NULL,
    value text,
    category character varying(50),
    description text,
    is_secret boolean,
    is_required boolean,
    last_validated timestamp without time zone,
    validation_status character varying(20),
    validation_message text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.system_settings OWNER TO jarvis;

--
-- Name: system_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: jarvis
--

CREATE SEQUENCE public.system_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.system_settings_id_seq OWNER TO jarvis;

--
-- Name: system_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jarvis
--

ALTER SEQUENCE public.system_settings_id_seq OWNED BY public.system_settings.id;


--
-- Name: tasks; Type: TABLE; Schema: public; Owner: jarvis
--

CREATE TABLE public.tasks (
    id uuid NOT NULL,
    workflow_id uuid,
    title character varying(255) NOT NULL,
    description text NOT NULL,
    task_type public.tasktype NOT NULL,
    status public.taskstatus NOT NULL,
    priority public.taskpriority NOT NULL,
    assigned_to character varying(255),
    instructions json,
    created_at timestamp with time zone DEFAULT now(),
    completed_at timestamp with time zone,
    metadata json
);


ALTER TABLE public.tasks OWNER TO jarvis;

--
-- Name: unified_logs; Type: TABLE; Schema: public; Owner: jarvis
--

CREATE TABLE public.unified_logs (
    id integer NOT NULL,
    service character varying(100) NOT NULL,
    container_id character varying(64),
    log_level character varying(20) NOT NULL,
    message text NOT NULL,
    "timestamp" timestamp without time zone DEFAULT now() NOT NULL,
    extra_metadata json
);


ALTER TABLE public.unified_logs OWNER TO jarvis;

--
-- Name: unified_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: jarvis
--

CREATE SEQUENCE public.unified_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.unified_logs_id_seq OWNER TO jarvis;

--
-- Name: unified_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jarvis
--

ALTER SEQUENCE public.unified_logs_id_seq OWNED BY public.unified_logs.id;


--
-- Name: usage_metrics; Type: TABLE; Schema: public; Owner: jarvis
--

CREATE TABLE public.usage_metrics (
    id integer NOT NULL,
    subscription_id integer NOT NULL,
    metric_type character varying(50) NOT NULL,
    count integer NOT NULL,
    period_start timestamp without time zone NOT NULL,
    period_end timestamp without time zone
);


ALTER TABLE public.usage_metrics OWNER TO jarvis;

--
-- Name: usage_metrics_id_seq; Type: SEQUENCE; Schema: public; Owner: jarvis
--

CREATE SEQUENCE public.usage_metrics_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.usage_metrics_id_seq OWNER TO jarvis;

--
-- Name: usage_metrics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jarvis
--

ALTER SEQUENCE public.usage_metrics_id_seq OWNED BY public.usage_metrics.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: jarvis
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(100) NOT NULL,
    email character varying(255),
    role public.userrole DEFAULT 'viewer'::public.userrole NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    last_login timestamp without time zone,
    metadata_json json
);


ALTER TABLE public.users OWNER TO jarvis;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: jarvis
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO jarvis;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jarvis
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: workflows; Type: TABLE; Schema: public; Owner: jarvis
--

CREATE TABLE public.workflows (
    id uuid NOT NULL,
    name character varying(255) NOT NULL,
    status public.workflowstatus NOT NULL,
    workflow_type character varying(100) NOT NULL,
    created_by character varying(255) NOT NULL,
    started_at timestamp with time zone DEFAULT now(),
    completed_at timestamp with time zone,
    error_message text,
    metadata json,
    current_step character varying(255),
    total_steps integer
);


ALTER TABLE public.workflows OWNER TO jarvis;

--
-- Name: activity_logs id; Type: DEFAULT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.activity_logs ALTER COLUMN id SET DEFAULT nextval('public.activity_logs_id_seq'::regclass);


--
-- Name: agent_conversations id; Type: DEFAULT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.agent_conversations ALTER COLUMN id SET DEFAULT nextval('public.agent_conversations_id_seq'::regclass);


--
-- Name: agent_tasks id; Type: DEFAULT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.agent_tasks ALTER COLUMN id SET DEFAULT nextval('public.agent_tasks_id_seq'::regclass);


--
-- Name: anomaly_baselines id; Type: DEFAULT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.anomaly_baselines ALTER COLUMN id SET DEFAULT nextval('public.anomaly_baselines_id_seq'::regclass);


--
-- Name: anomaly_events id; Type: DEFAULT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.anomaly_events ALTER COLUMN id SET DEFAULT nextval('public.anomaly_events_id_seq'::regclass);


--
-- Name: audit_logs id; Type: DEFAULT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN id SET DEFAULT nextval('public.audit_logs_id_seq'::regclass);


--
-- Name: deployed_apps id; Type: DEFAULT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.deployed_apps ALTER COLUMN id SET DEFAULT nextval('public.deployed_apps_id_seq'::regclass);


--
-- Name: deployment_logs id; Type: DEFAULT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.deployment_logs ALTER COLUMN id SET DEFAULT nextval('public.deployment_logs_id_seq'::regclass);


--
-- Name: deployment_queue id; Type: DEFAULT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.deployment_queue ALTER COLUMN id SET DEFAULT nextval('public.deployment_queue_id_seq'::regclass);


--
-- Name: license_activations id; Type: DEFAULT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.license_activations ALTER COLUMN id SET DEFAULT nextval('public.license_activations_id_seq'::regclass);


--
-- Name: marketplace_apps id; Type: DEFAULT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.marketplace_apps ALTER COLUMN id SET DEFAULT nextval('public.marketplace_apps_id_seq'::regclass);


--
-- Name: model_usage id; Type: DEFAULT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.model_usage ALTER COLUMN id SET DEFAULT nextval('public.model_usage_id_seq'::regclass);


--
-- Name: nas_backup_jobs id; Type: DEFAULT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.nas_backup_jobs ALTER COLUMN id SET DEFAULT nextval('public.nas_backup_jobs_id_seq'::regclass);


--
-- Name: nas_mounts id; Type: DEFAULT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.nas_mounts ALTER COLUMN id SET DEFAULT nextval('public.nas_mounts_id_seq'::regclass);


--
-- Name: remediation_history id; Type: DEFAULT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.remediation_history ALTER COLUMN id SET DEFAULT nextval('public.remediation_history_id_seq'::regclass);


--
-- Name: request_queue id; Type: DEFAULT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.request_queue ALTER COLUMN id SET DEFAULT nextval('public.request_queue_id_seq'::regclass);


--
-- Name: response_cache id; Type: DEFAULT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.response_cache ALTER COLUMN id SET DEFAULT nextval('public.response_cache_id_seq'::regclass);


--
-- Name: role_assignments id; Type: DEFAULT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.role_assignments ALTER COLUMN id SET DEFAULT nextval('public.role_assignments_id_seq'::regclass);


--
-- Name: service_configs id; Type: DEFAULT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.service_configs ALTER COLUMN id SET DEFAULT nextval('public.service_configs_id_seq'::regclass);


--
-- Name: service_dependencies id; Type: DEFAULT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.service_dependencies ALTER COLUMN id SET DEFAULT nextval('public.service_dependencies_id_seq'::regclass);


--
-- Name: service_health_alerts id; Type: DEFAULT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.service_health_alerts ALTER COLUMN id SET DEFAULT nextval('public.service_health_alerts_id_seq'::regclass);


--
-- Name: service_health_checks id; Type: DEFAULT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.service_health_checks ALTER COLUMN id SET DEFAULT nextval('public.service_health_checks_id_seq'::regclass);


--
-- Name: service_ownerships id; Type: DEFAULT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.service_ownerships ALTER COLUMN id SET DEFAULT nextval('public.service_ownerships_id_seq'::regclass);


--
-- Name: service_settings id; Type: DEFAULT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.service_settings ALTER COLUMN id SET DEFAULT nextval('public.service_settings_id_seq'::regclass);


--
-- Name: subscriptions id; Type: DEFAULT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.subscriptions ALTER COLUMN id SET DEFAULT nextval('public.subscriptions_id_seq'::regclass);


--
-- Name: system_logs id; Type: DEFAULT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.system_logs ALTER COLUMN id SET DEFAULT nextval('public.system_logs_id_seq'::regclass);


--
-- Name: system_settings id; Type: DEFAULT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.system_settings ALTER COLUMN id SET DEFAULT nextval('public.system_settings_id_seq'::regclass);


--
-- Name: unified_logs id; Type: DEFAULT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.unified_logs ALTER COLUMN id SET DEFAULT nextval('public.unified_logs_id_seq'::regclass);


--
-- Name: usage_metrics id; Type: DEFAULT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.usage_metrics ALTER COLUMN id SET DEFAULT nextval('public.usage_metrics_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: activity_logs; Type: TABLE DATA; Schema: public; Owner: jarvis
--

COPY public.activity_logs (id, user_id, username, session_id, activity_type, action, resource_type, resource_id, resource_name, description, previous_state, new_state, ip_address, user_agent, duration_ms, success, "timestamp", year_month, metadata_json) FROM stdin;
\.


--
-- Data for Name: agent_conversations; Type: TABLE DATA; Schema: public; Owner: jarvis
--

COPY public.agent_conversations (id, task_id, from_agent_id, to_agent_id, message, message_type, "timestamp") FROM stdin;
\.


--
-- Data for Name: agent_messages; Type: TABLE DATA; Schema: public; Owner: jarvis
--

COPY public.agent_messages (id, from_agent_id, to_agent_id, message_type, content, priority, status, response_to, created_at, processed_at) FROM stdin;
\.


--
-- Data for Name: agent_tasks; Type: TABLE DATA; Schema: public; Owner: jarvis
--

COPY public.agent_tasks (id, task_type, description, priority, status, assigned_agent_id, parent_task_id, context, result, execution_log, requires_collaboration, collaborating_agents, requires_approval, approved, approved_by, created_at, started_at, completed_at) FROM stdin;
\.


--
-- Data for Name: agents; Type: TABLE DATA; Schema: public; Owner: jarvis
--

COPY public.agents (id, name, agent_type, description, status, capabilities, config, last_active, tasks_completed, tasks_failed, created_at, updated_at, system_prompt, model, current_task_id) FROM stdin;
1ad84d78-1c23-4b0a-a0b6-3a32eeb1590f	Jarvis Master	orchestrator	Main AI orchestrator for all homelab operations	idle	["conversation", "orchestration", "decision_making"]	{"model": "gpt-4", "temperature": 0.7}	\N	0	0	2025-12-04 07:16:30.895059+00	2025-12-04 07:16:30.895059+00	\N	\N	\N
306e2d93-9bf2-4513-927f-68d91b391869	Deployment Agent	deployment	Handles service deployments and Docker operations	idle	["docker", "compose", "ssl", "dns"]	{"max_concurrent_deployments": 3}	\N	0	0	2025-12-04 07:16:30.895059+00	2025-12-04 07:16:30.895059+00	\N	\N	\N
484faca1-909a-4baa-9bc8-1391414ff65b	Security Agent	security	Monitors security, SSL certificates, and vulnerabilities	idle	["ssl_monitoring", "vulnerability_scan", "firewall"]	{"scan_interval": 3600}	\N	0	0	2025-12-04 07:16:30.895059+00	2025-12-04 07:16:30.895059+00	\N	\N	\N
77c08ac4-7d95-4856-b654-5c7c121cac9e	Monitoring Agent	monitoring	Tracks system health, metrics, and performance	idle	["health_checks", "metrics", "alerts"]	{"check_interval": 60}	\N	0	0	2025-12-04 07:16:30.895059+00	2025-12-04 07:16:30.895059+00	\N	\N	\N
8462d4f8-359e-4f88-a8b8-9001040d7e4c	Database Agent	database	Manages database creation, backups, and migrations	idle	["postgres", "mysql", "backup", "restore"]	{"backup_retention_days": 30}	\N	0	0	2025-12-04 07:16:30.895059+00	2025-12-04 07:16:30.895059+00	\N	\N	\N
a50c2b64-81f1-40dc-aeef-288fef512473	Mercury	network	Network and connectivity specialist	idle	["network-diagnosis", "dns-analysis", "ssl-monitoring", "connectivity-testing"]	{}	2025-12-04 07:16:35.330669+00	0	0	2025-12-04 07:16:35.330665+00	2025-12-04 07:16:35.330668+00	You are Mercury, the network specialist.\nYou diagnose connectivity issues, analyze DNS/SSL, and monitor network health.\n\nYour expertise:\n- TCP/IP networking\n- DNS resolution\n- SSL/TLS certificates\n- Port configuration\n- Firewall rules\n- Latency analysis\n\nWhen diagnosing issues:\n- Test connectivity at each layer\n- Verify DNS resolution\n- Check SSL certificate validity\n- Analyze packet routes\n- Suggest specific commands (ping, curl, nslookup, etc.)\n	gpt-4o	\N
458359ef-e110-4103-b280-305009641870	Atlas	container	Container and Docker specialist	idle	["container-health", "log-analysis", "resource-optimization", "docker-troubleshooting"]	{}	2025-12-04 07:16:35.332191+00	0	0	2025-12-04 07:16:35.332189+00	2025-12-04 07:16:35.33219+00	You are Atlas, the container specialist.\nYou analyze Docker container health, diagnose issues, and optimize configurations.\n\nYour expertise:\n- Docker container management\n- Health check analysis\n- Resource limit optimization\n- Log analysis\n- Container networking\n- Image troubleshooting\n\nWhen analyzing containers:\n- Check container status and health\n- Review logs for errors\n- Analyze resource usage\n- Identify restart loops\n- Suggest docker commands for diagnosis\n	gpt-4o	\N
\.


--
-- Data for Name: ai_sessions; Type: TABLE DATA; Schema: public; Owner: jarvis
--

COPY public.ai_sessions (id, user_id, session_type, state, current_step, context, messages, intent, target_project_id, created_at, updated_at, completed_at) FROM stdin;
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: jarvis
--

COPY public.alembic_version (version_num) FROM stdin;
020_system_settings
\.


--
-- Data for Name: anomaly_baselines; Type: TABLE DATA; Schema: public; Owner: jarvis
--

COPY public.anomaly_baselines (id, service_name, metric_name, mean_value, std_dev, min_value, max_value, percentile_25, percentile_50, percentile_75, percentile_95, percentile_99, sample_count, last_sample_value, anomaly_threshold_low, anomaly_threshold_high, sensitivity, time_window_hours, created_at, updated_at, metadata_json) FROM stdin;
\.


--
-- Data for Name: anomaly_events; Type: TABLE DATA; Schema: public; Owner: jarvis
--

COPY public.anomaly_events (id, service_name, metric_name, value, baseline_mean, baseline_std, anomaly_score, direction, severity, is_acknowledged, acknowledged_by, acknowledged_at, auto_remediated, remediation_id, "timestamp", metadata_json) FROM stdin;
\.


--
-- Data for Name: artifact_builds; Type: TABLE DATA; Schema: public; Owner: jarvis
--

COPY public.artifact_builds (id, project_id, workflow_id, status, image_ref, image_tag, dockerfile_content, build_logs, build_duration_ms, image_size_bytes, build_metadata, created_at, completed_at) FROM stdin;
\.


--
-- Data for Name: artifacts; Type: TABLE DATA; Schema: public; Owner: jarvis
--

COPY public.artifacts (id, filename, original_filename, file_type, storage_path, file_size, checksum_sha256, uploaded_by, uploaded_at, detected_service_type, analysis_complete, metadata, analysis_status, analysis_result, detected_framework, requires_database) FROM stdin;
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: jarvis
--

COPY public.audit_logs (id, user_id, username, action, action_category, target_type, target_id, target_name, method, endpoint, request_data, response_status, response_message, ip_address, user_agent, duration_ms, success, error_message, "timestamp", metadata_json) FROM stdin;
\.


--
-- Data for Name: builder_checkpoints; Type: TABLE DATA; Schema: public; Owner: jarvis
--

COPY public.builder_checkpoints (id, project_id, stage, step_name, message, context, preview_data, status, user_response, user_feedback, responded_at, created_at) FROM stdin;
\.


--
-- Data for Name: builder_pages; Type: TABLE DATA; Schema: public; Owner: jarvis
--

COPY public.builder_pages (id, project_id, name, path, page_type, html_content, css_content, js_content, component_code, page_meta, is_generated, generation_prompt, generated_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: builder_projects; Type: TABLE DATA; Schema: public; Owner: jarvis
--

COPY public.builder_projects (id, name, description, domain, preview_domain, status, tech_stack, project_path, plan, features, generated_files, ai_messages, current_step, error_message, build_logs, created_at, updated_at, deployed_at) FROM stdin;
\.


--
-- Data for Name: calendar_automations; Type: TABLE DATA; Schema: public; Owner: jarvis
--

COPY public.calendar_automations (id, name, description, calendar_id, event_keywords, ha_automation_id, ha_service_domain, ha_service_name, ha_service_data, lead_time_minutes, lag_time_minutes, status, last_triggered, trigger_count, last_error, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: chat_history; Type: TABLE DATA; Schema: public; Owner: jarvis
--

COPY public.chat_history (id, session_id, user_id, role, content, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: compose_specs; Type: TABLE DATA; Schema: public; Owner: jarvis
--

COPY public.compose_specs (id, project_id, version, yaml_content, checksum, services, networks, volumes, is_active, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: db_backup_jobs; Type: TABLE DATA; Schema: public; Owner: jarvis
--

COPY public.db_backup_jobs (id, db_name, backup_type, status, storage_path, file_size, compression, error_message, backup_metadata, created_at, started_at, completed_at) FROM stdin;
\.


--
-- Data for Name: db_credentials; Type: TABLE DATA; Schema: public; Owner: jarvis
--

COPY public.db_credentials (id, db_name, username, password_hash, host, port, connection_string, is_active, last_tested_at, test_status, credential_metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: deployed_apps; Type: TABLE DATA; Schema: public; Owner: jarvis
--

COPY public.deployed_apps (id, app_id, container_name, domain, port, env_vars, status, health_status, deployed_at, last_check, error_message) FROM stdin;
\.


--
-- Data for Name: deployment_logs; Type: TABLE DATA; Schema: public; Owner: jarvis
--

COPY public.deployment_logs (id, deployment_id, level, message, step, "timestamp", metadata_json) FROM stdin;
\.


--
-- Data for Name: deployment_queue; Type: TABLE DATA; Schema: public; Owner: jarvis
--

COPY public.deployment_queue (id, deployment_id, template_id, category, app_name, status, progress, current_step, total_steps, current_step_number, variables, compose_path, container_id, container_name, started_by, celery_task_id, rollback_available, rollback_snapshot, previous_state, error_message, error_details, logs, created_at, started_at, completed_at, metadata_json) FROM stdin;
\.


--
-- Data for Name: deployments; Type: TABLE DATA; Schema: public; Owner: jarvis
--

COPY public.deployments (id, workflow_id, artifact_id, service_name, service_type, domain, status, deployed_at, configuration, health_status, last_health_check, rollout_strategy, previous_deployment_id, ssl_certificate_id, compose_spec_id, health_check_url, health_check_status) FROM stdin;
\.


--
-- Data for Name: domain_records; Type: TABLE DATA; Schema: public; Owner: jarvis
--

COPY public.domain_records (id, deployment_id, domain, subdomain, record_type, record_value, ttl, auto_managed, dns_provider, status, verified_at, metadata, managed_by, verification_token, priority, provider, provider_record_id, last_verified) FROM stdin;
\.


--
-- Data for Name: drive_backups; Type: TABLE DATA; Schema: public; Owner: jarvis
--

COPY public.drive_backups (id, drive_file_id, file_name, description, file_size, local_path, drive_folder_id, status, uploaded_at, web_view_link, backup_type, retention_days, auto_delete_at, deleted, error_message, metadata, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: email_notifications; Type: TABLE DATA; Schema: public; Owner: jarvis
--

COPY public.email_notifications (id, recipient, subject, template_type, status, gmail_message_id, gmail_thread_id, sent_at, error_message, retry_count, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: game_sessions; Type: TABLE DATA; Schema: public; Owner: jarvis
--

COPY public.game_sessions (id, session_type, user_id, host_ip, host_name, status, client_device, resolution, fps, bitrate_mbps, latency_ms, game_name, game_metadata, started_at, ended_at, host_id, app_name, avg_bitrate, avg_fps, avg_latency, dropped_frames_pct, session_outcome) FROM stdin;
\.


--
-- Data for Name: google_service_status; Type: TABLE DATA; Schema: public; Owner: jarvis
--

COPY public.google_service_status (id, service_name, status, last_connected, last_error, error_count, connection_metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: license_activations; Type: TABLE DATA; Schema: public; Owner: jarvis
--

COPY public.license_activations (id, subscription_id, server_id, server_hostname, server_ip, activated_at, last_verified, active) FROM stdin;
\.


--
-- Data for Name: marketplace_apps; Type: TABLE DATA; Schema: public; Owner: jarvis
--

COPY public.marketplace_apps (id, slug, name, category, description, long_description, icon_url, screenshot_url, docker_image, default_port, requires_database, db_type, config_template, env_template, popularity, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: marketplace_deployments; Type: TABLE DATA; Schema: public; Owner: jarvis
--

COPY public.marketplace_deployments (id, template_id, category, variables, compose_path, status, error_message, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: model_usage; Type: TABLE DATA; Schema: public; Owner: jarvis
--

COPY public.model_usage (id, model_id, provider, request_type, prompt_tokens, completion_tokens, total_tokens, estimated_cost_usd, response_time_ms, success, error_message, user_id, session_id, "timestamp", year_month, metadata_json) FROM stdin;
\.


--
-- Data for Name: nas_backup_jobs; Type: TABLE DATA; Schema: public; Owner: jarvis
--

COPY public.nas_backup_jobs (id, source_path, dest_share, backup_name, status, error_message, created_at, completed_at) FROM stdin;
\.


--
-- Data for Name: nas_mounts; Type: TABLE DATA; Schema: public; Owner: jarvis
--

COPY public.nas_mounts (id, share_name, mount_point, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: plex_import_items; Type: TABLE DATA; Schema: public; Owner: jarvis
--

COPY public.plex_import_items (id, job_id, filename, original_filename, file_size, mime_type, storage_path, final_path, status, item_metadata, error_message, created_at, processed_at) FROM stdin;
\.


--
-- Data for Name: plex_import_jobs; Type: TABLE DATA; Schema: public; Owner: jarvis
--

COPY public.plex_import_jobs (id, user_id, job_type, status, total_files, processed_files, target_directory, job_metadata, error_message, created_at, updated_at, completed_at) FROM stdin;
\.


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: jarvis
--

COPY public.projects (id, name, path, project_type, framework, detected_at, last_scanned, config, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: remediation_history; Type: TABLE DATA; Schema: public; Owner: jarvis
--

COPY public.remediation_history (id, service_name, container_name, trigger_type, trigger_details, issue_summary, ai_diagnosis, ai_plan, ai_model_used, actions_taken, actions_count, status, success, result_message, logs_before, logs_after, initiated_by, is_automatic, started_at, completed_at, duration_seconds, rollback_available, rollback_data, metadata_json) FROM stdin;
\.


--
-- Data for Name: request_queue; Type: TABLE DATA; Schema: public; Owner: jarvis
--

COPY public.request_queue (id, request_type, user_id, session_id, query, context, preferred_model, priority, status, response, error_message, retry_count, max_retries, created_at, processed_at, expires_at, callback_url, metadata_json) FROM stdin;
\.


--
-- Data for Name: response_cache; Type: TABLE DATA; Schema: public; Owner: jarvis
--

COPY public.response_cache (id, query_hash, query_pattern, query_category, original_query, response, response_model, hit_count, last_hit_at, quality_score, is_verified, verified_by, verified_at, expires_at, created_at, updated_at, metadata_json) FROM stdin;
\.


--
-- Data for Name: role_assignments; Type: TABLE DATA; Schema: public; Owner: jarvis
--

COPY public.role_assignments (id, user_id, previous_role, new_role, assigned_by, reason, assigned_at) FROM stdin;
\.


--
-- Data for Name: service_configs; Type: TABLE DATA; Schema: public; Owner: jarvis
--

COPY public.service_configs (id, service_name, display_name, description, container_name, image_name, image_tag, category, ports, volumes, environment, labels, health_check_url, health_check_interval, health_check_timeout, restart_policy, max_restarts, dependencies, is_enabled, is_critical, public_url, internal_url, created_at, updated_at, metadata_json) FROM stdin;
1	discord-bot	Discord Ticket Bot	Discord ticket system with web dashboard	discord-bot	\N	\N	bots	\N	\N	\N	\N	\N	60	10	unless-stopped	3	\N	t	f	https://bot.rig-city.com	\N	2025-12-04 07:16:30.895059	\N	\N
2	stream-bot	Stream Bot	AI-powered Snapple facts for Twitch and Kick	stream-bot	\N	\N	bots	\N	\N	\N	\N	\N	60	10	unless-stopped	3	\N	t	f	https://stream.rig-city.com	\N	2025-12-04 07:16:30.895059	\N	\N
3	homelab-dashboard	Homelab Dashboard	Central control panel for homelab services	homelab-dashboard	\N	\N	infrastructure	\N	\N	\N	\N	\N	30	10	unless-stopped	3	\N	t	t	https://host.evindrake.net	\N	2025-12-04 07:16:30.895059	\N	\N
4	homelab-postgres	PostgreSQL Database	Main database for homelab services	homelab-postgres	\N	\N	database	\N	\N	\N	\N	\N	30	10	unless-stopped	3	\N	t	t	\N	\N	2025-12-04 07:16:30.895059	\N	\N
5	redis	Redis Cache	In-memory cache and message broker	homelab-redis	\N	\N	database	\N	\N	\N	\N	\N	30	10	unless-stopped	3	\N	t	t	\N	\N	2025-12-04 07:16:30.895059	\N	\N
6	caddy	Caddy Reverse Proxy	Web server and reverse proxy with automatic HTTPS	caddy	\N	\N	infrastructure	\N	\N	\N	\N	\N	30	10	unless-stopped	3	\N	t	t	\N	\N	2025-12-04 07:16:30.895059	\N	\N
7	plex	Plex Media Server	Media streaming server	plex-server	\N	\N	media	\N	\N	\N	\N	\N	120	10	unless-stopped	3	\N	t	f	https://plex.evindrake.net	\N	2025-12-04 07:16:30.895059	\N	\N
8	n8n	n8n Automation	Workflow automation platform	n8n	\N	\N	automation	\N	\N	\N	\N	\N	60	10	unless-stopped	3	\N	t	f	https://n8n.evindrake.net	\N	2025-12-04 07:16:30.895059	\N	\N
9	homeassistant	Home Assistant	Smart home automation platform	homeassistant	\N	\N	automation	\N	\N	\N	\N	\N	60	10	unless-stopped	3	\N	t	f	https://home.evindrake.net	http://homeassistant:8123	2025-12-04 07:16:30.895059	\N	\N
10	vnc-desktop	VNC Desktop	Remote desktop access	vnc-desktop	\N	\N	utilities	\N	\N	\N	\N	\N	120	10	unless-stopped	3	\N	t	f	https://vnc.evindrake.net	\N	2025-12-04 07:16:30.895059	\N	\N
\.


--
-- Data for Name: service_dependencies; Type: TABLE DATA; Schema: public; Owner: jarvis
--

COPY public.service_dependencies (id, service_name, depends_on, dependency_type, startup_order, health_check_required, timeout_seconds, created_at) FROM stdin;
1	homelab-dashboard	homelab-postgres	required	1	t	60	2025-12-04 07:16:30.895059
2	homelab-dashboard	redis	required	2	t	60	2025-12-04 07:16:30.895059
3	discord-bot	homelab-postgres	required	1	t	60	2025-12-04 07:16:30.895059
4	stream-bot	homelab-postgres	required	1	t	60	2025-12-04 07:16:30.895059
5	stream-bot	redis	optional	2	t	60	2025-12-04 07:16:30.895059
\.


--
-- Data for Name: service_health_alerts; Type: TABLE DATA; Schema: public; Owner: jarvis
--

COPY public.service_health_alerts (id, service_name, severity, message, status, triggered_at, resolved_at) FROM stdin;
\.


--
-- Data for Name: service_health_checks; Type: TABLE DATA; Schema: public; Owner: jarvis
--

COPY public.service_health_checks (id, service_name, status, checks, response_time_ms, "timestamp") FROM stdin;
\.


--
-- Data for Name: service_ownerships; Type: TABLE DATA; Schema: public; Owner: jarvis
--

COPY public.service_ownerships (id, user_id, service_name, container_name, permission_level, granted_at, granted_by, notes) FROM stdin;
\.


--
-- Data for Name: service_settings; Type: TABLE DATA; Schema: public; Owner: jarvis
--

COPY public.service_settings (id, service_id, key, value, value_type, is_secret, is_required, description, default_value, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: service_telemetry; Type: TABLE DATA; Schema: public; Owner: jarvis
--

COPY public.service_telemetry (id, service_name, container_id, status, cpu_percent, memory_usage, memory_limit, network_rx, network_tx, health_status, restart_count, uptime_seconds, service_metadata, "timestamp") FROM stdin;
\.


--
-- Data for Name: ssl_certificates; Type: TABLE DATA; Schema: public; Owner: jarvis
--

COPY public.ssl_certificates (id, domain, status, provider, cert_path, key_path, chain_path, issued_at, expires_at, auto_renew, last_renewal_attempt, renewal_logs, cert_metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: storage_alerts; Type: TABLE DATA; Schema: public; Owner: jarvis
--

COPY public.storage_alerts (id, metric_type, metric_name, threshold_percent, alert_enabled, last_alerted_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: storage_metrics; Type: TABLE DATA; Schema: public; Owner: jarvis
--

COPY public.storage_metrics (id, metric_type, metric_name, path, size_bytes, file_count, usage_percent, storage_metadata, "timestamp") FROM stdin;
\.


--
-- Data for Name: subscriptions; Type: TABLE DATA; Schema: public; Owner: jarvis
--

COPY public.subscriptions (id, user_email, license_key, tier, status, amount_cents, currency, billing_interval, trial_ends_at, current_period_start, current_period_end, canceled_at, created_at, updated_at, max_servers, ai_requests_per_month, marketplace_deployments, priority_support, white_label, stripe_customer_id, stripe_subscription_id) FROM stdin;
\.


--
-- Data for Name: sunshine_hosts; Type: TABLE DATA; Schema: public; Owner: jarvis
--

COPY public.sunshine_hosts (id, host_ip, host_name, api_url, is_paired, pairing_pin, last_online, gpu_model, applications, host_metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: system_logs; Type: TABLE DATA; Schema: public; Owner: jarvis
--

COPY public.system_logs (id, source, source_type, level, category, message, details, container_id, container_name, host, process_id, stack_trace, error_code, cpu_percent, memory_percent, disk_percent, "timestamp", year_month, metadata_json) FROM stdin;
\.


--
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: jarvis
--

COPY public.system_settings (id, key, value, category, description, is_secret, is_required, last_validated, validation_status, validation_message, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: jarvis
--

COPY public.tasks (id, workflow_id, title, description, task_type, status, priority, assigned_to, instructions, created_at, completed_at, metadata) FROM stdin;
\.


--
-- Data for Name: unified_logs; Type: TABLE DATA; Schema: public; Owner: jarvis
--

COPY public.unified_logs (id, service, container_id, log_level, message, "timestamp", extra_metadata) FROM stdin;
\.


--
-- Data for Name: usage_metrics; Type: TABLE DATA; Schema: public; Owner: jarvis
--

COPY public.usage_metrics (id, subscription_id, metric_type, count, period_start, period_end) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: jarvis
--

COPY public.users (id, username, email, role, is_active, created_at, updated_at, last_login, metadata_json) FROM stdin;
\.


--
-- Data for Name: workflows; Type: TABLE DATA; Schema: public; Owner: jarvis
--

COPY public.workflows (id, name, status, workflow_type, created_by, started_at, completed_at, error_message, metadata, current_step, total_steps) FROM stdin;
\.


--
-- Name: activity_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jarvis
--

SELECT pg_catalog.setval('public.activity_logs_id_seq', 1, false);


--
-- Name: agent_conversations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jarvis
--

SELECT pg_catalog.setval('public.agent_conversations_id_seq', 1, false);


--
-- Name: agent_tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jarvis
--

SELECT pg_catalog.setval('public.agent_tasks_id_seq', 1, false);


--
-- Name: anomaly_baselines_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jarvis
--

SELECT pg_catalog.setval('public.anomaly_baselines_id_seq', 1, false);


--
-- Name: anomaly_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jarvis
--

SELECT pg_catalog.setval('public.anomaly_events_id_seq', 1, false);


--
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jarvis
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 1, false);


--
-- Name: deployed_apps_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jarvis
--

SELECT pg_catalog.setval('public.deployed_apps_id_seq', 1, false);


--
-- Name: deployment_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jarvis
--

SELECT pg_catalog.setval('public.deployment_logs_id_seq', 1, false);


--
-- Name: deployment_queue_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jarvis
--

SELECT pg_catalog.setval('public.deployment_queue_id_seq', 1, false);


--
-- Name: license_activations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jarvis
--

SELECT pg_catalog.setval('public.license_activations_id_seq', 1, false);


--
-- Name: marketplace_apps_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jarvis
--

SELECT pg_catalog.setval('public.marketplace_apps_id_seq', 1, false);


--
-- Name: model_usage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jarvis
--

SELECT pg_catalog.setval('public.model_usage_id_seq', 1, false);


--
-- Name: nas_backup_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jarvis
--

SELECT pg_catalog.setval('public.nas_backup_jobs_id_seq', 1, false);


--
-- Name: nas_mounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jarvis
--

SELECT pg_catalog.setval('public.nas_mounts_id_seq', 1, false);


--
-- Name: remediation_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jarvis
--

SELECT pg_catalog.setval('public.remediation_history_id_seq', 1, false);


--
-- Name: request_queue_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jarvis
--

SELECT pg_catalog.setval('public.request_queue_id_seq', 1, false);


--
-- Name: response_cache_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jarvis
--

SELECT pg_catalog.setval('public.response_cache_id_seq', 1, false);


--
-- Name: role_assignments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jarvis
--

SELECT pg_catalog.setval('public.role_assignments_id_seq', 1, false);


--
-- Name: service_configs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jarvis
--

SELECT pg_catalog.setval('public.service_configs_id_seq', 10, true);


--
-- Name: service_dependencies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jarvis
--

SELECT pg_catalog.setval('public.service_dependencies_id_seq', 5, true);


--
-- Name: service_health_alerts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jarvis
--

SELECT pg_catalog.setval('public.service_health_alerts_id_seq', 1, false);


--
-- Name: service_health_checks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jarvis
--

SELECT pg_catalog.setval('public.service_health_checks_id_seq', 1, false);


--
-- Name: service_ownerships_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jarvis
--

SELECT pg_catalog.setval('public.service_ownerships_id_seq', 1, false);


--
-- Name: service_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jarvis
--

SELECT pg_catalog.setval('public.service_settings_id_seq', 1, false);


--
-- Name: subscriptions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jarvis
--

SELECT pg_catalog.setval('public.subscriptions_id_seq', 1, false);


--
-- Name: system_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jarvis
--

SELECT pg_catalog.setval('public.system_logs_id_seq', 1, false);


--
-- Name: system_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jarvis
--

SELECT pg_catalog.setval('public.system_settings_id_seq', 1, false);


--
-- Name: unified_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jarvis
--

SELECT pg_catalog.setval('public.unified_logs_id_seq', 1, false);


--
-- Name: usage_metrics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jarvis
--

SELECT pg_catalog.setval('public.usage_metrics_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jarvis
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: activity_logs activity_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.activity_logs
    ADD CONSTRAINT activity_logs_pkey PRIMARY KEY (id);


--
-- Name: agent_conversations agent_conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.agent_conversations
    ADD CONSTRAINT agent_conversations_pkey PRIMARY KEY (id);


--
-- Name: agent_messages agent_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.agent_messages
    ADD CONSTRAINT agent_messages_pkey PRIMARY KEY (id);


--
-- Name: agent_tasks agent_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.agent_tasks
    ADD CONSTRAINT agent_tasks_pkey PRIMARY KEY (id);


--
-- Name: agents agents_name_key; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_name_key UNIQUE (name);


--
-- Name: agents agents_pkey; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_pkey PRIMARY KEY (id);


--
-- Name: ai_sessions ai_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.ai_sessions
    ADD CONSTRAINT ai_sessions_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: anomaly_baselines anomaly_baselines_pkey; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.anomaly_baselines
    ADD CONSTRAINT anomaly_baselines_pkey PRIMARY KEY (id);


--
-- Name: anomaly_events anomaly_events_pkey; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.anomaly_events
    ADD CONSTRAINT anomaly_events_pkey PRIMARY KEY (id);


--
-- Name: artifact_builds artifact_builds_pkey; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.artifact_builds
    ADD CONSTRAINT artifact_builds_pkey PRIMARY KEY (id);


--
-- Name: artifacts artifacts_pkey; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.artifacts
    ADD CONSTRAINT artifacts_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: builder_checkpoints builder_checkpoints_pkey; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.builder_checkpoints
    ADD CONSTRAINT builder_checkpoints_pkey PRIMARY KEY (id);


--
-- Name: builder_pages builder_pages_pkey; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.builder_pages
    ADD CONSTRAINT builder_pages_pkey PRIMARY KEY (id);


--
-- Name: builder_projects builder_projects_pkey; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.builder_projects
    ADD CONSTRAINT builder_projects_pkey PRIMARY KEY (id);


--
-- Name: calendar_automations calendar_automations_pkey; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.calendar_automations
    ADD CONSTRAINT calendar_automations_pkey PRIMARY KEY (id);


--
-- Name: chat_history chat_history_pkey; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.chat_history
    ADD CONSTRAINT chat_history_pkey PRIMARY KEY (id);


--
-- Name: compose_specs compose_specs_pkey; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.compose_specs
    ADD CONSTRAINT compose_specs_pkey PRIMARY KEY (id);


--
-- Name: db_backup_jobs db_backup_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.db_backup_jobs
    ADD CONSTRAINT db_backup_jobs_pkey PRIMARY KEY (id);


--
-- Name: db_credentials db_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.db_credentials
    ADD CONSTRAINT db_credentials_pkey PRIMARY KEY (id);


--
-- Name: deployed_apps deployed_apps_pkey; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.deployed_apps
    ADD CONSTRAINT deployed_apps_pkey PRIMARY KEY (id);


--
-- Name: deployment_logs deployment_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.deployment_logs
    ADD CONSTRAINT deployment_logs_pkey PRIMARY KEY (id);


--
-- Name: deployment_queue deployment_queue_pkey; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.deployment_queue
    ADD CONSTRAINT deployment_queue_pkey PRIMARY KEY (id);


--
-- Name: deployments deployments_pkey; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.deployments
    ADD CONSTRAINT deployments_pkey PRIMARY KEY (id);


--
-- Name: domain_records domain_records_pkey; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.domain_records
    ADD CONSTRAINT domain_records_pkey PRIMARY KEY (id);


--
-- Name: drive_backups drive_backups_drive_file_id_key; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.drive_backups
    ADD CONSTRAINT drive_backups_drive_file_id_key UNIQUE (drive_file_id);


--
-- Name: drive_backups drive_backups_pkey; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.drive_backups
    ADD CONSTRAINT drive_backups_pkey PRIMARY KEY (id);


--
-- Name: email_notifications email_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.email_notifications
    ADD CONSTRAINT email_notifications_pkey PRIMARY KEY (id);


--
-- Name: game_sessions game_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.game_sessions
    ADD CONSTRAINT game_sessions_pkey PRIMARY KEY (id);


--
-- Name: google_service_status google_service_status_pkey; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.google_service_status
    ADD CONSTRAINT google_service_status_pkey PRIMARY KEY (id);


--
-- Name: google_service_status google_service_status_service_name_key; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.google_service_status
    ADD CONSTRAINT google_service_status_service_name_key UNIQUE (service_name);


--
-- Name: license_activations license_activations_pkey; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.license_activations
    ADD CONSTRAINT license_activations_pkey PRIMARY KEY (id);


--
-- Name: marketplace_apps marketplace_apps_pkey; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.marketplace_apps
    ADD CONSTRAINT marketplace_apps_pkey PRIMARY KEY (id);


--
-- Name: marketplace_deployments marketplace_deployments_pkey; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.marketplace_deployments
    ADD CONSTRAINT marketplace_deployments_pkey PRIMARY KEY (id);


--
-- Name: model_usage model_usage_pkey; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.model_usage
    ADD CONSTRAINT model_usage_pkey PRIMARY KEY (id);


--
-- Name: nas_backup_jobs nas_backup_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.nas_backup_jobs
    ADD CONSTRAINT nas_backup_jobs_pkey PRIMARY KEY (id);


--
-- Name: nas_mounts nas_mounts_pkey; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.nas_mounts
    ADD CONSTRAINT nas_mounts_pkey PRIMARY KEY (id);


--
-- Name: plex_import_items plex_import_items_pkey; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.plex_import_items
    ADD CONSTRAINT plex_import_items_pkey PRIMARY KEY (id);


--
-- Name: plex_import_jobs plex_import_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.plex_import_jobs
    ADD CONSTRAINT plex_import_jobs_pkey PRIMARY KEY (id);


--
-- Name: projects projects_name_key; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_name_key UNIQUE (name);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: remediation_history remediation_history_pkey; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.remediation_history
    ADD CONSTRAINT remediation_history_pkey PRIMARY KEY (id);


--
-- Name: request_queue request_queue_pkey; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.request_queue
    ADD CONSTRAINT request_queue_pkey PRIMARY KEY (id);


--
-- Name: response_cache response_cache_pkey; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.response_cache
    ADD CONSTRAINT response_cache_pkey PRIMARY KEY (id);


--
-- Name: role_assignments role_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.role_assignments
    ADD CONSTRAINT role_assignments_pkey PRIMARY KEY (id);


--
-- Name: service_configs service_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.service_configs
    ADD CONSTRAINT service_configs_pkey PRIMARY KEY (id);


--
-- Name: service_dependencies service_dependencies_pkey; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.service_dependencies
    ADD CONSTRAINT service_dependencies_pkey PRIMARY KEY (id);


--
-- Name: service_health_alerts service_health_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.service_health_alerts
    ADD CONSTRAINT service_health_alerts_pkey PRIMARY KEY (id);


--
-- Name: service_health_checks service_health_checks_pkey; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.service_health_checks
    ADD CONSTRAINT service_health_checks_pkey PRIMARY KEY (id);


--
-- Name: service_ownerships service_ownerships_pkey; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.service_ownerships
    ADD CONSTRAINT service_ownerships_pkey PRIMARY KEY (id);


--
-- Name: service_settings service_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.service_settings
    ADD CONSTRAINT service_settings_pkey PRIMARY KEY (id);


--
-- Name: service_telemetry service_telemetry_pkey; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.service_telemetry
    ADD CONSTRAINT service_telemetry_pkey PRIMARY KEY (id);


--
-- Name: ssl_certificates ssl_certificates_domain_key; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.ssl_certificates
    ADD CONSTRAINT ssl_certificates_domain_key UNIQUE (domain);


--
-- Name: ssl_certificates ssl_certificates_pkey; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.ssl_certificates
    ADD CONSTRAINT ssl_certificates_pkey PRIMARY KEY (id);


--
-- Name: storage_alerts storage_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.storage_alerts
    ADD CONSTRAINT storage_alerts_pkey PRIMARY KEY (id);


--
-- Name: storage_metrics storage_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.storage_metrics
    ADD CONSTRAINT storage_metrics_pkey PRIMARY KEY (id);


--
-- Name: subscriptions subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_pkey PRIMARY KEY (id);


--
-- Name: sunshine_hosts sunshine_hosts_host_ip_key; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.sunshine_hosts
    ADD CONSTRAINT sunshine_hosts_host_ip_key UNIQUE (host_ip);


--
-- Name: sunshine_hosts sunshine_hosts_pkey; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.sunshine_hosts
    ADD CONSTRAINT sunshine_hosts_pkey PRIMARY KEY (id);


--
-- Name: system_logs system_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.system_logs
    ADD CONSTRAINT system_logs_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: unified_logs unified_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.unified_logs
    ADD CONSTRAINT unified_logs_pkey PRIMARY KEY (id);


--
-- Name: nas_mounts uq_nas_mounts_mount_point; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.nas_mounts
    ADD CONSTRAINT uq_nas_mounts_mount_point UNIQUE (mount_point);


--
-- Name: nas_mounts uq_nas_mounts_share_name; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.nas_mounts
    ADD CONSTRAINT uq_nas_mounts_share_name UNIQUE (share_name);


--
-- Name: usage_metrics usage_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.usage_metrics
    ADD CONSTRAINT usage_metrics_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: workflows workflows_pkey; Type: CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.workflows
    ADD CONSTRAINT workflows_pkey PRIMARY KEY (id);


--
-- Name: idx_agent_conversations_task; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX idx_agent_conversations_task ON public.agent_conversations USING btree (task_id);


--
-- Name: idx_agent_conversations_timestamp; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX idx_agent_conversations_timestamp ON public.agent_conversations USING btree ("timestamp");


--
-- Name: idx_agent_messages_from_agent; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX idx_agent_messages_from_agent ON public.agent_messages USING btree (from_agent_id);


--
-- Name: idx_agent_messages_priority; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX idx_agent_messages_priority ON public.agent_messages USING btree (priority, created_at);


--
-- Name: idx_agent_messages_status; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX idx_agent_messages_status ON public.agent_messages USING btree (status);


--
-- Name: idx_agent_messages_to_agent; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX idx_agent_messages_to_agent ON public.agent_messages USING btree (to_agent_id);


--
-- Name: idx_agent_tasks_agent; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX idx_agent_tasks_agent ON public.agent_tasks USING btree (assigned_agent_id);


--
-- Name: idx_agent_tasks_created; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX idx_agent_tasks_created ON public.agent_tasks USING btree (created_at);


--
-- Name: idx_agent_tasks_priority; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX idx_agent_tasks_priority ON public.agent_tasks USING btree (priority);


--
-- Name: idx_agent_tasks_status; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX idx_agent_tasks_status ON public.agent_tasks USING btree (status);


--
-- Name: idx_agents_status; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX idx_agents_status ON public.agents USING btree (status);


--
-- Name: idx_agents_type; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX idx_agents_type ON public.agents USING btree (agent_type);


--
-- Name: idx_ai_sessions_created; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX idx_ai_sessions_created ON public.ai_sessions USING btree (created_at);


--
-- Name: idx_ai_sessions_state; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX idx_ai_sessions_state ON public.ai_sessions USING btree (state);


--
-- Name: idx_ai_sessions_user; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX idx_ai_sessions_user ON public.ai_sessions USING btree (user_id);


--
-- Name: idx_alert_service_status; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX idx_alert_service_status ON public.service_health_alerts USING btree (service_name, status);


--
-- Name: idx_alert_triggered; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX idx_alert_triggered ON public.service_health_alerts USING btree (triggered_at);


--
-- Name: idx_artifact_builds_created; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX idx_artifact_builds_created ON public.artifact_builds USING btree (created_at);


--
-- Name: idx_artifact_builds_project; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX idx_artifact_builds_project ON public.artifact_builds USING btree (project_id);


--
-- Name: idx_artifact_builds_status; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX idx_artifact_builds_status ON public.artifact_builds USING btree (status);


--
-- Name: idx_chat_history_session; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX idx_chat_history_session ON public.chat_history USING btree (session_id, created_at);


--
-- Name: idx_compose_specs_active; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX idx_compose_specs_active ON public.compose_specs USING btree (is_active);


--
-- Name: idx_compose_specs_project; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX idx_compose_specs_project ON public.compose_specs USING btree (project_id);


--
-- Name: idx_compose_specs_version; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX idx_compose_specs_version ON public.compose_specs USING btree (project_id, version);


--
-- Name: idx_deployments_health; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX idx_deployments_health ON public.deployments USING btree (health_check_status);


--
-- Name: idx_deployments_rollout; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX idx_deployments_rollout ON public.deployments USING btree (rollout_strategy);


--
-- Name: idx_domain_records_managed_by; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX idx_domain_records_managed_by ON public.domain_records USING btree (managed_by);


--
-- Name: idx_domain_records_provider; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX idx_domain_records_provider ON public.domain_records USING btree (provider);


--
-- Name: idx_game_sessions_host_id; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX idx_game_sessions_host_id ON public.game_sessions USING btree (host_id);


--
-- Name: idx_game_sessions_started_at; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX idx_game_sessions_started_at ON public.game_sessions USING btree (started_at);


--
-- Name: idx_game_sessions_status; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX idx_game_sessions_status ON public.game_sessions USING btree (status);


--
-- Name: idx_log_level; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX idx_log_level ON public.unified_logs USING btree (log_level);


--
-- Name: idx_log_level_timestamp; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX idx_log_level_timestamp ON public.unified_logs USING btree (log_level, "timestamp");


--
-- Name: idx_message_fulltext; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX idx_message_fulltext ON public.unified_logs USING gin (to_tsvector('english'::regconfig, message));


--
-- Name: idx_projects_name; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX idx_projects_name ON public.projects USING btree (name);


--
-- Name: idx_projects_status; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX idx_projects_status ON public.projects USING btree (status);


--
-- Name: idx_service; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX idx_service ON public.unified_logs USING btree (service);


--
-- Name: idx_service_level_timestamp; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX idx_service_level_timestamp ON public.unified_logs USING btree (service, log_level, "timestamp");


--
-- Name: idx_service_timestamp; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX idx_service_timestamp ON public.service_health_checks USING btree (service_name, "timestamp");


--
-- Name: idx_ssl_certificates_auto_renew; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX idx_ssl_certificates_auto_renew ON public.ssl_certificates USING btree (auto_renew);


--
-- Name: idx_ssl_certificates_domain; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX idx_ssl_certificates_domain ON public.ssl_certificates USING btree (domain);


--
-- Name: idx_ssl_certificates_expires; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX idx_ssl_certificates_expires ON public.ssl_certificates USING btree (expires_at);


--
-- Name: idx_status_timestamp; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX idx_status_timestamp ON public.service_health_checks USING btree (status, "timestamp");


--
-- Name: idx_timestamp; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX idx_timestamp ON public.unified_logs USING btree ("timestamp");


--
-- Name: idx_unified_logs_service_timestamp; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX idx_unified_logs_service_timestamp ON public.unified_logs USING btree (service, "timestamp");


--
-- Name: ix_activity_action; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_activity_action ON public.activity_logs USING btree (action);


--
-- Name: ix_activity_resource; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_activity_resource ON public.activity_logs USING btree (resource_type, resource_id);


--
-- Name: ix_activity_resource_id; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_activity_resource_id ON public.activity_logs USING btree (resource_id);


--
-- Name: ix_activity_resource_type; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_activity_resource_type ON public.activity_logs USING btree (resource_type);


--
-- Name: ix_activity_session; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_activity_session ON public.activity_logs USING btree (session_id);


--
-- Name: ix_activity_timestamp; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_activity_timestamp ON public.activity_logs USING btree ("timestamp");


--
-- Name: ix_activity_type; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_activity_type ON public.activity_logs USING btree (activity_type);


--
-- Name: ix_activity_type_timestamp; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_activity_type_timestamp ON public.activity_logs USING btree (activity_type, "timestamp");


--
-- Name: ix_activity_user_id; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_activity_user_id ON public.activity_logs USING btree (user_id);


--
-- Name: ix_activity_user_timestamp; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_activity_user_timestamp ON public.activity_logs USING btree (user_id, "timestamp");


--
-- Name: ix_activity_year_month; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_activity_year_month ON public.activity_logs USING btree (year_month);


--
-- Name: ix_agent_conversations_from_agent_id; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_agent_conversations_from_agent_id ON public.agent_conversations USING btree (from_agent_id);


--
-- Name: ix_agent_conversations_task_id; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_agent_conversations_task_id ON public.agent_conversations USING btree (task_id);


--
-- Name: ix_agent_conversations_to_agent_id; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_agent_conversations_to_agent_id ON public.agent_conversations USING btree (to_agent_id);


--
-- Name: ix_agent_tasks_assigned_agent_id; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_agent_tasks_assigned_agent_id ON public.agent_tasks USING btree (assigned_agent_id);


--
-- Name: ix_agent_tasks_completed_at; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_agent_tasks_completed_at ON public.agent_tasks USING btree (completed_at);


--
-- Name: ix_agent_tasks_created_at; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_agent_tasks_created_at ON public.agent_tasks USING btree (created_at);


--
-- Name: ix_agent_tasks_parent_task_id; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_agent_tasks_parent_task_id ON public.agent_tasks USING btree (parent_task_id);


--
-- Name: ix_agent_tasks_started_at; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_agent_tasks_started_at ON public.agent_tasks USING btree (started_at);


--
-- Name: ix_agent_tasks_status_created_at; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_agent_tasks_status_created_at ON public.agent_tasks USING btree (status, created_at);


--
-- Name: ix_agent_tasks_status_priority; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_agent_tasks_status_priority ON public.agent_tasks USING btree (status, priority);


--
-- Name: ix_anomaly_metric; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_anomaly_metric ON public.anomaly_events USING btree (metric_name);


--
-- Name: ix_anomaly_remediation; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_anomaly_remediation ON public.anomaly_events USING btree (remediation_id);


--
-- Name: ix_anomaly_service; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_anomaly_service ON public.anomaly_events USING btree (service_name);


--
-- Name: ix_anomaly_service_timestamp; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_anomaly_service_timestamp ON public.anomaly_events USING btree (service_name, "timestamp");


--
-- Name: ix_anomaly_severity; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_anomaly_severity ON public.anomaly_events USING btree (severity);


--
-- Name: ix_anomaly_severity_timestamp; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_anomaly_severity_timestamp ON public.anomaly_events USING btree (severity, "timestamp");


--
-- Name: ix_anomaly_timestamp; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_anomaly_timestamp ON public.anomaly_events USING btree ("timestamp");


--
-- Name: ix_anomaly_unacked; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_anomaly_unacked ON public.anomaly_events USING btree (is_acknowledged, "timestamp");


--
-- Name: ix_artifacts_analysis_status; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_artifacts_analysis_status ON public.artifacts USING btree (analysis_status);


--
-- Name: ix_audit_logs_action; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_audit_logs_action ON public.audit_logs USING btree (action);


--
-- Name: ix_audit_logs_action_category; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_audit_logs_action_category ON public.audit_logs USING btree (action_category);


--
-- Name: ix_audit_logs_target_id; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_audit_logs_target_id ON public.audit_logs USING btree (target_id);


--
-- Name: ix_audit_logs_timestamp; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_audit_logs_timestamp ON public.audit_logs USING btree ("timestamp");


--
-- Name: ix_audit_logs_user_id; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_audit_logs_user_id ON public.audit_logs USING btree (user_id);


--
-- Name: ix_audit_target; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_audit_target ON public.audit_logs USING btree (target_type, target_id);


--
-- Name: ix_audit_timestamp_user; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_audit_timestamp_user ON public.audit_logs USING btree ("timestamp", user_id);


--
-- Name: ix_audit_user_action; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_audit_user_action ON public.audit_logs USING btree (user_id, action);


--
-- Name: ix_baseline_metric; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_baseline_metric ON public.anomaly_baselines USING btree (metric_name);


--
-- Name: ix_baseline_service; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_baseline_service ON public.anomaly_baselines USING btree (service_name);


--
-- Name: ix_baseline_service_metric; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE UNIQUE INDEX ix_baseline_service_metric ON public.anomaly_baselines USING btree (service_name, metric_name);


--
-- Name: ix_builder_checkpoints_project; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_builder_checkpoints_project ON public.builder_checkpoints USING btree (project_id);


--
-- Name: ix_builder_checkpoints_stage; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_builder_checkpoints_stage ON public.builder_checkpoints USING btree (stage);


--
-- Name: ix_builder_checkpoints_status; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_builder_checkpoints_status ON public.builder_checkpoints USING btree (status);


--
-- Name: ix_builder_pages_path; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_builder_pages_path ON public.builder_pages USING btree (path);


--
-- Name: ix_builder_pages_project; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_builder_pages_project ON public.builder_pages USING btree (project_id);


--
-- Name: ix_builder_projects_created; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_builder_projects_created ON public.builder_projects USING btree (created_at);


--
-- Name: ix_builder_projects_name; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_builder_projects_name ON public.builder_projects USING btree (name);


--
-- Name: ix_builder_projects_status; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_builder_projects_status ON public.builder_projects USING btree (status);


--
-- Name: ix_cache_expires; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_cache_expires ON public.response_cache USING btree (expires_at);


--
-- Name: ix_cache_hit_count; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_cache_hit_count ON public.response_cache USING btree (hit_count);


--
-- Name: ix_cache_query_category; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_cache_query_category ON public.response_cache USING btree (query_category);


--
-- Name: ix_cache_query_hash; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE UNIQUE INDEX ix_cache_query_hash ON public.response_cache USING btree (query_hash);


--
-- Name: ix_cache_query_pattern; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_cache_query_pattern ON public.response_cache USING btree (query_pattern);


--
-- Name: ix_calendar_automations_created_at; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_calendar_automations_created_at ON public.calendar_automations USING btree (created_at);


--
-- Name: ix_calendar_automations_created_by; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_calendar_automations_created_by ON public.calendar_automations USING btree (created_by);


--
-- Name: ix_calendar_automations_last_triggered; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_calendar_automations_last_triggered ON public.calendar_automations USING btree (last_triggered);


--
-- Name: ix_calendar_automations_status; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_calendar_automations_status ON public.calendar_automations USING btree (status);


--
-- Name: ix_calendar_automations_updated_at; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_calendar_automations_updated_at ON public.calendar_automations USING btree (updated_at);


--
-- Name: ix_db_backup_jobs_created_at; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_db_backup_jobs_created_at ON public.db_backup_jobs USING btree (created_at);


--
-- Name: ix_db_backup_jobs_db_name; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_db_backup_jobs_db_name ON public.db_backup_jobs USING btree (db_name);


--
-- Name: ix_db_backup_jobs_status; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_db_backup_jobs_status ON public.db_backup_jobs USING btree (status);


--
-- Name: ix_db_credentials_active; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_db_credentials_active ON public.db_credentials USING btree (is_active);


--
-- Name: ix_db_credentials_db_name; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_db_credentials_db_name ON public.db_credentials USING btree (db_name);


--
-- Name: ix_deployed_apps_app_id; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_deployed_apps_app_id ON public.deployed_apps USING btree (app_id);


--
-- Name: ix_deployed_apps_container_name; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE UNIQUE INDEX ix_deployed_apps_container_name ON public.deployed_apps USING btree (container_name);


--
-- Name: ix_deployed_apps_deployed_at; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_deployed_apps_deployed_at ON public.deployed_apps USING btree (deployed_at);


--
-- Name: ix_deployed_apps_health_status; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_deployed_apps_health_status ON public.deployed_apps USING btree (health_status);


--
-- Name: ix_deployed_apps_last_check; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_deployed_apps_last_check ON public.deployed_apps USING btree (last_check);


--
-- Name: ix_deployed_apps_status; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_deployed_apps_status ON public.deployed_apps USING btree (status);


--
-- Name: ix_deployment_logs_deployment_id; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_deployment_logs_deployment_id ON public.deployment_logs USING btree (deployment_id);


--
-- Name: ix_deployment_queue_celery_task_id; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_deployment_queue_celery_task_id ON public.deployment_queue USING btree (celery_task_id);


--
-- Name: ix_deployment_queue_deployment_id; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE UNIQUE INDEX ix_deployment_queue_deployment_id ON public.deployment_queue USING btree (deployment_id);


--
-- Name: ix_deployment_queue_status; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_deployment_queue_status ON public.deployment_queue USING btree (status);


--
-- Name: ix_deployments_artifact_id; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_deployments_artifact_id ON public.deployments USING btree (artifact_id);


--
-- Name: ix_deployments_deployed_at; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_deployments_deployed_at ON public.deployments USING btree (deployed_at);


--
-- Name: ix_deployments_health_status; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_deployments_health_status ON public.deployments USING btree (health_status);


--
-- Name: ix_deployments_last_health_check; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_deployments_last_health_check ON public.deployments USING btree (last_health_check);


--
-- Name: ix_deployments_status; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_deployments_status ON public.deployments USING btree (status);


--
-- Name: ix_deployments_status_health_status; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_deployments_status_health_status ON public.deployments USING btree (status, health_status);


--
-- Name: ix_deployments_workflow_id; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_deployments_workflow_id ON public.deployments USING btree (workflow_id);


--
-- Name: ix_domain_records_deployment_id; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_domain_records_deployment_id ON public.domain_records USING btree (deployment_id);


--
-- Name: ix_drive_backups_auto_delete_at; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_drive_backups_auto_delete_at ON public.drive_backups USING btree (auto_delete_at);


--
-- Name: ix_drive_backups_backup_type; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_drive_backups_backup_type ON public.drive_backups USING btree (backup_type);


--
-- Name: ix_drive_backups_created_at; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_drive_backups_created_at ON public.drive_backups USING btree (created_at);


--
-- Name: ix_drive_backups_created_by; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_drive_backups_created_by ON public.drive_backups USING btree (created_by);


--
-- Name: ix_drive_backups_deleted; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_drive_backups_deleted ON public.drive_backups USING btree (deleted);


--
-- Name: ix_drive_backups_deleted_status; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_drive_backups_deleted_status ON public.drive_backups USING btree (deleted, status);


--
-- Name: ix_drive_backups_status; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_drive_backups_status ON public.drive_backups USING btree (status);


--
-- Name: ix_drive_backups_updated_at; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_drive_backups_updated_at ON public.drive_backups USING btree (updated_at);


--
-- Name: ix_drive_backups_uploaded_at; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_drive_backups_uploaded_at ON public.drive_backups USING btree (uploaded_at);


--
-- Name: ix_email_notifications_created_at; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_email_notifications_created_at ON public.email_notifications USING btree (created_at);


--
-- Name: ix_email_notifications_recipient; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_email_notifications_recipient ON public.email_notifications USING btree (recipient);


--
-- Name: ix_email_notifications_sent_at; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_email_notifications_sent_at ON public.email_notifications USING btree (sent_at);


--
-- Name: ix_email_notifications_status; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_email_notifications_status ON public.email_notifications USING btree (status);


--
-- Name: ix_game_sessions_started_at; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_game_sessions_started_at ON public.game_sessions USING btree (started_at);


--
-- Name: ix_game_sessions_status; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_game_sessions_status ON public.game_sessions USING btree (status);


--
-- Name: ix_google_service_status_created_at; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_google_service_status_created_at ON public.google_service_status USING btree (created_at);


--
-- Name: ix_google_service_status_last_connected; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_google_service_status_last_connected ON public.google_service_status USING btree (last_connected);


--
-- Name: ix_google_service_status_status; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_google_service_status_status ON public.google_service_status USING btree (status);


--
-- Name: ix_google_service_status_updated_at; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_google_service_status_updated_at ON public.google_service_status USING btree (updated_at);


--
-- Name: ix_license_activations_server_id; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_license_activations_server_id ON public.license_activations USING btree (server_id);


--
-- Name: ix_marketplace_apps_category; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_marketplace_apps_category ON public.marketplace_apps USING btree (category);


--
-- Name: ix_marketplace_apps_popularity; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_marketplace_apps_popularity ON public.marketplace_apps USING btree (popularity);


--
-- Name: ix_marketplace_apps_slug; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE UNIQUE INDEX ix_marketplace_apps_slug ON public.marketplace_apps USING btree (slug);


--
-- Name: ix_marketplace_deployments_status; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_marketplace_deployments_status ON public.marketplace_deployments USING btree (status);


--
-- Name: ix_marketplace_deployments_template_id; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_marketplace_deployments_template_id ON public.marketplace_deployments USING btree (template_id);


--
-- Name: ix_model_usage_model_id; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_model_usage_model_id ON public.model_usage USING btree (model_id);


--
-- Name: ix_model_usage_model_timestamp; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_model_usage_model_timestamp ON public.model_usage USING btree (model_id, "timestamp");


--
-- Name: ix_model_usage_provider; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_model_usage_provider ON public.model_usage USING btree (provider);


--
-- Name: ix_model_usage_provider_timestamp; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_model_usage_provider_timestamp ON public.model_usage USING btree (provider, "timestamp");


--
-- Name: ix_model_usage_request_type; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_model_usage_request_type ON public.model_usage USING btree (request_type);


--
-- Name: ix_model_usage_timestamp; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_model_usage_timestamp ON public.model_usage USING btree ("timestamp");


--
-- Name: ix_model_usage_user_id; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_model_usage_user_id ON public.model_usage USING btree (user_id);


--
-- Name: ix_model_usage_year_month; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_model_usage_year_month ON public.model_usage USING btree (year_month);


--
-- Name: ix_nas_backup_jobs_completed_at; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_nas_backup_jobs_completed_at ON public.nas_backup_jobs USING btree (completed_at);


--
-- Name: ix_nas_backup_jobs_created_at; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_nas_backup_jobs_created_at ON public.nas_backup_jobs USING btree (created_at);


--
-- Name: ix_nas_backup_jobs_status; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_nas_backup_jobs_status ON public.nas_backup_jobs USING btree (status);


--
-- Name: ix_nas_mounts_created_at; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_nas_mounts_created_at ON public.nas_mounts USING btree (created_at);


--
-- Name: ix_nas_mounts_is_active; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_nas_mounts_is_active ON public.nas_mounts USING btree (is_active);


--
-- Name: ix_nas_mounts_share_name; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_nas_mounts_share_name ON public.nas_mounts USING btree (share_name);


--
-- Name: ix_nas_mounts_updated_at; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_nas_mounts_updated_at ON public.nas_mounts USING btree (updated_at);


--
-- Name: ix_plex_import_items_job_id; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_plex_import_items_job_id ON public.plex_import_items USING btree (job_id);


--
-- Name: ix_plex_import_items_status; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_plex_import_items_status ON public.plex_import_items USING btree (status);


--
-- Name: ix_plex_import_jobs_created_at; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_plex_import_jobs_created_at ON public.plex_import_jobs USING btree (created_at);


--
-- Name: ix_plex_import_jobs_status; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_plex_import_jobs_status ON public.plex_import_jobs USING btree (status);


--
-- Name: ix_queue_created_at; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_queue_created_at ON public.request_queue USING btree (created_at);


--
-- Name: ix_queue_expires; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_queue_expires ON public.request_queue USING btree (expires_at);


--
-- Name: ix_queue_priority; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_queue_priority ON public.request_queue USING btree (priority);


--
-- Name: ix_queue_request_type; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_queue_request_type ON public.request_queue USING btree (request_type);


--
-- Name: ix_queue_status; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_queue_status ON public.request_queue USING btree (status);


--
-- Name: ix_queue_status_created; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_queue_status_created ON public.request_queue USING btree (status, created_at);


--
-- Name: ix_queue_status_priority; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_queue_status_priority ON public.request_queue USING btree (status, priority);


--
-- Name: ix_queue_user_id; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_queue_user_id ON public.request_queue USING btree (user_id);


--
-- Name: ix_remediation_service; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_remediation_service ON public.remediation_history USING btree (service_name);


--
-- Name: ix_remediation_service_timestamp; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_remediation_service_timestamp ON public.remediation_history USING btree (service_name, started_at);


--
-- Name: ix_remediation_started_at; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_remediation_started_at ON public.remediation_history USING btree (started_at);


--
-- Name: ix_remediation_status; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_remediation_status ON public.remediation_history USING btree (status);


--
-- Name: ix_remediation_status_timestamp; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_remediation_status_timestamp ON public.remediation_history USING btree (status, started_at);


--
-- Name: ix_remediation_trigger_type; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_remediation_trigger_type ON public.remediation_history USING btree (trigger_type);


--
-- Name: ix_service_health_alerts_service_name; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_service_health_alerts_service_name ON public.service_health_alerts USING btree (service_name);


--
-- Name: ix_service_health_checks_service_name; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_service_health_checks_service_name ON public.service_health_checks USING btree (service_name);


--
-- Name: ix_service_health_checks_timestamp; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_service_health_checks_timestamp ON public.service_health_checks USING btree ("timestamp");


--
-- Name: ix_service_ownerships_service_name; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_service_ownerships_service_name ON public.service_ownerships USING btree (service_name);


--
-- Name: ix_service_ownerships_user_id; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_service_ownerships_user_id ON public.service_ownerships USING btree (user_id);


--
-- Name: ix_service_telemetry_service_name; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_service_telemetry_service_name ON public.service_telemetry USING btree (service_name);


--
-- Name: ix_service_telemetry_service_timestamp; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_service_telemetry_service_timestamp ON public.service_telemetry USING btree (service_name, "timestamp");


--
-- Name: ix_service_telemetry_timestamp; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_service_telemetry_timestamp ON public.service_telemetry USING btree ("timestamp");


--
-- Name: ix_storage_alerts_alert_enabled; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_storage_alerts_alert_enabled ON public.storage_alerts USING btree (alert_enabled);


--
-- Name: ix_storage_alerts_created_at; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_storage_alerts_created_at ON public.storage_alerts USING btree (created_at);


--
-- Name: ix_storage_alerts_type_name; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_storage_alerts_type_name ON public.storage_alerts USING btree (metric_type, metric_name);


--
-- Name: ix_storage_alerts_updated_at; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_storage_alerts_updated_at ON public.storage_alerts USING btree (updated_at);


--
-- Name: ix_storage_metrics_timestamp; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_storage_metrics_timestamp ON public.storage_metrics USING btree ("timestamp");


--
-- Name: ix_storage_metrics_type; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_storage_metrics_type ON public.storage_metrics USING btree (metric_type);


--
-- Name: ix_storage_metrics_type_timestamp; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_storage_metrics_type_timestamp ON public.storage_metrics USING btree (metric_type, "timestamp");


--
-- Name: ix_subscriptions_license_key; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE UNIQUE INDEX ix_subscriptions_license_key ON public.subscriptions USING btree (license_key);


--
-- Name: ix_subscriptions_user_email; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE UNIQUE INDEX ix_subscriptions_user_email ON public.subscriptions USING btree (user_email);


--
-- Name: ix_svc_config_category; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_svc_config_category ON public.service_configs USING btree (category);


--
-- Name: ix_svc_config_critical; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_svc_config_critical ON public.service_configs USING btree (is_critical);


--
-- Name: ix_svc_config_enabled; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_svc_config_enabled ON public.service_configs USING btree (is_enabled);


--
-- Name: ix_svc_config_service_name; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE UNIQUE INDEX ix_svc_config_service_name ON public.service_configs USING btree (service_name);


--
-- Name: ix_svc_dep_depends; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_svc_dep_depends ON public.service_dependencies USING btree (depends_on);


--
-- Name: ix_svc_dep_pair; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE UNIQUE INDEX ix_svc_dep_pair ON public.service_dependencies USING btree (service_name, depends_on);


--
-- Name: ix_svc_dep_service; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_svc_dep_service ON public.service_dependencies USING btree (service_name);


--
-- Name: ix_svc_setting_key; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE UNIQUE INDEX ix_svc_setting_key ON public.service_settings USING btree (service_id, key);


--
-- Name: ix_svc_setting_service_id; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_svc_setting_service_id ON public.service_settings USING btree (service_id);


--
-- Name: ix_syslog_category; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_syslog_category ON public.system_logs USING btree (category);


--
-- Name: ix_syslog_category_timestamp; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_syslog_category_timestamp ON public.system_logs USING btree (category, "timestamp");


--
-- Name: ix_syslog_container_name; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_syslog_container_name ON public.system_logs USING btree (container_name);


--
-- Name: ix_syslog_container_timestamp; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_syslog_container_timestamp ON public.system_logs USING btree (container_name, "timestamp");


--
-- Name: ix_syslog_error_code; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_syslog_error_code ON public.system_logs USING btree (error_code);


--
-- Name: ix_syslog_level; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_syslog_level ON public.system_logs USING btree (level);


--
-- Name: ix_syslog_level_timestamp; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_syslog_level_timestamp ON public.system_logs USING btree (level, "timestamp");


--
-- Name: ix_syslog_source; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_syslog_source ON public.system_logs USING btree (source);


--
-- Name: ix_syslog_source_timestamp; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_syslog_source_timestamp ON public.system_logs USING btree (source, "timestamp");


--
-- Name: ix_syslog_source_type; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_syslog_source_type ON public.system_logs USING btree (source_type);


--
-- Name: ix_syslog_timestamp; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_syslog_timestamp ON public.system_logs USING btree ("timestamp");


--
-- Name: ix_syslog_year_month; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_syslog_year_month ON public.system_logs USING btree (year_month);


--
-- Name: ix_system_setting_category; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_system_setting_category ON public.system_settings USING btree (category);


--
-- Name: ix_system_setting_key_category; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_system_setting_key_category ON public.system_settings USING btree (key, category);


--
-- Name: ix_system_settings_category; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_system_settings_category ON public.system_settings USING btree (category);


--
-- Name: ix_system_settings_key; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE UNIQUE INDEX ix_system_settings_key ON public.system_settings USING btree (key);


--
-- Name: ix_tasks_completed_at; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_tasks_completed_at ON public.tasks USING btree (completed_at);


--
-- Name: ix_tasks_created_at; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_tasks_created_at ON public.tasks USING btree (created_at);


--
-- Name: ix_tasks_status; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_tasks_status ON public.tasks USING btree (status);


--
-- Name: ix_tasks_status_priority; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_tasks_status_priority ON public.tasks USING btree (status, priority);


--
-- Name: ix_tasks_workflow_id; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_tasks_workflow_id ON public.tasks USING btree (workflow_id);


--
-- Name: ix_usage_metrics_metric_type; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_usage_metrics_metric_type ON public.usage_metrics USING btree (metric_type);


--
-- Name: ix_usage_metrics_period_start; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_usage_metrics_period_start ON public.usage_metrics USING btree (period_start);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_users_username; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE UNIQUE INDEX ix_users_username ON public.users USING btree (username);


--
-- Name: ix_workflows_completed_at; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_workflows_completed_at ON public.workflows USING btree (completed_at);


--
-- Name: ix_workflows_status; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_workflows_status ON public.workflows USING btree (status);


--
-- Name: ix_workflows_status_created; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_workflows_status_created ON public.workflows USING btree (status, started_at);


--
-- Name: ix_workflows_workflow_type; Type: INDEX; Schema: public; Owner: jarvis
--

CREATE INDEX ix_workflows_workflow_type ON public.workflows USING btree (workflow_type);


--
-- Name: marketplace_deployments trigger_marketplace_deployments_updated_at; Type: TRIGGER; Schema: public; Owner: jarvis
--

CREATE TRIGGER trigger_marketplace_deployments_updated_at BEFORE UPDATE ON public.marketplace_deployments FOR EACH ROW EXECUTE FUNCTION public.update_marketplace_deployments_updated_at();


--
-- Name: agent_conversations agent_conversations_from_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.agent_conversations
    ADD CONSTRAINT agent_conversations_from_agent_id_fkey FOREIGN KEY (from_agent_id) REFERENCES public.agents(id) ON DELETE CASCADE;


--
-- Name: agent_conversations agent_conversations_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.agent_conversations
    ADD CONSTRAINT agent_conversations_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.agent_tasks(id) ON DELETE CASCADE;


--
-- Name: agent_conversations agent_conversations_to_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.agent_conversations
    ADD CONSTRAINT agent_conversations_to_agent_id_fkey FOREIGN KEY (to_agent_id) REFERENCES public.agents(id) ON DELETE CASCADE;


--
-- Name: agent_messages agent_messages_from_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.agent_messages
    ADD CONSTRAINT agent_messages_from_agent_id_fkey FOREIGN KEY (from_agent_id) REFERENCES public.agents(id) ON DELETE CASCADE;


--
-- Name: agent_messages agent_messages_response_to_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.agent_messages
    ADD CONSTRAINT agent_messages_response_to_fkey FOREIGN KEY (response_to) REFERENCES public.agent_messages(id) ON DELETE SET NULL;


--
-- Name: agent_messages agent_messages_to_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.agent_messages
    ADD CONSTRAINT agent_messages_to_agent_id_fkey FOREIGN KEY (to_agent_id) REFERENCES public.agents(id) ON DELETE CASCADE;


--
-- Name: agent_tasks agent_tasks_assigned_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.agent_tasks
    ADD CONSTRAINT agent_tasks_assigned_agent_id_fkey FOREIGN KEY (assigned_agent_id) REFERENCES public.agents(id) ON DELETE SET NULL;


--
-- Name: agent_tasks agent_tasks_parent_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.agent_tasks
    ADD CONSTRAINT agent_tasks_parent_task_id_fkey FOREIGN KEY (parent_task_id) REFERENCES public.agent_tasks(id) ON DELETE SET NULL;


--
-- Name: ai_sessions ai_sessions_target_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.ai_sessions
    ADD CONSTRAINT ai_sessions_target_project_id_fkey FOREIGN KEY (target_project_id) REFERENCES public.projects(id) ON DELETE SET NULL;


--
-- Name: artifact_builds artifact_builds_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.artifact_builds
    ADD CONSTRAINT artifact_builds_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: artifact_builds artifact_builds_workflow_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.artifact_builds
    ADD CONSTRAINT artifact_builds_workflow_id_fkey FOREIGN KEY (workflow_id) REFERENCES public.workflows(id) ON DELETE SET NULL;


--
-- Name: builder_checkpoints builder_checkpoints_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.builder_checkpoints
    ADD CONSTRAINT builder_checkpoints_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.builder_projects(id) ON DELETE CASCADE;


--
-- Name: builder_pages builder_pages_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.builder_pages
    ADD CONSTRAINT builder_pages_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.builder_projects(id) ON DELETE CASCADE;


--
-- Name: compose_specs compose_specs_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.compose_specs
    ADD CONSTRAINT compose_specs_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: deployed_apps deployed_apps_app_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.deployed_apps
    ADD CONSTRAINT deployed_apps_app_id_fkey FOREIGN KEY (app_id) REFERENCES public.marketplace_apps(id);


--
-- Name: deployments deployments_artifact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.deployments
    ADD CONSTRAINT deployments_artifact_id_fkey FOREIGN KEY (artifact_id) REFERENCES public.artifacts(id) ON DELETE SET NULL;


--
-- Name: deployments deployments_workflow_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.deployments
    ADD CONSTRAINT deployments_workflow_id_fkey FOREIGN KEY (workflow_id) REFERENCES public.workflows(id) ON DELETE CASCADE;


--
-- Name: domain_records domain_records_deployment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.domain_records
    ADD CONSTRAINT domain_records_deployment_id_fkey FOREIGN KEY (deployment_id) REFERENCES public.deployments(id) ON DELETE SET NULL;


--
-- Name: deployments fk_deployments_compose_spec; Type: FK CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.deployments
    ADD CONSTRAINT fk_deployments_compose_spec FOREIGN KEY (compose_spec_id) REFERENCES public.compose_specs(id) ON DELETE SET NULL;


--
-- Name: deployments fk_deployments_previous; Type: FK CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.deployments
    ADD CONSTRAINT fk_deployments_previous FOREIGN KEY (previous_deployment_id) REFERENCES public.deployments(id) ON DELETE SET NULL;


--
-- Name: deployments fk_deployments_ssl_cert; Type: FK CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.deployments
    ADD CONSTRAINT fk_deployments_ssl_cert FOREIGN KEY (ssl_certificate_id) REFERENCES public.ssl_certificates(id) ON DELETE SET NULL;


--
-- Name: license_activations license_activations_subscription_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.license_activations
    ADD CONSTRAINT license_activations_subscription_id_fkey FOREIGN KEY (subscription_id) REFERENCES public.subscriptions(id) ON DELETE CASCADE;


--
-- Name: plex_import_items plex_import_items_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.plex_import_items
    ADD CONSTRAINT plex_import_items_job_id_fkey FOREIGN KEY (job_id) REFERENCES public.plex_import_jobs(id) ON DELETE CASCADE;


--
-- Name: role_assignments role_assignments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.role_assignments
    ADD CONSTRAINT role_assignments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: service_ownerships service_ownerships_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.service_ownerships
    ADD CONSTRAINT service_ownerships_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: service_settings service_settings_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.service_settings
    ADD CONSTRAINT service_settings_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.service_configs(id) ON DELETE CASCADE;


--
-- Name: tasks tasks_workflow_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_workflow_id_fkey FOREIGN KEY (workflow_id) REFERENCES public.workflows(id) ON DELETE SET NULL;


--
-- Name: usage_metrics usage_metrics_subscription_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jarvis
--

ALTER TABLE ONLY public.usage_metrics
    ADD CONSTRAINT usage_metrics_subscription_id_fkey FOREIGN KEY (subscription_id) REFERENCES public.subscriptions(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict 6yh8bTkJockx51ml10ZVLC75TY3uMVcCGoYEzkCMAuj7FRtDNBDJRJgg0A7heL9

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

\restrict OAbd5venMDTi56abh5VSgolfeNN0QYXXGBQPV33aD2Ad2P2pTvRHVF002uibvKd

-- Dumped from database version 16.11
-- Dumped by pg_dump version 16.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict OAbd5venMDTi56abh5VSgolfeNN0QYXXGBQPV33aD2Ad2P2pTvRHVF002uibvKd

--
-- Database "streambot" dump
--

--
-- PostgreSQL database dump
--

\restrict 5QeS2x8nyaAedkQ8j8WY23bHwWG4faD5omdri3vyr272mlqDIZXFthNuq7A9chf

-- Dumped from database version 16.11
-- Dumped by pg_dump version 16.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: streambot; Type: DATABASE; Schema: -; Owner: streambot
--

CREATE DATABASE streambot WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE streambot OWNER TO streambot;

\unrestrict 5QeS2x8nyaAedkQ8j8WY23bHwWG4faD5omdri3vyr272mlqDIZXFthNuq7A9chf
\connect streambot
\restrict 5QeS2x8nyaAedkQ8j8WY23bHwWG4faD5omdri3vyr272mlqDIZXFthNuq7A9chf

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: active_trivia_questions; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.active_trivia_questions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    player text NOT NULL,
    platform text NOT NULL,
    question text NOT NULL,
    correct_answer text NOT NULL,
    difficulty text NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.active_trivia_questions OWNER TO streambot;

--
-- Name: alert_history; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.alert_history (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    alert_type text NOT NULL,
    username text,
    message text NOT NULL,
    platform text NOT NULL,
    metadata jsonb,
    "timestamp" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.alert_history OWNER TO streambot;

--
-- Name: alert_settings; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.alert_settings (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    enable_follower_alerts boolean DEFAULT true NOT NULL,
    enable_sub_alerts boolean DEFAULT true NOT NULL,
    enable_raid_alerts boolean DEFAULT true NOT NULL,
    enable_milestone_alerts boolean DEFAULT true NOT NULL,
    follower_template text DEFAULT 'Thanks for the follow, {user}! Welcome to the community!'::text NOT NULL,
    sub_template text DEFAULT 'Thanks for subscribing, {user}! {tier} sub for {months} months!'::text NOT NULL,
    raid_template text DEFAULT 'Thanks for the raid, {raider}! {viewers} viewers joining the party!'::text NOT NULL,
    milestone_thresholds integer[] DEFAULT ARRAY[50, 100, 500, 1000, 5000, 10000] NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.alert_settings OWNER TO streambot;

--
-- Name: analytics_snapshots; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.analytics_snapshots (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    date timestamp without time zone NOT NULL,
    followers integer DEFAULT 0 NOT NULL,
    subscribers integer DEFAULT 0 NOT NULL,
    avg_viewers integer DEFAULT 0 NOT NULL,
    total_streams integer DEFAULT 0 NOT NULL,
    total_hours integer DEFAULT 0 NOT NULL,
    revenue integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.analytics_snapshots OWNER TO streambot;

--
-- Name: bot_configs; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.bot_configs (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    interval_mode text DEFAULT 'manual'::text NOT NULL,
    fixed_interval_minutes integer,
    random_min_minutes integer,
    random_max_minutes integer,
    ai_model text DEFAULT 'gpt-4o'::text NOT NULL,
    ai_prompt_template text,
    ai_temperature integer DEFAULT 1,
    enable_chat_triggers boolean DEFAULT true NOT NULL,
    chat_keywords text[] DEFAULT ARRAY['!snapple'::text, '!fact'::text] NOT NULL,
    active_platforms text[] DEFAULT ARRAY[]::text[] NOT NULL,
    is_active boolean DEFAULT false NOT NULL,
    last_fact_posted_at timestamp without time zone,
    auto_shoutout_on_raid boolean DEFAULT false NOT NULL,
    auto_shoutout_on_host boolean DEFAULT false NOT NULL,
    shoutout_message_template text DEFAULT 'Check out @{username}! They were last streaming {game} with {viewers} viewers! {url}'::text,
    banned_words text[] DEFAULT ARRAY[]::text[] NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.bot_configs OWNER TO streambot;

--
-- Name: bot_instances; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.bot_instances (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    status text DEFAULT 'stopped'::text NOT NULL,
    last_heartbeat timestamp without time zone,
    error_message text,
    started_at timestamp without time zone,
    stopped_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.bot_instances OWNER TO streambot;

--
-- Name: chat_activity; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.chat_activity (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    session_id character varying NOT NULL,
    username text NOT NULL,
    message_count integer DEFAULT 1 NOT NULL,
    first_seen timestamp without time zone DEFAULT now() NOT NULL,
    last_seen timestamp without time zone DEFAULT now() NOT NULL,
    "timestamp" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.chat_activity OWNER TO streambot;

--
-- Name: chatbot_context; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.chatbot_context (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    bot_user_id character varying NOT NULL,
    username text NOT NULL,
    platform text NOT NULL,
    recent_messages jsonb DEFAULT '[]'::jsonb NOT NULL,
    conversation_summary text,
    message_count integer DEFAULT 0 NOT NULL,
    last_seen timestamp without time zone DEFAULT now() NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.chatbot_context OWNER TO streambot;

--
-- Name: chatbot_personalities; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.chatbot_personalities (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    name text NOT NULL,
    system_prompt text NOT NULL,
    temperature integer DEFAULT 10 NOT NULL,
    traits jsonb DEFAULT '[]'::jsonb NOT NULL,
    is_preset boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    usage_count integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.chatbot_personalities OWNER TO streambot;

--
-- Name: chatbot_responses; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.chatbot_responses (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    username text NOT NULL,
    platform text NOT NULL,
    message text NOT NULL,
    response text NOT NULL,
    personality text NOT NULL,
    was_helpful boolean,
    engagement_score integer DEFAULT 0 NOT NULL,
    metadata jsonb,
    "timestamp" timestamp without time zone DEFAULT now() NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.chatbot_responses OWNER TO streambot;

--
-- Name: chatbot_settings; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.chatbot_settings (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    is_enabled boolean DEFAULT false NOT NULL,
    personality text DEFAULT 'friendly'::text NOT NULL,
    custom_personality_prompt text,
    temperature integer DEFAULT 10 NOT NULL,
    response_rate integer DEFAULT 30 NOT NULL,
    context_window integer DEFAULT 10 NOT NULL,
    learning_enabled boolean DEFAULT true NOT NULL,
    mention_trigger text DEFAULT '@bot'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.chatbot_settings OWNER TO streambot;

--
-- Name: currency_rewards; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.currency_rewards (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    bot_user_id character varying NOT NULL,
    reward_name text NOT NULL,
    cost integer DEFAULT 100 NOT NULL,
    command text,
    stock integer,
    max_redeems integer,
    reward_type text NOT NULL,
    reward_data jsonb,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.currency_rewards OWNER TO streambot;

--
-- Name: currency_settings; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.currency_settings (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    currency_name text DEFAULT 'Points'::text NOT NULL,
    currency_symbol text DEFAULT '⭐'::text NOT NULL,
    earn_per_message integer DEFAULT 1 NOT NULL,
    earn_per_minute integer DEFAULT 10 NOT NULL,
    starting_balance integer DEFAULT 100 NOT NULL,
    max_balance integer DEFAULT 1000000 NOT NULL,
    enable_gambling boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.currency_settings OWNER TO streambot;

--
-- Name: currency_transactions; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.currency_transactions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    balance_id character varying NOT NULL,
    username text NOT NULL,
    type text NOT NULL,
    amount integer NOT NULL,
    description text NOT NULL,
    "timestamp" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.currency_transactions OWNER TO streambot;

--
-- Name: custom_commands; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.custom_commands (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    name text NOT NULL,
    response text NOT NULL,
    cooldown integer DEFAULT 0 NOT NULL,
    permission text DEFAULT 'everyone'::text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    usage_count integer DEFAULT 0 NOT NULL,
    last_used_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.custom_commands OWNER TO streambot;

--
-- Name: enhanced_moderation_settings; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.enhanced_moderation_settings (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    global_sensitivity text DEFAULT 'medium'::text NOT NULL,
    toxicity_sensitivity integer DEFAULT 50 NOT NULL,
    spam_sensitivity integer DEFAULT 50 NOT NULL,
    hate_sensitivity integer DEFAULT 70 NOT NULL,
    harassment_sensitivity integer DEFAULT 60 NOT NULL,
    sexual_sensitivity integer DEFAULT 70 NOT NULL,
    violence_sensitivity integer DEFAULT 60 NOT NULL,
    self_harm_sensitivity integer DEFAULT 80 NOT NULL,
    custom_whitelist jsonb DEFAULT '[]'::jsonb NOT NULL,
    custom_blacklist jsonb DEFAULT '[]'::jsonb NOT NULL,
    whitelisted_users jsonb DEFAULT '[]'::jsonb NOT NULL,
    auto_timeout_enabled boolean DEFAULT true NOT NULL,
    auto_ban_threshold integer DEFAULT 3 NOT NULL,
    log_all_messages boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.enhanced_moderation_settings OWNER TO streambot;

--
-- Name: fact_analytics; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.fact_analytics (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    fact_id character varying,
    fact_content text NOT NULL,
    topic text NOT NULL,
    length integer NOT NULL,
    platform text NOT NULL,
    trigger_type text NOT NULL,
    trigger_user text,
    ai_model text DEFAULT 'gpt-4o'::text NOT NULL,
    generation_time_ms integer,
    views integer DEFAULT 0 NOT NULL,
    reactions jsonb DEFAULT '{}'::jsonb NOT NULL,
    engagement_score integer DEFAULT 0 NOT NULL,
    was_personalized boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.fact_analytics OWNER TO streambot;

--
-- Name: facts; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.facts (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    fact text NOT NULL,
    source text DEFAULT 'stream-bot'::text NOT NULL,
    tags jsonb DEFAULT '[]'::jsonb NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.facts OWNER TO streambot;

--
-- Name: feature_toggles; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.feature_toggles (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    twitch_enabled boolean DEFAULT true NOT NULL,
    youtube_enabled boolean DEFAULT true NOT NULL,
    kick_enabled boolean DEFAULT true NOT NULL,
    spotify_enabled boolean DEFAULT true NOT NULL,
    facts_enabled boolean DEFAULT true NOT NULL,
    shoutouts_enabled boolean DEFAULT true NOT NULL,
    commands_enabled boolean DEFAULT true NOT NULL,
    song_requests_enabled boolean DEFAULT true NOT NULL,
    polls_enabled boolean DEFAULT true NOT NULL,
    alerts_enabled boolean DEFAULT true NOT NULL,
    games_enabled boolean DEFAULT true NOT NULL,
    moderation_enabled boolean DEFAULT true NOT NULL,
    chatbot_enabled boolean DEFAULT false NOT NULL,
    currency_enabled boolean DEFAULT true NOT NULL,
    giveaways_enabled boolean DEFAULT true NOT NULL,
    analytics_enabled boolean DEFAULT true NOT NULL,
    obs_integration_enabled boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.feature_toggles OWNER TO streambot;

--
-- Name: game_history; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.game_history (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    game_type text NOT NULL,
    player text NOT NULL,
    opponent text,
    outcome text NOT NULL,
    points_awarded integer DEFAULT 0 NOT NULL,
    details jsonb,
    platform text NOT NULL,
    "timestamp" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.game_history OWNER TO streambot;

--
-- Name: game_settings; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.game_settings (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    enable_games boolean DEFAULT true NOT NULL,
    cooldown_minutes integer DEFAULT 5 NOT NULL,
    points_per_win integer DEFAULT 10 NOT NULL,
    enable_8ball boolean DEFAULT true NOT NULL,
    enable_trivia boolean DEFAULT true NOT NULL,
    enable_duel boolean DEFAULT true NOT NULL,
    enable_slots boolean DEFAULT true NOT NULL,
    enable_roulette boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.game_settings OWNER TO streambot;

--
-- Name: game_stats; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.game_stats (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    username text NOT NULL,
    game_name text NOT NULL,
    platform text NOT NULL,
    wins integer DEFAULT 0 NOT NULL,
    losses integer DEFAULT 0 NOT NULL,
    neutral integer DEFAULT 0 NOT NULL,
    total_plays integer DEFAULT 0 NOT NULL,
    total_points_earned integer DEFAULT 0 NOT NULL,
    last_played timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.game_stats OWNER TO streambot;

--
-- Name: giveaway_entries; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.giveaway_entries (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    giveaway_id character varying NOT NULL,
    user_id character varying NOT NULL,
    username text NOT NULL,
    platform text NOT NULL,
    subscriber_status boolean DEFAULT false NOT NULL,
    entered_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.giveaway_entries OWNER TO streambot;

--
-- Name: giveaway_entry_attempts; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.giveaway_entry_attempts (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    username text NOT NULL,
    platform text NOT NULL,
    giveaway_id character varying,
    attempted_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.giveaway_entry_attempts OWNER TO streambot;

--
-- Name: giveaway_winners; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.giveaway_winners (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    giveaway_id character varying NOT NULL,
    username text NOT NULL,
    platform text NOT NULL,
    selected_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.giveaway_winners OWNER TO streambot;

--
-- Name: giveaways; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.giveaways (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    title text NOT NULL,
    keyword text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    requires_subscription boolean DEFAULT false NOT NULL,
    max_winners integer DEFAULT 1 NOT NULL,
    entry_count integer DEFAULT 0 NOT NULL,
    started_at timestamp without time zone DEFAULT now() NOT NULL,
    ended_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.giveaways OWNER TO streambot;

--
-- Name: intent_classifications; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.intent_classifications (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    platform text NOT NULL,
    username text NOT NULL,
    message text NOT NULL,
    intent text NOT NULL,
    sub_intent text,
    confidence integer DEFAULT 0 NOT NULL,
    entities jsonb DEFAULT '[]'::jsonb NOT NULL,
    sentiment text,
    was_routed boolean DEFAULT false NOT NULL,
    routed_to text,
    processing_time_ms integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.intent_classifications OWNER TO streambot;

--
-- Name: job_queue; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.job_queue (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying,
    job_type text NOT NULL,
    job_name text NOT NULL,
    payload jsonb,
    status text DEFAULT 'pending'::text NOT NULL,
    priority integer DEFAULT 5 NOT NULL,
    run_at timestamp without time zone DEFAULT now() NOT NULL,
    repeat_interval integer,
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    retry_count integer DEFAULT 0 NOT NULL,
    max_retries integer DEFAULT 3 NOT NULL,
    last_error text,
    result jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.job_queue OWNER TO streambot;

--
-- Name: link_whitelist; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.link_whitelist (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    domain text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.link_whitelist OWNER TO streambot;

--
-- Name: message_history; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.message_history (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    platform text NOT NULL,
    trigger_type text NOT NULL,
    trigger_user text,
    fact_content text NOT NULL,
    posted_at timestamp without time zone DEFAULT now() NOT NULL,
    status text DEFAULT 'success'::text NOT NULL,
    error_message text
);


ALTER TABLE public.message_history OWNER TO streambot;

--
-- Name: message_queue; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.message_queue (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    platform text NOT NULL,
    message_type text NOT NULL,
    content text NOT NULL,
    metadata jsonb,
    status text DEFAULT 'pending'::text NOT NULL,
    priority integer DEFAULT 5 NOT NULL,
    retry_count integer DEFAULT 0 NOT NULL,
    max_retries integer DEFAULT 3 NOT NULL,
    last_error text,
    scheduled_for timestamp without time zone DEFAULT now() NOT NULL,
    processed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.message_queue OWNER TO streambot;

--
-- Name: milestones; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.milestones (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    milestone_type text NOT NULL,
    threshold integer NOT NULL,
    achieved boolean DEFAULT false NOT NULL,
    achieved_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.milestones OWNER TO streambot;

--
-- Name: moderation_action_log; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.moderation_action_log (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    platform text NOT NULL,
    target_username text NOT NULL,
    target_message text NOT NULL,
    action_type text NOT NULL,
    action_reason text NOT NULL,
    violation_type text,
    confidence_score integer,
    sensitivity_used integer,
    was_appealed boolean DEFAULT false NOT NULL,
    appeal_outcome text,
    moderator_override boolean DEFAULT false NOT NULL,
    override_by text,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.moderation_action_log OWNER TO streambot;

--
-- Name: moderation_logs; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.moderation_logs (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    platform text NOT NULL,
    username text NOT NULL,
    message text NOT NULL,
    rule_triggered text NOT NULL,
    action text NOT NULL,
    severity text NOT NULL,
    "timestamp" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.moderation_logs OWNER TO streambot;

--
-- Name: moderation_rules; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.moderation_rules (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    rule_type text NOT NULL,
    is_enabled boolean DEFAULT true NOT NULL,
    severity text DEFAULT 'medium'::text NOT NULL,
    action text DEFAULT 'warn'::text NOT NULL,
    custom_pattern text,
    timeout_duration integer DEFAULT 60,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.moderation_rules OWNER TO streambot;

--
-- Name: oauth_sessions; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.oauth_sessions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    state text NOT NULL,
    user_id text NOT NULL,
    platform text NOT NULL,
    code_verifier text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    used_at timestamp with time zone,
    ip_address text
);


ALTER TABLE public.oauth_sessions OWNER TO streambot;

--
-- Name: obs_automations; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.obs_automations (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    name text NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    trigger jsonb NOT NULL,
    actions jsonb NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.obs_automations OWNER TO streambot;

--
-- Name: obs_connections; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.obs_connections (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    host text DEFAULT 'localhost'::text NOT NULL,
    port integer DEFAULT 4455 NOT NULL,
    password text NOT NULL,
    is_connected boolean DEFAULT false NOT NULL,
    last_connected_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.obs_connections OWNER TO streambot;

--
-- Name: onboarding_progress; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.onboarding_progress (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    welcome_completed boolean DEFAULT false NOT NULL,
    platforms_completed boolean DEFAULT false NOT NULL,
    features_completed boolean DEFAULT false NOT NULL,
    settings_completed boolean DEFAULT false NOT NULL,
    finish_completed boolean DEFAULT false NOT NULL,
    twitch_connected boolean DEFAULT false NOT NULL,
    youtube_connected boolean DEFAULT false NOT NULL,
    kick_connected boolean DEFAULT false NOT NULL,
    spotify_connected boolean DEFAULT false NOT NULL,
    enabled_features jsonb DEFAULT '[]'::jsonb NOT NULL,
    current_step integer DEFAULT 1 NOT NULL,
    last_visited_at timestamp without time zone,
    started_at timestamp without time zone DEFAULT now() NOT NULL,
    completed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.onboarding_progress OWNER TO streambot;

--
-- Name: platform_connections; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.platform_connections (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    platform text NOT NULL,
    platform_user_id text,
    platform_username text,
    access_token text,
    refresh_token text,
    token_expires_at timestamp without time zone,
    channel_id text,
    is_connected boolean DEFAULT false NOT NULL,
    last_connected_at timestamp without time zone,
    connection_data jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.platform_connections OWNER TO streambot;

--
-- Name: platform_credential_metadata; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.platform_credential_metadata (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    connection_id character varying NOT NULL,
    platform text NOT NULL,
    scopes jsonb DEFAULT '[]'::jsonb NOT NULL,
    issued_at timestamp without time zone,
    last_refreshed_at timestamp without time zone,
    refresh_count integer DEFAULT 0 NOT NULL,
    encrypted_access_token text,
    encrypted_refresh_token text,
    token_version integer DEFAULT 1 NOT NULL,
    previous_token_hash text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.platform_credential_metadata OWNER TO streambot;

--
-- Name: platform_health; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.platform_health (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    platform text NOT NULL,
    circuit_state text DEFAULT 'closed'::text NOT NULL,
    failure_count integer DEFAULT 0 NOT NULL,
    success_count integer DEFAULT 0 NOT NULL,
    last_failure timestamp without time zone,
    last_success timestamp without time zone,
    is_throttled boolean DEFAULT false NOT NULL,
    throttled_until timestamp without time zone,
    throttle_retry_count integer DEFAULT 0 NOT NULL,
    avg_response_time integer DEFAULT 0 NOT NULL,
    requests_today integer DEFAULT 0 NOT NULL,
    errors_today integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.platform_health OWNER TO streambot;

--
-- Name: platform_stats; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.platform_stats (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    platform text NOT NULL,
    period_type text NOT NULL,
    period_start timestamp without time zone NOT NULL,
    period_end timestamp without time zone NOT NULL,
    messages_sent integer DEFAULT 0 NOT NULL,
    messages_received integer DEFAULT 0 NOT NULL,
    api_calls integer DEFAULT 0 NOT NULL,
    api_errors integer DEFAULT 0 NOT NULL,
    facts_generated integer DEFAULT 0 NOT NULL,
    commands_processed integer DEFAULT 0 NOT NULL,
    moderation_actions integer DEFAULT 0 NOT NULL,
    avg_response_time_ms integer,
    peak_concurrent_users integer,
    total_engagement integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.platform_stats OWNER TO streambot;

--
-- Name: poll_votes; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.poll_votes (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    poll_id character varying NOT NULL,
    username text NOT NULL,
    platform text NOT NULL,
    option text NOT NULL,
    voted_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.poll_votes OWNER TO streambot;

--
-- Name: polls; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.polls (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    question text NOT NULL,
    options text[] NOT NULL,
    duration integer NOT NULL,
    platform text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    twitch_poll_id text,
    started_at timestamp without time zone,
    ended_at timestamp without time zone,
    total_votes integer DEFAULT 0 NOT NULL,
    winner text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.polls OWNER TO streambot;

--
-- Name: prediction_bets; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.prediction_bets (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    prediction_id character varying NOT NULL,
    username text NOT NULL,
    platform text NOT NULL,
    outcome text NOT NULL,
    points integer NOT NULL,
    payout integer DEFAULT 0 NOT NULL,
    placed_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.prediction_bets OWNER TO streambot;

--
-- Name: predictions; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.predictions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    title text NOT NULL,
    outcomes text[] NOT NULL,
    duration integer NOT NULL,
    platform text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    twitch_prediction_id text,
    started_at timestamp without time zone,
    locked_at timestamp without time zone,
    ended_at timestamp without time zone,
    total_points integer DEFAULT 0 NOT NULL,
    total_bets integer DEFAULT 0 NOT NULL,
    winning_outcome text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.predictions OWNER TO streambot;

--
-- Name: reward_redemptions; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.reward_redemptions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    reward_id character varying NOT NULL,
    bot_user_id character varying NOT NULL,
    username text NOT NULL,
    platform text NOT NULL,
    fulfilled boolean DEFAULT false NOT NULL,
    fulfilled_at timestamp without time zone,
    redeemed_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.reward_redemptions OWNER TO streambot;

--
-- Name: sentiment_analysis; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.sentiment_analysis (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    date timestamp without time zone NOT NULL,
    positive_messages integer DEFAULT 0 NOT NULL,
    negative_messages integer DEFAULT 0 NOT NULL,
    neutral_messages integer DEFAULT 0 NOT NULL,
    sentiment_score integer DEFAULT 0 NOT NULL,
    top_topics jsonb DEFAULT '[]'::jsonb NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.sentiment_analysis OWNER TO streambot;

--
-- Name: shoutout_history; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.shoutout_history (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    target_username text NOT NULL,
    platform text NOT NULL,
    shoutout_type text NOT NULL,
    message text NOT NULL,
    "timestamp" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.shoutout_history OWNER TO streambot;

--
-- Name: shoutout_settings; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.shoutout_settings (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    enable_auto_shoutouts boolean DEFAULT false NOT NULL,
    shoutout_template text DEFAULT 'Check out @{username}! They were last streaming {game} with {viewers} viewers! {url}'::text NOT NULL,
    enable_raid_shoutouts boolean DEFAULT false NOT NULL,
    enable_host_shoutouts boolean DEFAULT false NOT NULL,
    recent_follower_shoutouts boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.shoutout_settings OWNER TO streambot;

--
-- Name: shoutouts; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.shoutouts (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    target_username text NOT NULL,
    target_platform text NOT NULL,
    custom_message text,
    usage_count integer DEFAULT 1 NOT NULL,
    last_used_at timestamp without time zone DEFAULT now() NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.shoutouts OWNER TO streambot;

--
-- Name: song_queue; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.song_queue (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    requested_by text NOT NULL,
    song_title text NOT NULL,
    artist text NOT NULL,
    url text NOT NULL,
    platform text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    album_image_url text,
    duration integer,
    "position" integer NOT NULL,
    requested_at timestamp without time zone DEFAULT now() NOT NULL,
    played_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.song_queue OWNER TO streambot;

--
-- Name: song_settings; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.song_settings (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    enable_song_requests boolean DEFAULT true NOT NULL,
    max_queue_size integer DEFAULT 20 NOT NULL,
    max_songs_per_user integer DEFAULT 3 NOT NULL,
    allow_duplicates boolean DEFAULT false NOT NULL,
    profanity_filter boolean DEFAULT true NOT NULL,
    banned_songs text[] DEFAULT ARRAY[]::text[] NOT NULL,
    volume_limit integer DEFAULT 100 NOT NULL,
    allow_spotify boolean DEFAULT true NOT NULL,
    allow_youtube boolean DEFAULT true NOT NULL,
    moderator_only boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.song_settings OWNER TO streambot;

--
-- Name: speech_to_text_queue; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.speech_to_text_queue (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    platform text NOT NULL,
    audio_source text NOT NULL,
    audio_url text,
    audio_format text DEFAULT 'wav'::text NOT NULL,
    duration_ms integer,
    sample_rate integer DEFAULT 16000 NOT NULL,
    channels integer DEFAULT 1 NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    priority integer DEFAULT 5 NOT NULL,
    processing_started_at timestamp without time zone,
    processing_completed_at timestamp without time zone,
    processing_time_ms integer,
    retry_count integer DEFAULT 0 NOT NULL,
    max_retries integer DEFAULT 3 NOT NULL,
    last_error text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.speech_to_text_queue OWNER TO streambot;

--
-- Name: stream_sessions; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.stream_sessions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    platform text NOT NULL,
    started_at timestamp without time zone DEFAULT now() NOT NULL,
    ended_at timestamp without time zone,
    peak_viewers integer DEFAULT 0 NOT NULL,
    total_messages integer DEFAULT 0 NOT NULL,
    unique_chatters integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.stream_sessions OWNER TO streambot;

--
-- Name: token_expiry_alerts; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.token_expiry_alerts (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    platform text NOT NULL,
    alert_type text NOT NULL,
    token_expires_at timestamp without time zone NOT NULL,
    notification_sent boolean DEFAULT false NOT NULL,
    notified_at timestamp without time zone,
    acknowledged boolean DEFAULT false NOT NULL,
    acknowledged_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.token_expiry_alerts OWNER TO streambot;

--
-- Name: token_rollback_storage; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.token_rollback_storage (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    connection_id character varying NOT NULL,
    platform text NOT NULL,
    encrypted_old_access_token text NOT NULL,
    encrypted_old_refresh_token text,
    old_token_expires_at timestamp without time zone,
    rotation_id character varying,
    rollback_used boolean DEFAULT false NOT NULL,
    rollback_used_at timestamp without time zone,
    expires_at timestamp without time zone NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.token_rollback_storage OWNER TO streambot;

--
-- Name: token_rotation_history; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.token_rotation_history (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    platform text NOT NULL,
    rotation_type text NOT NULL,
    previous_expires_at timestamp without time zone,
    new_expires_at timestamp without time zone,
    success boolean DEFAULT true NOT NULL,
    error_message text,
    rotated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.token_rotation_history OWNER TO streambot;

--
-- Name: transcriptions; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.transcriptions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    queue_id character varying,
    user_id character varying NOT NULL,
    platform text NOT NULL,
    audio_source text NOT NULL,
    transcription_text text NOT NULL,
    language text DEFAULT 'en'::text NOT NULL,
    confidence integer,
    word_timestamps jsonb,
    segments jsonb,
    speaker_labels jsonb,
    duration_ms integer,
    model_used text DEFAULT 'whisper-1'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.transcriptions OWNER TO streambot;

--
-- Name: user_balances; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.user_balances (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    bot_user_id character varying NOT NULL,
    username text NOT NULL,
    platform text NOT NULL,
    balance integer DEFAULT 0 NOT NULL,
    total_earned integer DEFAULT 0 NOT NULL,
    total_spent integer DEFAULT 0 NOT NULL,
    last_earned timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.user_balances OWNER TO streambot;

--
-- Name: user_topic_preferences; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.user_topic_preferences (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    topic text NOT NULL,
    positive_reactions integer DEFAULT 0 NOT NULL,
    negative_reactions integer DEFAULT 0 NOT NULL,
    total_shown integer DEFAULT 0 NOT NULL,
    preference_score integer DEFAULT 50 NOT NULL,
    last_shown_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.user_topic_preferences OWNER TO streambot;

--
-- Name: users; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.users (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    email text NOT NULL,
    password_hash text,
    primary_platform text,
    role text DEFAULT 'user'::text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    onboarding_completed boolean DEFAULT false NOT NULL,
    onboarding_step integer DEFAULT 0 NOT NULL,
    dismissed_welcome boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.users OWNER TO streambot;

--
-- Name: viewer_snapshots; Type: TABLE; Schema: public; Owner: streambot
--

CREATE TABLE public.viewer_snapshots (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    session_id character varying NOT NULL,
    viewer_count integer DEFAULT 0 NOT NULL,
    "timestamp" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.viewer_snapshots OWNER TO streambot;

--
-- Data for Name: active_trivia_questions; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.active_trivia_questions (id, user_id, player, platform, question, correct_answer, difficulty, expires_at, created_at) FROM stdin;
\.


--
-- Data for Name: alert_history; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.alert_history (id, user_id, alert_type, username, message, platform, metadata, "timestamp") FROM stdin;
\.


--
-- Data for Name: alert_settings; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.alert_settings (id, user_id, enable_follower_alerts, enable_sub_alerts, enable_raid_alerts, enable_milestone_alerts, follower_template, sub_template, raid_template, milestone_thresholds, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: analytics_snapshots; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.analytics_snapshots (id, user_id, date, followers, subscribers, avg_viewers, total_streams, total_hours, revenue, created_at) FROM stdin;
\.


--
-- Data for Name: bot_configs; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.bot_configs (id, user_id, interval_mode, fixed_interval_minutes, random_min_minutes, random_max_minutes, ai_model, ai_prompt_template, ai_temperature, enable_chat_triggers, chat_keywords, active_platforms, is_active, last_fact_posted_at, auto_shoutout_on_raid, auto_shoutout_on_host, shoutout_message_template, banned_words, created_at, updated_at) FROM stdin;
d396fc33-b2f8-44cf-a766-53c05de2fa13	1d1ea469-de7c-40bc-a2ec-370c18922a02	manual	30	15	60	gpt-4o	Generate a fun, mind-blowing fact about life, the universe, science, history, nature, or weird phenomena. Topics: space, animals, physics, human body, ancient civilizations, food science, geography, inventions, unusual traditions, or bizarre natural phenomena. Keep it under 200 characters.	1	t	{!snapple,!fact}	{}	f	\N	f	f	Check out @{username}! They were last streaming {game} with {viewers} viewers! {url}	{}	2025-12-04 20:30:06.576725	2025-12-04 20:30:06.576725
\.


--
-- Data for Name: bot_instances; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.bot_instances (id, user_id, status, last_heartbeat, error_message, started_at, stopped_at, created_at, updated_at) FROM stdin;
19b5bb23-84f2-433e-918b-51b95b907f11	1d1ea469-de7c-40bc-a2ec-370c18922a02	stopped	\N	\N	\N	\N	2025-12-04 20:30:06.576725	2025-12-04 20:30:06.576725
\.


--
-- Data for Name: chat_activity; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.chat_activity (id, session_id, username, message_count, first_seen, last_seen, "timestamp") FROM stdin;
\.


--
-- Data for Name: chatbot_context; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.chatbot_context (id, bot_user_id, username, platform, recent_messages, conversation_summary, message_count, last_seen, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: chatbot_personalities; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.chatbot_personalities (id, user_id, name, system_prompt, temperature, traits, is_preset, is_active, usage_count, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: chatbot_responses; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.chatbot_responses (id, user_id, username, platform, message, response, personality, was_helpful, engagement_score, metadata, "timestamp", created_at) FROM stdin;
\.


--
-- Data for Name: chatbot_settings; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.chatbot_settings (id, user_id, is_enabled, personality, custom_personality_prompt, temperature, response_rate, context_window, learning_enabled, mention_trigger, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: currency_rewards; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.currency_rewards (id, bot_user_id, reward_name, cost, command, stock, max_redeems, reward_type, reward_data, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: currency_settings; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.currency_settings (id, user_id, currency_name, currency_symbol, earn_per_message, earn_per_minute, starting_balance, max_balance, enable_gambling, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: currency_transactions; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.currency_transactions (id, balance_id, username, type, amount, description, "timestamp") FROM stdin;
\.


--
-- Data for Name: custom_commands; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.custom_commands (id, user_id, name, response, cooldown, permission, is_active, usage_count, last_used_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: enhanced_moderation_settings; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.enhanced_moderation_settings (id, user_id, global_sensitivity, toxicity_sensitivity, spam_sensitivity, hate_sensitivity, harassment_sensitivity, sexual_sensitivity, violence_sensitivity, self_harm_sensitivity, custom_whitelist, custom_blacklist, whitelisted_users, auto_timeout_enabled, auto_ban_threshold, log_all_messages, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: fact_analytics; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.fact_analytics (id, user_id, fact_id, fact_content, topic, length, platform, trigger_type, trigger_user, ai_model, generation_time_ms, views, reactions, engagement_score, was_personalized, created_at) FROM stdin;
\.


--
-- Data for Name: facts; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.facts (id, fact, source, tags, created_at) FROM stdin;
\.


--
-- Data for Name: feature_toggles; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.feature_toggles (id, user_id, twitch_enabled, youtube_enabled, kick_enabled, spotify_enabled, facts_enabled, shoutouts_enabled, commands_enabled, song_requests_enabled, polls_enabled, alerts_enabled, games_enabled, moderation_enabled, chatbot_enabled, currency_enabled, giveaways_enabled, analytics_enabled, obs_integration_enabled, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: game_history; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.game_history (id, user_id, game_type, player, opponent, outcome, points_awarded, details, platform, "timestamp") FROM stdin;
\.


--
-- Data for Name: game_settings; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.game_settings (id, user_id, enable_games, cooldown_minutes, points_per_win, enable_8ball, enable_trivia, enable_duel, enable_slots, enable_roulette, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: game_stats; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.game_stats (id, user_id, username, game_name, platform, wins, losses, neutral, total_plays, total_points_earned, last_played, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: giveaway_entries; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.giveaway_entries (id, giveaway_id, user_id, username, platform, subscriber_status, entered_at) FROM stdin;
\.


--
-- Data for Name: giveaway_entry_attempts; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.giveaway_entry_attempts (id, user_id, username, platform, giveaway_id, attempted_at) FROM stdin;
\.


--
-- Data for Name: giveaway_winners; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.giveaway_winners (id, giveaway_id, username, platform, selected_at) FROM stdin;
\.


--
-- Data for Name: giveaways; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.giveaways (id, user_id, title, keyword, is_active, requires_subscription, max_winners, entry_count, started_at, ended_at, created_at) FROM stdin;
\.


--
-- Data for Name: intent_classifications; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.intent_classifications (id, user_id, platform, username, message, intent, sub_intent, confidence, entities, sentiment, was_routed, routed_to, processing_time_ms, created_at) FROM stdin;
\.


--
-- Data for Name: job_queue; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.job_queue (id, user_id, job_type, job_name, payload, status, priority, run_at, repeat_interval, started_at, completed_at, retry_count, max_retries, last_error, result, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: link_whitelist; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.link_whitelist (id, user_id, domain, created_at) FROM stdin;
\.


--
-- Data for Name: message_history; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.message_history (id, user_id, platform, trigger_type, trigger_user, fact_content, posted_at, status, error_message) FROM stdin;
\.


--
-- Data for Name: message_queue; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.message_queue (id, user_id, platform, message_type, content, metadata, status, priority, retry_count, max_retries, last_error, scheduled_for, processed_at, created_at) FROM stdin;
\.


--
-- Data for Name: milestones; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.milestones (id, user_id, milestone_type, threshold, achieved, achieved_at, created_at) FROM stdin;
\.


--
-- Data for Name: moderation_action_log; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.moderation_action_log (id, user_id, platform, target_username, target_message, action_type, action_reason, violation_type, confidence_score, sensitivity_used, was_appealed, appeal_outcome, moderator_override, override_by, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: moderation_logs; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.moderation_logs (id, user_id, platform, username, message, rule_triggered, action, severity, "timestamp") FROM stdin;
\.


--
-- Data for Name: moderation_rules; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.moderation_rules (id, user_id, rule_type, is_enabled, severity, action, custom_pattern, timeout_duration, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: oauth_sessions; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.oauth_sessions (id, state, user_id, platform, code_verifier, metadata, created_at, expires_at, used_at, ip_address) FROM stdin;
\.


--
-- Data for Name: obs_automations; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.obs_automations (id, user_id, name, enabled, trigger, actions, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: obs_connections; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.obs_connections (id, user_id, host, port, password, is_connected, last_connected_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: onboarding_progress; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.onboarding_progress (id, user_id, welcome_completed, platforms_completed, features_completed, settings_completed, finish_completed, twitch_connected, youtube_connected, kick_connected, spotify_connected, enabled_features, current_step, last_visited_at, started_at, completed_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: platform_connections; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.platform_connections (id, user_id, platform, platform_user_id, platform_username, access_token, refresh_token, token_expires_at, channel_id, is_connected, last_connected_at, connection_data, created_at, updated_at) FROM stdin;
ba9243f8-611e-43b0-88f2-f505212874ac	1d1ea469-de7c-40bc-a2ec-370c18922a02	youtube	youtube user	YouTube User	connector_managed	\N	\N	youtube_channel	t	2025-12-04 20:30:16.079	{"botUsername": "YouTube User"}	2025-12-04 20:30:16.254332	2025-12-04 20:30:16.253
30c45b90-ee78-4f43-be21-be1094df31a7	1d1ea469-de7c-40bc-a2ec-370c18922a02	twitch	119886653	scarletredjoker	cbb91d0aadb84efbe1a1f21f0fd598d1:fb62da8b6426d0f5d7547358b68fd057:7a6cbf8944e1428ad85a59a3b4ec90a2178593bc12e2b2bb7a471086f0d1	3e96d31549ce6b4ecdd3b1559c8c8a13:089426353f8f0ce4694a2d21c07f49a3:9e2f0bbb6773e7ff5c7f58cc7e5db4b9969bc2ba0baefb4d505a26192abbff526c228289d5fd8c6945cdcfc4b756a4f7a25f	2025-12-07 14:59:13.309	\N	f	2025-12-04 20:30:06.668	{"email": "zeldaduck11@gmail.com"}	2025-12-04 20:30:06.576725	2025-12-07 11:04:59.539
\.


--
-- Data for Name: platform_credential_metadata; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.platform_credential_metadata (id, connection_id, platform, scopes, issued_at, last_refreshed_at, refresh_count, encrypted_access_token, encrypted_refresh_token, token_version, previous_token_hash, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: platform_health; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.platform_health (id, platform, circuit_state, failure_count, success_count, last_failure, last_success, is_throttled, throttled_until, throttle_retry_count, avg_response_time, requests_today, errors_today, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: platform_stats; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.platform_stats (id, user_id, platform, period_type, period_start, period_end, messages_sent, messages_received, api_calls, api_errors, facts_generated, commands_processed, moderation_actions, avg_response_time_ms, peak_concurrent_users, total_engagement, created_at) FROM stdin;
\.


--
-- Data for Name: poll_votes; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.poll_votes (id, poll_id, username, platform, option, voted_at) FROM stdin;
\.


--
-- Data for Name: polls; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.polls (id, user_id, question, options, duration, platform, status, twitch_poll_id, started_at, ended_at, total_votes, winner, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: prediction_bets; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.prediction_bets (id, prediction_id, username, platform, outcome, points, payout, placed_at) FROM stdin;
\.


--
-- Data for Name: predictions; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.predictions (id, user_id, title, outcomes, duration, platform, status, twitch_prediction_id, started_at, locked_at, ended_at, total_points, total_bets, winning_outcome, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: reward_redemptions; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.reward_redemptions (id, reward_id, bot_user_id, username, platform, fulfilled, fulfilled_at, redeemed_at) FROM stdin;
\.


--
-- Data for Name: sentiment_analysis; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.sentiment_analysis (id, user_id, date, positive_messages, negative_messages, neutral_messages, sentiment_score, top_topics, created_at) FROM stdin;
\.


--
-- Data for Name: shoutout_history; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.shoutout_history (id, user_id, target_username, platform, shoutout_type, message, "timestamp") FROM stdin;
\.


--
-- Data for Name: shoutout_settings; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.shoutout_settings (id, user_id, enable_auto_shoutouts, shoutout_template, enable_raid_shoutouts, enable_host_shoutouts, recent_follower_shoutouts, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: shoutouts; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.shoutouts (id, user_id, target_username, target_platform, custom_message, usage_count, last_used_at, created_at) FROM stdin;
\.


--
-- Data for Name: song_queue; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.song_queue (id, user_id, requested_by, song_title, artist, url, platform, status, album_image_url, duration, "position", requested_at, played_at, created_at) FROM stdin;
\.


--
-- Data for Name: song_settings; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.song_settings (id, user_id, enable_song_requests, max_queue_size, max_songs_per_user, allow_duplicates, profanity_filter, banned_songs, volume_limit, allow_spotify, allow_youtube, moderator_only, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: speech_to_text_queue; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.speech_to_text_queue (id, user_id, platform, audio_source, audio_url, audio_format, duration_ms, sample_rate, channels, status, priority, processing_started_at, processing_completed_at, processing_time_ms, retry_count, max_retries, last_error, created_at) FROM stdin;
\.


--
-- Data for Name: stream_sessions; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.stream_sessions (id, user_id, platform, started_at, ended_at, peak_viewers, total_messages, unique_chatters, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: token_expiry_alerts; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.token_expiry_alerts (id, user_id, platform, alert_type, token_expires_at, notification_sent, notified_at, acknowledged, acknowledged_at, created_at) FROM stdin;
\.


--
-- Data for Name: token_rollback_storage; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.token_rollback_storage (id, user_id, connection_id, platform, encrypted_old_access_token, encrypted_old_refresh_token, old_token_expires_at, rotation_id, rollback_used, rollback_used_at, expires_at, created_at) FROM stdin;
\.


--
-- Data for Name: token_rotation_history; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.token_rotation_history (id, user_id, platform, rotation_type, previous_expires_at, new_expires_at, success, error_message, rotated_at) FROM stdin;
\.


--
-- Data for Name: transcriptions; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.transcriptions (id, queue_id, user_id, platform, audio_source, transcription_text, language, confidence, word_timestamps, segments, speaker_labels, duration_ms, model_used, created_at) FROM stdin;
\.


--
-- Data for Name: user_balances; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.user_balances (id, bot_user_id, username, platform, balance, total_earned, total_spent, last_earned, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_topic_preferences; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.user_topic_preferences (id, user_id, topic, positive_reactions, negative_reactions, total_shown, preference_score, last_shown_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.users (id, email, password_hash, primary_platform, role, is_active, onboarding_completed, onboarding_step, dismissed_welcome, created_at, updated_at) FROM stdin;
1d1ea469-de7c-40bc-a2ec-370c18922a02	zeldaduck11@gmail.com	\N	twitch	user	t	f	0	f	2025-12-04 20:30:06.576725	2025-12-04 20:30:06.576725
\.


--
-- Data for Name: viewer_snapshots; Type: TABLE DATA; Schema: public; Owner: streambot
--

COPY public.viewer_snapshots (id, session_id, viewer_count, "timestamp") FROM stdin;
\.


--
-- Name: active_trivia_questions active_trivia_questions_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.active_trivia_questions
    ADD CONSTRAINT active_trivia_questions_pkey PRIMARY KEY (id);


--
-- Name: alert_history alert_history_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.alert_history
    ADD CONSTRAINT alert_history_pkey PRIMARY KEY (id);


--
-- Name: alert_settings alert_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.alert_settings
    ADD CONSTRAINT alert_settings_pkey PRIMARY KEY (id);


--
-- Name: alert_settings alert_settings_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.alert_settings
    ADD CONSTRAINT alert_settings_user_id_unique UNIQUE (user_id);


--
-- Name: analytics_snapshots analytics_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.analytics_snapshots
    ADD CONSTRAINT analytics_snapshots_pkey PRIMARY KEY (id);


--
-- Name: bot_configs bot_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.bot_configs
    ADD CONSTRAINT bot_configs_pkey PRIMARY KEY (id);


--
-- Name: bot_configs bot_configs_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.bot_configs
    ADD CONSTRAINT bot_configs_user_id_unique UNIQUE (user_id);


--
-- Name: bot_instances bot_instances_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.bot_instances
    ADD CONSTRAINT bot_instances_pkey PRIMARY KEY (id);


--
-- Name: bot_instances bot_instances_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.bot_instances
    ADD CONSTRAINT bot_instances_user_id_unique UNIQUE (user_id);


--
-- Name: chat_activity chat_activity_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.chat_activity
    ADD CONSTRAINT chat_activity_pkey PRIMARY KEY (id);


--
-- Name: chatbot_context chatbot_context_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.chatbot_context
    ADD CONSTRAINT chatbot_context_pkey PRIMARY KEY (id);


--
-- Name: chatbot_personalities chatbot_personalities_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.chatbot_personalities
    ADD CONSTRAINT chatbot_personalities_pkey PRIMARY KEY (id);


--
-- Name: chatbot_responses chatbot_responses_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.chatbot_responses
    ADD CONSTRAINT chatbot_responses_pkey PRIMARY KEY (id);


--
-- Name: chatbot_settings chatbot_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.chatbot_settings
    ADD CONSTRAINT chatbot_settings_pkey PRIMARY KEY (id);


--
-- Name: chatbot_settings chatbot_settings_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.chatbot_settings
    ADD CONSTRAINT chatbot_settings_user_id_unique UNIQUE (user_id);


--
-- Name: currency_rewards currency_rewards_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.currency_rewards
    ADD CONSTRAINT currency_rewards_pkey PRIMARY KEY (id);


--
-- Name: currency_settings currency_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.currency_settings
    ADD CONSTRAINT currency_settings_pkey PRIMARY KEY (id);


--
-- Name: currency_settings currency_settings_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.currency_settings
    ADD CONSTRAINT currency_settings_user_id_unique UNIQUE (user_id);


--
-- Name: currency_transactions currency_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.currency_transactions
    ADD CONSTRAINT currency_transactions_pkey PRIMARY KEY (id);


--
-- Name: custom_commands custom_commands_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.custom_commands
    ADD CONSTRAINT custom_commands_pkey PRIMARY KEY (id);


--
-- Name: enhanced_moderation_settings enhanced_moderation_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.enhanced_moderation_settings
    ADD CONSTRAINT enhanced_moderation_settings_pkey PRIMARY KEY (id);


--
-- Name: enhanced_moderation_settings enhanced_moderation_settings_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.enhanced_moderation_settings
    ADD CONSTRAINT enhanced_moderation_settings_user_id_unique UNIQUE (user_id);


--
-- Name: fact_analytics fact_analytics_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.fact_analytics
    ADD CONSTRAINT fact_analytics_pkey PRIMARY KEY (id);


--
-- Name: facts facts_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.facts
    ADD CONSTRAINT facts_pkey PRIMARY KEY (id);


--
-- Name: feature_toggles feature_toggles_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.feature_toggles
    ADD CONSTRAINT feature_toggles_pkey PRIMARY KEY (id);


--
-- Name: feature_toggles feature_toggles_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.feature_toggles
    ADD CONSTRAINT feature_toggles_user_id_unique UNIQUE (user_id);


--
-- Name: game_history game_history_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.game_history
    ADD CONSTRAINT game_history_pkey PRIMARY KEY (id);


--
-- Name: game_settings game_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.game_settings
    ADD CONSTRAINT game_settings_pkey PRIMARY KEY (id);


--
-- Name: game_settings game_settings_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.game_settings
    ADD CONSTRAINT game_settings_user_id_unique UNIQUE (user_id);


--
-- Name: game_stats game_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.game_stats
    ADD CONSTRAINT game_stats_pkey PRIMARY KEY (id);


--
-- Name: giveaway_entries giveaway_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.giveaway_entries
    ADD CONSTRAINT giveaway_entries_pkey PRIMARY KEY (id);


--
-- Name: giveaway_entry_attempts giveaway_entry_attempts_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.giveaway_entry_attempts
    ADD CONSTRAINT giveaway_entry_attempts_pkey PRIMARY KEY (id);


--
-- Name: giveaway_winners giveaway_winners_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.giveaway_winners
    ADD CONSTRAINT giveaway_winners_pkey PRIMARY KEY (id);


--
-- Name: giveaways giveaways_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.giveaways
    ADD CONSTRAINT giveaways_pkey PRIMARY KEY (id);


--
-- Name: intent_classifications intent_classifications_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.intent_classifications
    ADD CONSTRAINT intent_classifications_pkey PRIMARY KEY (id);


--
-- Name: job_queue job_queue_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.job_queue
    ADD CONSTRAINT job_queue_pkey PRIMARY KEY (id);


--
-- Name: link_whitelist link_whitelist_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.link_whitelist
    ADD CONSTRAINT link_whitelist_pkey PRIMARY KEY (id);


--
-- Name: message_history message_history_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.message_history
    ADD CONSTRAINT message_history_pkey PRIMARY KEY (id);


--
-- Name: message_queue message_queue_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.message_queue
    ADD CONSTRAINT message_queue_pkey PRIMARY KEY (id);


--
-- Name: milestones milestones_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.milestones
    ADD CONSTRAINT milestones_pkey PRIMARY KEY (id);


--
-- Name: moderation_action_log moderation_action_log_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.moderation_action_log
    ADD CONSTRAINT moderation_action_log_pkey PRIMARY KEY (id);


--
-- Name: moderation_logs moderation_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.moderation_logs
    ADD CONSTRAINT moderation_logs_pkey PRIMARY KEY (id);


--
-- Name: moderation_rules moderation_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.moderation_rules
    ADD CONSTRAINT moderation_rules_pkey PRIMARY KEY (id);


--
-- Name: oauth_sessions oauth_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.oauth_sessions
    ADD CONSTRAINT oauth_sessions_pkey PRIMARY KEY (id);


--
-- Name: oauth_sessions oauth_sessions_state_unique; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.oauth_sessions
    ADD CONSTRAINT oauth_sessions_state_unique UNIQUE (state);


--
-- Name: obs_automations obs_automations_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.obs_automations
    ADD CONSTRAINT obs_automations_pkey PRIMARY KEY (id);


--
-- Name: obs_connections obs_connections_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.obs_connections
    ADD CONSTRAINT obs_connections_pkey PRIMARY KEY (id);


--
-- Name: obs_connections obs_connections_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.obs_connections
    ADD CONSTRAINT obs_connections_user_id_unique UNIQUE (user_id);


--
-- Name: onboarding_progress onboarding_progress_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.onboarding_progress
    ADD CONSTRAINT onboarding_progress_pkey PRIMARY KEY (id);


--
-- Name: onboarding_progress onboarding_progress_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.onboarding_progress
    ADD CONSTRAINT onboarding_progress_user_id_unique UNIQUE (user_id);


--
-- Name: platform_connections platform_connections_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.platform_connections
    ADD CONSTRAINT platform_connections_pkey PRIMARY KEY (id);


--
-- Name: platform_credential_metadata platform_credential_metadata_connection_id_unique; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.platform_credential_metadata
    ADD CONSTRAINT platform_credential_metadata_connection_id_unique UNIQUE (connection_id);


--
-- Name: platform_credential_metadata platform_credential_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.platform_credential_metadata
    ADD CONSTRAINT platform_credential_metadata_pkey PRIMARY KEY (id);


--
-- Name: platform_health platform_health_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.platform_health
    ADD CONSTRAINT platform_health_pkey PRIMARY KEY (id);


--
-- Name: platform_health platform_health_platform_unique; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.platform_health
    ADD CONSTRAINT platform_health_platform_unique UNIQUE (platform);


--
-- Name: platform_stats platform_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.platform_stats
    ADD CONSTRAINT platform_stats_pkey PRIMARY KEY (id);


--
-- Name: poll_votes poll_votes_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.poll_votes
    ADD CONSTRAINT poll_votes_pkey PRIMARY KEY (id);


--
-- Name: polls polls_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.polls
    ADD CONSTRAINT polls_pkey PRIMARY KEY (id);


--
-- Name: prediction_bets prediction_bets_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.prediction_bets
    ADD CONSTRAINT prediction_bets_pkey PRIMARY KEY (id);


--
-- Name: predictions predictions_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.predictions
    ADD CONSTRAINT predictions_pkey PRIMARY KEY (id);


--
-- Name: reward_redemptions reward_redemptions_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.reward_redemptions
    ADD CONSTRAINT reward_redemptions_pkey PRIMARY KEY (id);


--
-- Name: sentiment_analysis sentiment_analysis_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.sentiment_analysis
    ADD CONSTRAINT sentiment_analysis_pkey PRIMARY KEY (id);


--
-- Name: shoutout_history shoutout_history_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.shoutout_history
    ADD CONSTRAINT shoutout_history_pkey PRIMARY KEY (id);


--
-- Name: shoutout_settings shoutout_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.shoutout_settings
    ADD CONSTRAINT shoutout_settings_pkey PRIMARY KEY (id);


--
-- Name: shoutout_settings shoutout_settings_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.shoutout_settings
    ADD CONSTRAINT shoutout_settings_user_id_unique UNIQUE (user_id);


--
-- Name: shoutouts shoutouts_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.shoutouts
    ADD CONSTRAINT shoutouts_pkey PRIMARY KEY (id);


--
-- Name: song_queue song_queue_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.song_queue
    ADD CONSTRAINT song_queue_pkey PRIMARY KEY (id);


--
-- Name: song_settings song_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.song_settings
    ADD CONSTRAINT song_settings_pkey PRIMARY KEY (id);


--
-- Name: song_settings song_settings_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.song_settings
    ADD CONSTRAINT song_settings_user_id_unique UNIQUE (user_id);


--
-- Name: speech_to_text_queue speech_to_text_queue_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.speech_to_text_queue
    ADD CONSTRAINT speech_to_text_queue_pkey PRIMARY KEY (id);


--
-- Name: stream_sessions stream_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.stream_sessions
    ADD CONSTRAINT stream_sessions_pkey PRIMARY KEY (id);


--
-- Name: token_expiry_alerts token_expiry_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.token_expiry_alerts
    ADD CONSTRAINT token_expiry_alerts_pkey PRIMARY KEY (id);


--
-- Name: token_rollback_storage token_rollback_storage_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.token_rollback_storage
    ADD CONSTRAINT token_rollback_storage_pkey PRIMARY KEY (id);


--
-- Name: token_rotation_history token_rotation_history_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.token_rotation_history
    ADD CONSTRAINT token_rotation_history_pkey PRIMARY KEY (id);


--
-- Name: transcriptions transcriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.transcriptions
    ADD CONSTRAINT transcriptions_pkey PRIMARY KEY (id);


--
-- Name: user_balances user_balances_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.user_balances
    ADD CONSTRAINT user_balances_pkey PRIMARY KEY (id);


--
-- Name: user_topic_preferences user_topic_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.user_topic_preferences
    ADD CONSTRAINT user_topic_preferences_pkey PRIMARY KEY (id);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: viewer_snapshots viewer_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.viewer_snapshots
    ADD CONSTRAINT viewer_snapshots_pkey PRIMARY KEY (id);


--
-- Name: analytics_snapshots_user_id_date_unique; Type: INDEX; Schema: public; Owner: streambot
--

CREATE UNIQUE INDEX analytics_snapshots_user_id_date_unique ON public.analytics_snapshots USING btree (user_id, date);


--
-- Name: chatbot_context_bot_user_id_username_platform_unique; Type: INDEX; Schema: public; Owner: streambot
--

CREATE UNIQUE INDEX chatbot_context_bot_user_id_username_platform_unique ON public.chatbot_context USING btree (bot_user_id, username, platform);


--
-- Name: chatbot_personalities_user_id_name_unique; Type: INDEX; Schema: public; Owner: streambot
--

CREATE UNIQUE INDEX chatbot_personalities_user_id_name_unique ON public.chatbot_personalities USING btree (user_id, name);


--
-- Name: currency_rewards_bot_user_id_reward_name_unique; Type: INDEX; Schema: public; Owner: streambot
--

CREATE UNIQUE INDEX currency_rewards_bot_user_id_reward_name_unique ON public.currency_rewards USING btree (bot_user_id, reward_name);


--
-- Name: custom_commands_user_id_name_unique; Type: INDEX; Schema: public; Owner: streambot
--

CREATE UNIQUE INDEX custom_commands_user_id_name_unique ON public.custom_commands USING btree (user_id, name);


--
-- Name: fact_analytics_created_at_idx; Type: INDEX; Schema: public; Owner: streambot
--

CREATE INDEX fact_analytics_created_at_idx ON public.fact_analytics USING btree (created_at);


--
-- Name: fact_analytics_platform_idx; Type: INDEX; Schema: public; Owner: streambot
--

CREATE INDEX fact_analytics_platform_idx ON public.fact_analytics USING btree (platform);


--
-- Name: fact_analytics_topic_idx; Type: INDEX; Schema: public; Owner: streambot
--

CREATE INDEX fact_analytics_topic_idx ON public.fact_analytics USING btree (topic);


--
-- Name: fact_analytics_user_id_idx; Type: INDEX; Schema: public; Owner: streambot
--

CREATE INDEX fact_analytics_user_id_idx ON public.fact_analytics USING btree (user_id);


--
-- Name: facts_created_at_idx; Type: INDEX; Schema: public; Owner: streambot
--

CREATE INDEX facts_created_at_idx ON public.facts USING btree (created_at);


--
-- Name: facts_source_idx; Type: INDEX; Schema: public; Owner: streambot
--

CREATE INDEX facts_source_idx ON public.facts USING btree (source);


--
-- Name: game_stats_user_id_username_game_name_platform_unique; Type: INDEX; Schema: public; Owner: streambot
--

CREATE UNIQUE INDEX game_stats_user_id_username_game_name_platform_unique ON public.game_stats USING btree (user_id, username, game_name, platform);


--
-- Name: giveaway_entries_giveaway_id_username_platform_unique; Type: INDEX; Schema: public; Owner: streambot
--

CREATE UNIQUE INDEX giveaway_entries_giveaway_id_username_platform_unique ON public.giveaway_entries USING btree (giveaway_id, username, platform);


--
-- Name: giveaway_entry_attempts_username_platform_attempted_at_idx; Type: INDEX; Schema: public; Owner: streambot
--

CREATE UNIQUE INDEX giveaway_entry_attempts_username_platform_attempted_at_idx ON public.giveaway_entry_attempts USING btree (username, platform, attempted_at);


--
-- Name: intent_classifications_created_at_idx; Type: INDEX; Schema: public; Owner: streambot
--

CREATE INDEX intent_classifications_created_at_idx ON public.intent_classifications USING btree (created_at);


--
-- Name: intent_classifications_intent_idx; Type: INDEX; Schema: public; Owner: streambot
--

CREATE INDEX intent_classifications_intent_idx ON public.intent_classifications USING btree (intent);


--
-- Name: intent_classifications_user_id_idx; Type: INDEX; Schema: public; Owner: streambot
--

CREATE INDEX intent_classifications_user_id_idx ON public.intent_classifications USING btree (user_id);


--
-- Name: job_queue_job_type_idx; Type: INDEX; Schema: public; Owner: streambot
--

CREATE INDEX job_queue_job_type_idx ON public.job_queue USING btree (job_type);


--
-- Name: job_queue_run_at_idx; Type: INDEX; Schema: public; Owner: streambot
--

CREATE INDEX job_queue_run_at_idx ON public.job_queue USING btree (run_at);


--
-- Name: job_queue_status_idx; Type: INDEX; Schema: public; Owner: streambot
--

CREATE INDEX job_queue_status_idx ON public.job_queue USING btree (status);


--
-- Name: job_queue_user_id_idx; Type: INDEX; Schema: public; Owner: streambot
--

CREATE INDEX job_queue_user_id_idx ON public.job_queue USING btree (user_id);


--
-- Name: link_whitelist_user_id_domain_unique; Type: INDEX; Schema: public; Owner: streambot
--

CREATE UNIQUE INDEX link_whitelist_user_id_domain_unique ON public.link_whitelist USING btree (user_id, domain);


--
-- Name: message_queue_platform_idx; Type: INDEX; Schema: public; Owner: streambot
--

CREATE INDEX message_queue_platform_idx ON public.message_queue USING btree (platform);


--
-- Name: message_queue_scheduled_for_idx; Type: INDEX; Schema: public; Owner: streambot
--

CREATE INDEX message_queue_scheduled_for_idx ON public.message_queue USING btree (scheduled_for);


--
-- Name: message_queue_status_idx; Type: INDEX; Schema: public; Owner: streambot
--

CREATE INDEX message_queue_status_idx ON public.message_queue USING btree (status);


--
-- Name: message_queue_user_id_idx; Type: INDEX; Schema: public; Owner: streambot
--

CREATE INDEX message_queue_user_id_idx ON public.message_queue USING btree (user_id);


--
-- Name: milestones_user_id_type_threshold_unique; Type: INDEX; Schema: public; Owner: streambot
--

CREATE UNIQUE INDEX milestones_user_id_type_threshold_unique ON public.milestones USING btree (user_id, milestone_type, threshold);


--
-- Name: moderation_action_log_action_type_idx; Type: INDEX; Schema: public; Owner: streambot
--

CREATE INDEX moderation_action_log_action_type_idx ON public.moderation_action_log USING btree (action_type);


--
-- Name: moderation_action_log_created_at_idx; Type: INDEX; Schema: public; Owner: streambot
--

CREATE INDEX moderation_action_log_created_at_idx ON public.moderation_action_log USING btree (created_at);


--
-- Name: moderation_action_log_target_username_idx; Type: INDEX; Schema: public; Owner: streambot
--

CREATE INDEX moderation_action_log_target_username_idx ON public.moderation_action_log USING btree (target_username);


--
-- Name: moderation_action_log_user_id_idx; Type: INDEX; Schema: public; Owner: streambot
--

CREATE INDEX moderation_action_log_user_id_idx ON public.moderation_action_log USING btree (user_id);


--
-- Name: moderation_rules_user_id_rule_type_unique; Type: INDEX; Schema: public; Owner: streambot
--

CREATE UNIQUE INDEX moderation_rules_user_id_rule_type_unique ON public.moderation_rules USING btree (user_id, rule_type);


--
-- Name: oauth_sessions_expires_at_idx; Type: INDEX; Schema: public; Owner: streambot
--

CREATE INDEX oauth_sessions_expires_at_idx ON public.oauth_sessions USING btree (expires_at);


--
-- Name: oauth_sessions_state_idx; Type: INDEX; Schema: public; Owner: streambot
--

CREATE INDEX oauth_sessions_state_idx ON public.oauth_sessions USING btree (state);


--
-- Name: oauth_sessions_user_id_idx; Type: INDEX; Schema: public; Owner: streambot
--

CREATE INDEX oauth_sessions_user_id_idx ON public.oauth_sessions USING btree (user_id);


--
-- Name: obs_automations_user_id_name_unique; Type: INDEX; Schema: public; Owner: streambot
--

CREATE UNIQUE INDEX obs_automations_user_id_name_unique ON public.obs_automations USING btree (user_id, name);


--
-- Name: platform_connections_platform_platform_user_id_unique; Type: INDEX; Schema: public; Owner: streambot
--

CREATE UNIQUE INDEX platform_connections_platform_platform_user_id_unique ON public.platform_connections USING btree (platform, platform_user_id);


--
-- Name: platform_connections_user_id_platform_unique; Type: INDEX; Schema: public; Owner: streambot
--

CREATE UNIQUE INDEX platform_connections_user_id_platform_unique ON public.platform_connections USING btree (user_id, platform);


--
-- Name: platform_credential_metadata_connection_id_idx; Type: INDEX; Schema: public; Owner: streambot
--

CREATE INDEX platform_credential_metadata_connection_id_idx ON public.platform_credential_metadata USING btree (connection_id);


--
-- Name: platform_credential_metadata_platform_idx; Type: INDEX; Schema: public; Owner: streambot
--

CREATE INDEX platform_credential_metadata_platform_idx ON public.platform_credential_metadata USING btree (platform);


--
-- Name: platform_health_circuit_state_idx; Type: INDEX; Schema: public; Owner: streambot
--

CREATE INDEX platform_health_circuit_state_idx ON public.platform_health USING btree (circuit_state);


--
-- Name: platform_health_platform_idx; Type: INDEX; Schema: public; Owner: streambot
--

CREATE INDEX platform_health_platform_idx ON public.platform_health USING btree (platform);


--
-- Name: platform_stats_period_start_idx; Type: INDEX; Schema: public; Owner: streambot
--

CREATE INDEX platform_stats_period_start_idx ON public.platform_stats USING btree (period_start);


--
-- Name: platform_stats_user_platform_period_unique; Type: INDEX; Schema: public; Owner: streambot
--

CREATE UNIQUE INDEX platform_stats_user_platform_period_unique ON public.platform_stats USING btree (user_id, platform, period_type, period_start);


--
-- Name: poll_votes_poll_id_username_platform_unique; Type: INDEX; Schema: public; Owner: streambot
--

CREATE UNIQUE INDEX poll_votes_poll_id_username_platform_unique ON public.poll_votes USING btree (poll_id, username, platform);


--
-- Name: prediction_bets_prediction_id_username_platform_unique; Type: INDEX; Schema: public; Owner: streambot
--

CREATE UNIQUE INDEX prediction_bets_prediction_id_username_platform_unique ON public.prediction_bets USING btree (prediction_id, username, platform);


--
-- Name: sentiment_analysis_user_id_date_unique; Type: INDEX; Schema: public; Owner: streambot
--

CREATE UNIQUE INDEX sentiment_analysis_user_id_date_unique ON public.sentiment_analysis USING btree (user_id, date);


--
-- Name: shoutouts_user_id_target_username_platform_unique; Type: INDEX; Schema: public; Owner: streambot
--

CREATE UNIQUE INDEX shoutouts_user_id_target_username_platform_unique ON public.shoutouts USING btree (user_id, target_username, target_platform);


--
-- Name: speech_to_text_queue_created_at_idx; Type: INDEX; Schema: public; Owner: streambot
--

CREATE INDEX speech_to_text_queue_created_at_idx ON public.speech_to_text_queue USING btree (created_at);


--
-- Name: speech_to_text_queue_status_idx; Type: INDEX; Schema: public; Owner: streambot
--

CREATE INDEX speech_to_text_queue_status_idx ON public.speech_to_text_queue USING btree (status);


--
-- Name: speech_to_text_queue_user_id_idx; Type: INDEX; Schema: public; Owner: streambot
--

CREATE INDEX speech_to_text_queue_user_id_idx ON public.speech_to_text_queue USING btree (user_id);


--
-- Name: token_expiry_alerts_alert_type_idx; Type: INDEX; Schema: public; Owner: streambot
--

CREATE INDEX token_expiry_alerts_alert_type_idx ON public.token_expiry_alerts USING btree (alert_type);


--
-- Name: token_expiry_alerts_platform_idx; Type: INDEX; Schema: public; Owner: streambot
--

CREATE INDEX token_expiry_alerts_platform_idx ON public.token_expiry_alerts USING btree (platform);


--
-- Name: token_expiry_alerts_user_id_idx; Type: INDEX; Schema: public; Owner: streambot
--

CREATE INDEX token_expiry_alerts_user_id_idx ON public.token_expiry_alerts USING btree (user_id);


--
-- Name: token_rollback_storage_connection_id_idx; Type: INDEX; Schema: public; Owner: streambot
--

CREATE INDEX token_rollback_storage_connection_id_idx ON public.token_rollback_storage USING btree (connection_id);


--
-- Name: token_rollback_storage_expires_at_idx; Type: INDEX; Schema: public; Owner: streambot
--

CREATE INDEX token_rollback_storage_expires_at_idx ON public.token_rollback_storage USING btree (expires_at);


--
-- Name: token_rotation_history_platform_idx; Type: INDEX; Schema: public; Owner: streambot
--

CREATE INDEX token_rotation_history_platform_idx ON public.token_rotation_history USING btree (platform);


--
-- Name: token_rotation_history_rotated_at_idx; Type: INDEX; Schema: public; Owner: streambot
--

CREATE INDEX token_rotation_history_rotated_at_idx ON public.token_rotation_history USING btree (rotated_at);


--
-- Name: token_rotation_history_user_id_idx; Type: INDEX; Schema: public; Owner: streambot
--

CREATE INDEX token_rotation_history_user_id_idx ON public.token_rotation_history USING btree (user_id);


--
-- Name: transcriptions_created_at_idx; Type: INDEX; Schema: public; Owner: streambot
--

CREATE INDEX transcriptions_created_at_idx ON public.transcriptions USING btree (created_at);


--
-- Name: transcriptions_queue_id_idx; Type: INDEX; Schema: public; Owner: streambot
--

CREATE INDEX transcriptions_queue_id_idx ON public.transcriptions USING btree (queue_id);


--
-- Name: transcriptions_user_id_idx; Type: INDEX; Schema: public; Owner: streambot
--

CREATE INDEX transcriptions_user_id_idx ON public.transcriptions USING btree (user_id);


--
-- Name: user_balances_bot_user_id_username_platform_unique; Type: INDEX; Schema: public; Owner: streambot
--

CREATE UNIQUE INDEX user_balances_bot_user_id_username_platform_unique ON public.user_balances USING btree (bot_user_id, username, platform);


--
-- Name: user_topic_preferences_user_topic_unique; Type: INDEX; Schema: public; Owner: streambot
--

CREATE UNIQUE INDEX user_topic_preferences_user_topic_unique ON public.user_topic_preferences USING btree (user_id, topic);


--
-- Name: active_trivia_questions active_trivia_questions_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.active_trivia_questions
    ADD CONSTRAINT active_trivia_questions_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: alert_history alert_history_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.alert_history
    ADD CONSTRAINT alert_history_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: alert_settings alert_settings_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.alert_settings
    ADD CONSTRAINT alert_settings_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: analytics_snapshots analytics_snapshots_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.analytics_snapshots
    ADD CONSTRAINT analytics_snapshots_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: bot_configs bot_configs_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.bot_configs
    ADD CONSTRAINT bot_configs_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: bot_instances bot_instances_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.bot_instances
    ADD CONSTRAINT bot_instances_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: chat_activity chat_activity_session_id_stream_sessions_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.chat_activity
    ADD CONSTRAINT chat_activity_session_id_stream_sessions_id_fk FOREIGN KEY (session_id) REFERENCES public.stream_sessions(id) ON DELETE CASCADE;


--
-- Name: chatbot_context chatbot_context_bot_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.chatbot_context
    ADD CONSTRAINT chatbot_context_bot_user_id_users_id_fk FOREIGN KEY (bot_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: chatbot_personalities chatbot_personalities_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.chatbot_personalities
    ADD CONSTRAINT chatbot_personalities_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: chatbot_responses chatbot_responses_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.chatbot_responses
    ADD CONSTRAINT chatbot_responses_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: chatbot_settings chatbot_settings_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.chatbot_settings
    ADD CONSTRAINT chatbot_settings_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: currency_rewards currency_rewards_bot_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.currency_rewards
    ADD CONSTRAINT currency_rewards_bot_user_id_users_id_fk FOREIGN KEY (bot_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: currency_settings currency_settings_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.currency_settings
    ADD CONSTRAINT currency_settings_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: currency_transactions currency_transactions_balance_id_user_balances_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.currency_transactions
    ADD CONSTRAINT currency_transactions_balance_id_user_balances_id_fk FOREIGN KEY (balance_id) REFERENCES public.user_balances(id) ON DELETE CASCADE;


--
-- Name: custom_commands custom_commands_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.custom_commands
    ADD CONSTRAINT custom_commands_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: enhanced_moderation_settings enhanced_moderation_settings_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.enhanced_moderation_settings
    ADD CONSTRAINT enhanced_moderation_settings_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: fact_analytics fact_analytics_fact_id_facts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.fact_analytics
    ADD CONSTRAINT fact_analytics_fact_id_facts_id_fk FOREIGN KEY (fact_id) REFERENCES public.facts(id) ON DELETE SET NULL;


--
-- Name: fact_analytics fact_analytics_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.fact_analytics
    ADD CONSTRAINT fact_analytics_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: feature_toggles feature_toggles_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.feature_toggles
    ADD CONSTRAINT feature_toggles_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: game_history game_history_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.game_history
    ADD CONSTRAINT game_history_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: game_settings game_settings_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.game_settings
    ADD CONSTRAINT game_settings_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: game_stats game_stats_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.game_stats
    ADD CONSTRAINT game_stats_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: giveaway_entries giveaway_entries_giveaway_id_giveaways_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.giveaway_entries
    ADD CONSTRAINT giveaway_entries_giveaway_id_giveaways_id_fk FOREIGN KEY (giveaway_id) REFERENCES public.giveaways(id) ON DELETE CASCADE;


--
-- Name: giveaway_entries giveaway_entries_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.giveaway_entries
    ADD CONSTRAINT giveaway_entries_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: giveaway_entry_attempts giveaway_entry_attempts_giveaway_id_giveaways_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.giveaway_entry_attempts
    ADD CONSTRAINT giveaway_entry_attempts_giveaway_id_giveaways_id_fk FOREIGN KEY (giveaway_id) REFERENCES public.giveaways(id) ON DELETE CASCADE;


--
-- Name: giveaway_entry_attempts giveaway_entry_attempts_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.giveaway_entry_attempts
    ADD CONSTRAINT giveaway_entry_attempts_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: giveaway_winners giveaway_winners_giveaway_id_giveaways_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.giveaway_winners
    ADD CONSTRAINT giveaway_winners_giveaway_id_giveaways_id_fk FOREIGN KEY (giveaway_id) REFERENCES public.giveaways(id) ON DELETE CASCADE;


--
-- Name: giveaways giveaways_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.giveaways
    ADD CONSTRAINT giveaways_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: intent_classifications intent_classifications_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.intent_classifications
    ADD CONSTRAINT intent_classifications_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: job_queue job_queue_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.job_queue
    ADD CONSTRAINT job_queue_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: link_whitelist link_whitelist_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.link_whitelist
    ADD CONSTRAINT link_whitelist_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: message_history message_history_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.message_history
    ADD CONSTRAINT message_history_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: message_queue message_queue_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.message_queue
    ADD CONSTRAINT message_queue_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: milestones milestones_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.milestones
    ADD CONSTRAINT milestones_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: moderation_action_log moderation_action_log_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.moderation_action_log
    ADD CONSTRAINT moderation_action_log_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: moderation_logs moderation_logs_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.moderation_logs
    ADD CONSTRAINT moderation_logs_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: moderation_rules moderation_rules_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.moderation_rules
    ADD CONSTRAINT moderation_rules_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: obs_automations obs_automations_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.obs_automations
    ADD CONSTRAINT obs_automations_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: obs_connections obs_connections_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.obs_connections
    ADD CONSTRAINT obs_connections_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: onboarding_progress onboarding_progress_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.onboarding_progress
    ADD CONSTRAINT onboarding_progress_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: platform_connections platform_connections_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.platform_connections
    ADD CONSTRAINT platform_connections_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: platform_credential_metadata platform_credential_metadata_connection_id_platform_connections; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.platform_credential_metadata
    ADD CONSTRAINT platform_credential_metadata_connection_id_platform_connections FOREIGN KEY (connection_id) REFERENCES public.platform_connections(id) ON DELETE CASCADE;


--
-- Name: platform_stats platform_stats_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.platform_stats
    ADD CONSTRAINT platform_stats_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: poll_votes poll_votes_poll_id_polls_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.poll_votes
    ADD CONSTRAINT poll_votes_poll_id_polls_id_fk FOREIGN KEY (poll_id) REFERENCES public.polls(id) ON DELETE CASCADE;


--
-- Name: polls polls_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.polls
    ADD CONSTRAINT polls_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: prediction_bets prediction_bets_prediction_id_predictions_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.prediction_bets
    ADD CONSTRAINT prediction_bets_prediction_id_predictions_id_fk FOREIGN KEY (prediction_id) REFERENCES public.predictions(id) ON DELETE CASCADE;


--
-- Name: predictions predictions_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.predictions
    ADD CONSTRAINT predictions_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: reward_redemptions reward_redemptions_bot_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.reward_redemptions
    ADD CONSTRAINT reward_redemptions_bot_user_id_users_id_fk FOREIGN KEY (bot_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: reward_redemptions reward_redemptions_reward_id_currency_rewards_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.reward_redemptions
    ADD CONSTRAINT reward_redemptions_reward_id_currency_rewards_id_fk FOREIGN KEY (reward_id) REFERENCES public.currency_rewards(id) ON DELETE CASCADE;


--
-- Name: sentiment_analysis sentiment_analysis_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.sentiment_analysis
    ADD CONSTRAINT sentiment_analysis_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: shoutout_history shoutout_history_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.shoutout_history
    ADD CONSTRAINT shoutout_history_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: shoutout_settings shoutout_settings_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.shoutout_settings
    ADD CONSTRAINT shoutout_settings_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: shoutouts shoutouts_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.shoutouts
    ADD CONSTRAINT shoutouts_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: song_queue song_queue_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.song_queue
    ADD CONSTRAINT song_queue_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: song_settings song_settings_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.song_settings
    ADD CONSTRAINT song_settings_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: speech_to_text_queue speech_to_text_queue_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.speech_to_text_queue
    ADD CONSTRAINT speech_to_text_queue_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: stream_sessions stream_sessions_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.stream_sessions
    ADD CONSTRAINT stream_sessions_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: token_expiry_alerts token_expiry_alerts_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.token_expiry_alerts
    ADD CONSTRAINT token_expiry_alerts_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: token_rollback_storage token_rollback_storage_connection_id_platform_connections_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.token_rollback_storage
    ADD CONSTRAINT token_rollback_storage_connection_id_platform_connections_id_fk FOREIGN KEY (connection_id) REFERENCES public.platform_connections(id) ON DELETE CASCADE;


--
-- Name: token_rollback_storage token_rollback_storage_rotation_id_token_rotation_history_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.token_rollback_storage
    ADD CONSTRAINT token_rollback_storage_rotation_id_token_rotation_history_id_fk FOREIGN KEY (rotation_id) REFERENCES public.token_rotation_history(id) ON DELETE CASCADE;


--
-- Name: token_rollback_storage token_rollback_storage_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.token_rollback_storage
    ADD CONSTRAINT token_rollback_storage_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: token_rotation_history token_rotation_history_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.token_rotation_history
    ADD CONSTRAINT token_rotation_history_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: transcriptions transcriptions_queue_id_speech_to_text_queue_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.transcriptions
    ADD CONSTRAINT transcriptions_queue_id_speech_to_text_queue_id_fk FOREIGN KEY (queue_id) REFERENCES public.speech_to_text_queue(id) ON DELETE SET NULL;


--
-- Name: transcriptions transcriptions_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.transcriptions
    ADD CONSTRAINT transcriptions_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_balances user_balances_bot_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.user_balances
    ADD CONSTRAINT user_balances_bot_user_id_users_id_fk FOREIGN KEY (bot_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_topic_preferences user_topic_preferences_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.user_topic_preferences
    ADD CONSTRAINT user_topic_preferences_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: viewer_snapshots viewer_snapshots_session_id_stream_sessions_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: streambot
--

ALTER TABLE ONLY public.viewer_snapshots
    ADD CONSTRAINT viewer_snapshots_session_id_stream_sessions_id_fk FOREIGN KEY (session_id) REFERENCES public.stream_sessions(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict 5QeS2x8nyaAedkQ8j8WY23bHwWG4faD5omdri3vyr272mlqDIZXFthNuq7A9chf

--
-- Database "ticketbot" dump
--

--
-- PostgreSQL database dump
--

\restrict dzwbFdPpMF2rmYeQb77GAS4bhAqLyocEHuDLnBfctzefdtmugsX2jIsL0O9ykqX

-- Dumped from database version 16.11
-- Dumped by pg_dump version 16.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: ticketbot; Type: DATABASE; Schema: -; Owner: ticketbot
--

CREATE DATABASE ticketbot WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE ticketbot OWNER TO ticketbot;

\unrestrict dzwbFdPpMF2rmYeQb77GAS4bhAqLyocEHuDLnBfctzefdtmugsX2jIsL0O9ykqX
\connect ticketbot
\restrict dzwbFdPpMF2rmYeQb77GAS4bhAqLyocEHuDLnBfctzefdtmugsX2jIsL0O9ykqX

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: bot_settings; Type: TABLE; Schema: public; Owner: ticketbot
--

CREATE TABLE public.bot_settings (
    id integer NOT NULL,
    server_id text NOT NULL,
    bot_name text DEFAULT 'Ticket Bot'::text,
    bot_nickname text,
    bot_prefix text DEFAULT '!'::text,
    welcome_message text DEFAULT 'Thank you for creating a ticket. Our support team will assist you shortly.'::text,
    notifications_enabled boolean DEFAULT true,
    admin_role_id text,
    support_role_id text,
    auto_close_enabled boolean DEFAULT false,
    auto_close_hours text DEFAULT '48'::text,
    default_priority text DEFAULT 'normal'::text,
    debug_mode boolean DEFAULT false,
    log_channel_id text,
    ticket_channel_id text,
    dashboard_url text,
    admin_channel_id text,
    public_log_channel_id text,
    admin_notifications_enabled boolean DEFAULT true,
    send_copy_to_admin_channel boolean DEFAULT false,
    thread_integration_enabled boolean DEFAULT false,
    thread_channel_id text,
    thread_auto_create boolean DEFAULT true,
    thread_bidirectional_sync boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.bot_settings OWNER TO ticketbot;

--
-- Name: bot_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: ticketbot
--

CREATE SEQUENCE public.bot_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.bot_settings_id_seq OWNER TO ticketbot;

--
-- Name: bot_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ticketbot
--

ALTER SEQUENCE public.bot_settings_id_seq OWNED BY public.bot_settings.id;


--
-- Name: developer_audit_log; Type: TABLE; Schema: public; Owner: ticketbot
--

CREATE TABLE public.developer_audit_log (
    id integer NOT NULL,
    developer_id text NOT NULL,
    action text NOT NULL,
    metadata text,
    ip_address text,
    user_agent text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.developer_audit_log OWNER TO ticketbot;

--
-- Name: developer_audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: ticketbot
--

CREATE SEQUENCE public.developer_audit_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.developer_audit_log_id_seq OWNER TO ticketbot;

--
-- Name: developer_audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ticketbot
--

ALTER SEQUENCE public.developer_audit_log_id_seq OWNED BY public.developer_audit_log.id;


--
-- Name: developers; Type: TABLE; Schema: public; Owner: ticketbot
--

CREATE TABLE public.developers (
    id integer NOT NULL,
    discord_id text NOT NULL,
    username text NOT NULL,
    added_by text,
    added_at timestamp without time zone DEFAULT now(),
    is_active boolean DEFAULT true
);


ALTER TABLE public.developers OWNER TO ticketbot;

--
-- Name: developers_id_seq; Type: SEQUENCE; Schema: public; Owner: ticketbot
--

CREATE SEQUENCE public.developers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.developers_id_seq OWNER TO ticketbot;

--
-- Name: developers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ticketbot
--

ALTER SEQUENCE public.developers_id_seq OWNED BY public.developers.id;


--
-- Name: discord_users; Type: TABLE; Schema: public; Owner: ticketbot
--

CREATE TABLE public.discord_users (
    id text NOT NULL,
    username text NOT NULL,
    discriminator text NOT NULL,
    avatar text,
    is_admin boolean DEFAULT false,
    server_id text,
    onboarding_completed boolean DEFAULT false,
    first_login_at timestamp without time zone DEFAULT now(),
    last_seen_at timestamp without time zone DEFAULT now(),
    admin_guilds text,
    connected_servers text
);


ALTER TABLE public.discord_users OWNER TO ticketbot;

--
-- Name: escalation_history; Type: TABLE; Schema: public; Owner: ticketbot
--

CREATE TABLE public.escalation_history (
    id integer NOT NULL,
    ticket_id integer NOT NULL,
    server_id text NOT NULL,
    rule_id integer,
    from_level integer NOT NULL,
    to_level integer NOT NULL,
    reason text NOT NULL,
    triggered_by text,
    previous_assignee_id text,
    new_assignee_id text,
    notification_sent boolean DEFAULT false,
    message_id text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.escalation_history OWNER TO ticketbot;

--
-- Name: escalation_history_id_seq; Type: SEQUENCE; Schema: public; Owner: ticketbot
--

CREATE SEQUENCE public.escalation_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.escalation_history_id_seq OWNER TO ticketbot;

--
-- Name: escalation_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ticketbot
--

ALTER SEQUENCE public.escalation_history_id_seq OWNED BY public.escalation_history.id;


--
-- Name: escalation_rules; Type: TABLE; Schema: public; Owner: ticketbot
--

CREATE TABLE public.escalation_rules (
    id integer NOT NULL,
    server_id text NOT NULL,
    name text NOT NULL,
    description text,
    trigger_type text NOT NULL,
    trigger_value text,
    escalation_level integer DEFAULT 1,
    target_role_id text,
    notify_channel_id text,
    priority integer DEFAULT 0,
    is_enabled boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.escalation_rules OWNER TO ticketbot;

--
-- Name: escalation_rules_id_seq; Type: SEQUENCE; Schema: public; Owner: ticketbot
--

CREATE SEQUENCE public.escalation_rules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.escalation_rules_id_seq OWNER TO ticketbot;

--
-- Name: escalation_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ticketbot
--

ALTER SEQUENCE public.escalation_rules_id_seq OWNED BY public.escalation_rules.id;


--
-- Name: guild_provisioning_status; Type: TABLE; Schema: public; Owner: ticketbot
--

CREATE TABLE public.guild_provisioning_status (
    id integer NOT NULL,
    server_id text NOT NULL,
    provisioning_started_at timestamp without time zone DEFAULT now(),
    provisioning_completed_at timestamp without time zone,
    categories_created boolean DEFAULT false,
    settings_created boolean DEFAULT false,
    welcome_sent boolean DEFAULT false,
    ticket_category_channel_id text,
    support_channel_id text,
    log_channel_id text,
    status text DEFAULT 'pending'::text,
    error_message text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.guild_provisioning_status OWNER TO ticketbot;

--
-- Name: guild_provisioning_status_id_seq; Type: SEQUENCE; Schema: public; Owner: ticketbot
--

CREATE SEQUENCE public.guild_provisioning_status_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.guild_provisioning_status_id_seq OWNER TO ticketbot;

--
-- Name: guild_provisioning_status_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ticketbot
--

ALTER SEQUENCE public.guild_provisioning_status_id_seq OWNED BY public.guild_provisioning_status.id;


--
-- Name: interaction_locks; Type: TABLE; Schema: public; Owner: ticketbot
--

CREATE TABLE public.interaction_locks (
    interaction_id text NOT NULL,
    user_id text NOT NULL,
    action_type text NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.interaction_locks OWNER TO ticketbot;

--
-- Name: panel_template_buttons; Type: TABLE; Schema: public; Owner: ticketbot
--

CREATE TABLE public.panel_template_buttons (
    id integer NOT NULL,
    template_id integer NOT NULL,
    custom_id text NOT NULL,
    label text NOT NULL,
    emoji text,
    button_style text DEFAULT 'Primary'::text NOT NULL,
    url text,
    action_type text DEFAULT 'custom'::text NOT NULL,
    action_data text,
    "row" integer DEFAULT 1,
    "position" integer DEFAULT 0,
    is_enabled boolean DEFAULT true,
    requires_role text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.panel_template_buttons OWNER TO ticketbot;

--
-- Name: panel_template_buttons_id_seq; Type: SEQUENCE; Schema: public; Owner: ticketbot
--

CREATE SEQUENCE public.panel_template_buttons_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.panel_template_buttons_id_seq OWNER TO ticketbot;

--
-- Name: panel_template_buttons_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ticketbot
--

ALTER SEQUENCE public.panel_template_buttons_id_seq OWNED BY public.panel_template_buttons.id;


--
-- Name: panel_template_fields; Type: TABLE; Schema: public; Owner: ticketbot
--

CREATE TABLE public.panel_template_fields (
    id integer NOT NULL,
    template_id integer NOT NULL,
    name text NOT NULL,
    value text NOT NULL,
    inline boolean DEFAULT false,
    sort_order integer DEFAULT 0,
    is_enabled boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.panel_template_fields OWNER TO ticketbot;

--
-- Name: panel_template_fields_id_seq; Type: SEQUENCE; Schema: public; Owner: ticketbot
--

CREATE SEQUENCE public.panel_template_fields_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.panel_template_fields_id_seq OWNER TO ticketbot;

--
-- Name: panel_template_fields_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ticketbot
--

ALTER SEQUENCE public.panel_template_fields_id_seq OWNED BY public.panel_template_fields.id;


--
-- Name: panel_templates; Type: TABLE; Schema: public; Owner: ticketbot
--

CREATE TABLE public.panel_templates (
    id integer NOT NULL,
    server_id text NOT NULL,
    name text NOT NULL,
    description text,
    type text DEFAULT 'custom'::text NOT NULL,
    embed_title text,
    embed_description text,
    embed_color text DEFAULT '#5865F2'::text,
    embed_url text,
    author_name text,
    author_icon_url text,
    author_url text,
    thumbnail_url text,
    image_url text,
    footer_text text,
    footer_icon_url text,
    show_timestamp boolean DEFAULT false,
    is_enabled boolean DEFAULT true,
    is_ticket_panel boolean DEFAULT false,
    last_used timestamp without time zone,
    use_count integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.panel_templates OWNER TO ticketbot;

--
-- Name: panel_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: ticketbot
--

CREATE SEQUENCE public.panel_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.panel_templates_id_seq OWNER TO ticketbot;

--
-- Name: panel_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ticketbot
--

ALTER SEQUENCE public.panel_templates_id_seq OWNED BY public.panel_templates.id;


--
-- Name: server_role_permissions; Type: TABLE; Schema: public; Owner: ticketbot
--

CREATE TABLE public.server_role_permissions (
    id integer NOT NULL,
    server_id text NOT NULL,
    role_id text NOT NULL,
    role_name text NOT NULL,
    can_view_tickets boolean DEFAULT true,
    can_manage_tickets boolean DEFAULT true,
    can_delete_tickets boolean DEFAULT false,
    can_manage_settings boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.server_role_permissions OWNER TO ticketbot;

--
-- Name: server_role_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: ticketbot
--

CREATE SEQUENCE public.server_role_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.server_role_permissions_id_seq OWNER TO ticketbot;

--
-- Name: server_role_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ticketbot
--

ALTER SEQUENCE public.server_role_permissions_id_seq OWNED BY public.server_role_permissions.id;


--
-- Name: servers; Type: TABLE; Schema: public; Owner: ticketbot
--

CREATE TABLE public.servers (
    id text NOT NULL,
    name text NOT NULL,
    icon text,
    owner_id text,
    admin_role_id text,
    support_role_id text,
    is_active boolean DEFAULT true
);


ALTER TABLE public.servers OWNER TO ticketbot;

--
-- Name: sla_configurations; Type: TABLE; Schema: public; Owner: ticketbot
--

CREATE TABLE public.sla_configurations (
    id integer NOT NULL,
    server_id text NOT NULL,
    priority text NOT NULL,
    response_time_minutes integer NOT NULL,
    resolution_time_minutes integer,
    escalation_time_minutes integer,
    notify_on_breach boolean DEFAULT true,
    notify_channel_id text,
    is_enabled boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.sla_configurations OWNER TO ticketbot;

--
-- Name: sla_configurations_id_seq; Type: SEQUENCE; Schema: public; Owner: ticketbot
--

CREATE SEQUENCE public.sla_configurations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sla_configurations_id_seq OWNER TO ticketbot;

--
-- Name: sla_configurations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ticketbot
--

ALTER SEQUENCE public.sla_configurations_id_seq OWNED BY public.sla_configurations.id;


--
-- Name: sla_tracking; Type: TABLE; Schema: public; Owner: ticketbot
--

CREATE TABLE public.sla_tracking (
    id integer NOT NULL,
    ticket_id integer NOT NULL,
    server_id text NOT NULL,
    sla_config_id integer,
    response_deadline timestamp without time zone,
    resolution_deadline timestamp without time zone,
    first_responded_at timestamp without time zone,
    response_breached boolean DEFAULT false,
    resolution_breached boolean DEFAULT false,
    breach_notified_at timestamp without time zone,
    escalated_at timestamp without time zone,
    status text DEFAULT 'active'::text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.sla_tracking OWNER TO ticketbot;

--
-- Name: sla_tracking_id_seq; Type: SEQUENCE; Schema: public; Owner: ticketbot
--

CREATE SEQUENCE public.sla_tracking_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sla_tracking_id_seq OWNER TO ticketbot;

--
-- Name: sla_tracking_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ticketbot
--

ALTER SEQUENCE public.sla_tracking_id_seq OWNED BY public.sla_tracking.id;


--
-- Name: stream_notification_log; Type: TABLE; Schema: public; Owner: ticketbot
--

CREATE TABLE public.stream_notification_log (
    id integer NOT NULL,
    server_id text NOT NULL,
    user_id text NOT NULL,
    stream_title text,
    stream_url text,
    platform text,
    message_id text,
    notified_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.stream_notification_log OWNER TO ticketbot;

--
-- Name: stream_notification_log_id_seq; Type: SEQUENCE; Schema: public; Owner: ticketbot
--

CREATE SEQUENCE public.stream_notification_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.stream_notification_log_id_seq OWNER TO ticketbot;

--
-- Name: stream_notification_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ticketbot
--

ALTER SEQUENCE public.stream_notification_log_id_seq OWNED BY public.stream_notification_log.id;


--
-- Name: stream_notification_settings; Type: TABLE; Schema: public; Owner: ticketbot
--

CREATE TABLE public.stream_notification_settings (
    id integer NOT NULL,
    server_id text NOT NULL,
    notification_channel_id text,
    is_enabled boolean DEFAULT true,
    mention_role text,
    custom_message text,
    auto_detect_enabled boolean DEFAULT false,
    auto_sync_interval_minutes integer DEFAULT 60,
    last_auto_sync_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.stream_notification_settings OWNER TO ticketbot;

--
-- Name: stream_notification_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: ticketbot
--

CREATE SEQUENCE public.stream_notification_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.stream_notification_settings_id_seq OWNER TO ticketbot;

--
-- Name: stream_notification_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ticketbot
--

ALTER SEQUENCE public.stream_notification_settings_id_seq OWNED BY public.stream_notification_settings.id;


--
-- Name: stream_tracked_users; Type: TABLE; Schema: public; Owner: ticketbot
--

CREATE TABLE public.stream_tracked_users (
    id integer NOT NULL,
    server_id text NOT NULL,
    user_id text NOT NULL,
    username text,
    is_active boolean DEFAULT true,
    last_notified_at timestamp without time zone,
    auto_detected boolean DEFAULT false,
    connected_platforms text,
    platform_usernames text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.stream_tracked_users OWNER TO ticketbot;

--
-- Name: stream_tracked_users_id_seq; Type: SEQUENCE; Schema: public; Owner: ticketbot
--

CREATE SEQUENCE public.stream_tracked_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.stream_tracked_users_id_seq OWNER TO ticketbot;

--
-- Name: stream_tracked_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ticketbot
--

ALTER SEQUENCE public.stream_tracked_users_id_seq OWNED BY public.stream_tracked_users.id;


--
-- Name: thread_mappings; Type: TABLE; Schema: public; Owner: ticketbot
--

CREATE TABLE public.thread_mappings (
    id integer NOT NULL,
    server_id text NOT NULL,
    thread_id text NOT NULL,
    ticket_id integer NOT NULL,
    channel_id text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    sync_enabled boolean DEFAULT true,
    last_synced_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.thread_mappings OWNER TO ticketbot;

--
-- Name: thread_mappings_id_seq; Type: SEQUENCE; Schema: public; Owner: ticketbot
--

CREATE SEQUENCE public.thread_mappings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.thread_mappings_id_seq OWNER TO ticketbot;

--
-- Name: thread_mappings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ticketbot
--

ALTER SEQUENCE public.thread_mappings_id_seq OWNED BY public.thread_mappings.id;


--
-- Name: ticket_audit_log; Type: TABLE; Schema: public; Owner: ticketbot
--

CREATE TABLE public.ticket_audit_log (
    id integer NOT NULL,
    ticket_id integer NOT NULL,
    action text NOT NULL,
    performed_by text NOT NULL,
    performed_by_username text,
    details text,
    created_at timestamp without time zone DEFAULT now(),
    server_id text
);


ALTER TABLE public.ticket_audit_log OWNER TO ticketbot;

--
-- Name: ticket_audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: ticketbot
--

CREATE SEQUENCE public.ticket_audit_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ticket_audit_log_id_seq OWNER TO ticketbot;

--
-- Name: ticket_audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ticketbot
--

ALTER SEQUENCE public.ticket_audit_log_id_seq OWNED BY public.ticket_audit_log.id;


--
-- Name: ticket_categories; Type: TABLE; Schema: public; Owner: ticketbot
--

CREATE TABLE public.ticket_categories (
    id integer NOT NULL,
    name text NOT NULL,
    emoji text DEFAULT '🎫'::text,
    color text DEFAULT '#5865F2'::text NOT NULL,
    server_id text
);


ALTER TABLE public.ticket_categories OWNER TO ticketbot;

--
-- Name: ticket_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: ticketbot
--

CREATE SEQUENCE public.ticket_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ticket_categories_id_seq OWNER TO ticketbot;

--
-- Name: ticket_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ticketbot
--

ALTER SEQUENCE public.ticket_categories_id_seq OWNED BY public.ticket_categories.id;


--
-- Name: ticket_messages; Type: TABLE; Schema: public; Owner: ticketbot
--

CREATE TABLE public.ticket_messages (
    id integer NOT NULL,
    ticket_id integer NOT NULL,
    sender_id text NOT NULL,
    content text NOT NULL,
    sender_username text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.ticket_messages OWNER TO ticketbot;

--
-- Name: ticket_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: ticketbot
--

CREATE SEQUENCE public.ticket_messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ticket_messages_id_seq OWNER TO ticketbot;

--
-- Name: ticket_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ticketbot
--

ALTER SEQUENCE public.ticket_messages_id_seq OWNED BY public.ticket_messages.id;


--
-- Name: ticket_panel_categories; Type: TABLE; Schema: public; Owner: ticketbot
--

CREATE TABLE public.ticket_panel_categories (
    id integer NOT NULL,
    server_id text NOT NULL,
    ticket_category_id integer NOT NULL,
    name text NOT NULL,
    description text,
    emoji text DEFAULT '🎫'::text NOT NULL,
    button_style text DEFAULT 'Primary'::text NOT NULL,
    is_enabled boolean DEFAULT true,
    sort_order integer DEFAULT 0,
    custom_id text NOT NULL,
    requires_role text,
    welcome_message text,
    assign_to_role text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.ticket_panel_categories OWNER TO ticketbot;

--
-- Name: ticket_panel_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: ticketbot
--

CREATE SEQUENCE public.ticket_panel_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ticket_panel_categories_id_seq OWNER TO ticketbot;

--
-- Name: ticket_panel_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ticketbot
--

ALTER SEQUENCE public.ticket_panel_categories_id_seq OWNED BY public.ticket_panel_categories.id;


--
-- Name: ticket_panel_settings; Type: TABLE; Schema: public; Owner: ticketbot
--

CREATE TABLE public.ticket_panel_settings (
    id integer NOT NULL,
    server_id text NOT NULL,
    title text DEFAULT '🎫 Support Ticket System'::text NOT NULL,
    description text DEFAULT '**Welcome to our support ticket system!**

Click one of the buttons below to create a new support ticket. Our team will respond as quickly as possible.

*Please provide as much detail as possible when creating your ticket to help us assist you better.*'::text NOT NULL,
    embed_color text DEFAULT '#5865F2'::text NOT NULL,
    footer_text text DEFAULT 'Click a button below to get started • Support Team'::text NOT NULL,
    show_timestamp boolean DEFAULT true,
    thumbnail_url text,
    author_name text,
    author_icon_url text,
    buttons_per_row integer DEFAULT 2,
    show_categories_in_description boolean DEFAULT true,
    max_categories integer DEFAULT 25,
    is_enabled boolean DEFAULT true,
    require_reason boolean DEFAULT true,
    cooldown_minutes integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.ticket_panel_settings OWNER TO ticketbot;

--
-- Name: ticket_panel_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: ticketbot
--

CREATE SEQUENCE public.ticket_panel_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ticket_panel_settings_id_seq OWNER TO ticketbot;

--
-- Name: ticket_panel_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ticketbot
--

ALTER SEQUENCE public.ticket_panel_settings_id_seq OWNED BY public.ticket_panel_settings.id;


--
-- Name: ticket_resolutions; Type: TABLE; Schema: public; Owner: ticketbot
--

CREATE TABLE public.ticket_resolutions (
    id integer NOT NULL,
    ticket_id integer NOT NULL,
    resolution_type text NOT NULL,
    resolution_notes text,
    action_taken text,
    resolved_by text NOT NULL,
    resolved_by_username text,
    resolved_at timestamp without time zone DEFAULT now(),
    server_id text
);


ALTER TABLE public.ticket_resolutions OWNER TO ticketbot;

--
-- Name: ticket_resolutions_id_seq; Type: SEQUENCE; Schema: public; Owner: ticketbot
--

CREATE SEQUENCE public.ticket_resolutions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ticket_resolutions_id_seq OWNER TO ticketbot;

--
-- Name: ticket_resolutions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ticketbot
--

ALTER SEQUENCE public.ticket_resolutions_id_seq OWNED BY public.ticket_resolutions.id;


--
-- Name: tickets; Type: TABLE; Schema: public; Owner: ticketbot
--

CREATE TABLE public.tickets (
    id integer NOT NULL,
    discord_id text,
    title text NOT NULL,
    description text NOT NULL,
    status text DEFAULT 'open'::text NOT NULL,
    priority text DEFAULT 'normal'::text,
    category_id integer,
    creator_id text NOT NULL,
    assignee_id text,
    server_id text,
    mediation_actions text,
    user_actions text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.tickets OWNER TO ticketbot;

--
-- Name: tickets_id_seq; Type: SEQUENCE; Schema: public; Owner: ticketbot
--

CREATE SEQUENCE public.tickets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tickets_id_seq OWNER TO ticketbot;

--
-- Name: tickets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ticketbot
--

ALTER SEQUENCE public.tickets_id_seq OWNED BY public.tickets.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: ticketbot
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username text NOT NULL,
    password text NOT NULL
);


ALTER TABLE public.users OWNER TO ticketbot;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: ticketbot
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO ticketbot;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ticketbot
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: webhook_configurations; Type: TABLE; Schema: public; Owner: ticketbot
--

CREATE TABLE public.webhook_configurations (
    id integer NOT NULL,
    server_id text NOT NULL,
    name text NOT NULL,
    description text,
    webhook_url text,
    webhook_secret text,
    event_types text NOT NULL,
    target_channel_id text,
    is_inbound boolean DEFAULT true,
    is_enabled boolean DEFAULT true,
    last_triggered_at timestamp without time zone,
    failure_count integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.webhook_configurations OWNER TO ticketbot;

--
-- Name: webhook_configurations_id_seq; Type: SEQUENCE; Schema: public; Owner: ticketbot
--

CREATE SEQUENCE public.webhook_configurations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.webhook_configurations_id_seq OWNER TO ticketbot;

--
-- Name: webhook_configurations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ticketbot
--

ALTER SEQUENCE public.webhook_configurations_id_seq OWNED BY public.webhook_configurations.id;


--
-- Name: webhook_event_log; Type: TABLE; Schema: public; Owner: ticketbot
--

CREATE TABLE public.webhook_event_log (
    id integer NOT NULL,
    webhook_id integer,
    server_id text NOT NULL,
    event_type text NOT NULL,
    payload text,
    direction text NOT NULL,
    status_code integer,
    response text,
    success boolean DEFAULT true,
    error_message text,
    processed_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.webhook_event_log OWNER TO ticketbot;

--
-- Name: webhook_event_log_id_seq; Type: SEQUENCE; Schema: public; Owner: ticketbot
--

CREATE SEQUENCE public.webhook_event_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.webhook_event_log_id_seq OWNER TO ticketbot;

--
-- Name: webhook_event_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ticketbot
--

ALTER SEQUENCE public.webhook_event_log_id_seq OWNED BY public.webhook_event_log.id;


--
-- Name: bot_settings id; Type: DEFAULT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.bot_settings ALTER COLUMN id SET DEFAULT nextval('public.bot_settings_id_seq'::regclass);


--
-- Name: developer_audit_log id; Type: DEFAULT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.developer_audit_log ALTER COLUMN id SET DEFAULT nextval('public.developer_audit_log_id_seq'::regclass);


--
-- Name: developers id; Type: DEFAULT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.developers ALTER COLUMN id SET DEFAULT nextval('public.developers_id_seq'::regclass);


--
-- Name: escalation_history id; Type: DEFAULT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.escalation_history ALTER COLUMN id SET DEFAULT nextval('public.escalation_history_id_seq'::regclass);


--
-- Name: escalation_rules id; Type: DEFAULT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.escalation_rules ALTER COLUMN id SET DEFAULT nextval('public.escalation_rules_id_seq'::regclass);


--
-- Name: guild_provisioning_status id; Type: DEFAULT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.guild_provisioning_status ALTER COLUMN id SET DEFAULT nextval('public.guild_provisioning_status_id_seq'::regclass);


--
-- Name: panel_template_buttons id; Type: DEFAULT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.panel_template_buttons ALTER COLUMN id SET DEFAULT nextval('public.panel_template_buttons_id_seq'::regclass);


--
-- Name: panel_template_fields id; Type: DEFAULT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.panel_template_fields ALTER COLUMN id SET DEFAULT nextval('public.panel_template_fields_id_seq'::regclass);


--
-- Name: panel_templates id; Type: DEFAULT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.panel_templates ALTER COLUMN id SET DEFAULT nextval('public.panel_templates_id_seq'::regclass);


--
-- Name: server_role_permissions id; Type: DEFAULT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.server_role_permissions ALTER COLUMN id SET DEFAULT nextval('public.server_role_permissions_id_seq'::regclass);


--
-- Name: sla_configurations id; Type: DEFAULT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.sla_configurations ALTER COLUMN id SET DEFAULT nextval('public.sla_configurations_id_seq'::regclass);


--
-- Name: sla_tracking id; Type: DEFAULT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.sla_tracking ALTER COLUMN id SET DEFAULT nextval('public.sla_tracking_id_seq'::regclass);


--
-- Name: stream_notification_log id; Type: DEFAULT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.stream_notification_log ALTER COLUMN id SET DEFAULT nextval('public.stream_notification_log_id_seq'::regclass);


--
-- Name: stream_notification_settings id; Type: DEFAULT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.stream_notification_settings ALTER COLUMN id SET DEFAULT nextval('public.stream_notification_settings_id_seq'::regclass);


--
-- Name: stream_tracked_users id; Type: DEFAULT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.stream_tracked_users ALTER COLUMN id SET DEFAULT nextval('public.stream_tracked_users_id_seq'::regclass);


--
-- Name: thread_mappings id; Type: DEFAULT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.thread_mappings ALTER COLUMN id SET DEFAULT nextval('public.thread_mappings_id_seq'::regclass);


--
-- Name: ticket_audit_log id; Type: DEFAULT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.ticket_audit_log ALTER COLUMN id SET DEFAULT nextval('public.ticket_audit_log_id_seq'::regclass);


--
-- Name: ticket_categories id; Type: DEFAULT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.ticket_categories ALTER COLUMN id SET DEFAULT nextval('public.ticket_categories_id_seq'::regclass);


--
-- Name: ticket_messages id; Type: DEFAULT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.ticket_messages ALTER COLUMN id SET DEFAULT nextval('public.ticket_messages_id_seq'::regclass);


--
-- Name: ticket_panel_categories id; Type: DEFAULT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.ticket_panel_categories ALTER COLUMN id SET DEFAULT nextval('public.ticket_panel_categories_id_seq'::regclass);


--
-- Name: ticket_panel_settings id; Type: DEFAULT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.ticket_panel_settings ALTER COLUMN id SET DEFAULT nextval('public.ticket_panel_settings_id_seq'::regclass);


--
-- Name: ticket_resolutions id; Type: DEFAULT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.ticket_resolutions ALTER COLUMN id SET DEFAULT nextval('public.ticket_resolutions_id_seq'::regclass);


--
-- Name: tickets id; Type: DEFAULT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.tickets ALTER COLUMN id SET DEFAULT nextval('public.tickets_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: webhook_configurations id; Type: DEFAULT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.webhook_configurations ALTER COLUMN id SET DEFAULT nextval('public.webhook_configurations_id_seq'::regclass);


--
-- Name: webhook_event_log id; Type: DEFAULT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.webhook_event_log ALTER COLUMN id SET DEFAULT nextval('public.webhook_event_log_id_seq'::regclass);


--
-- Data for Name: bot_settings; Type: TABLE DATA; Schema: public; Owner: ticketbot
--

COPY public.bot_settings (id, server_id, bot_name, bot_nickname, bot_prefix, welcome_message, notifications_enabled, admin_role_id, support_role_id, auto_close_enabled, auto_close_hours, default_priority, debug_mode, log_channel_id, ticket_channel_id, dashboard_url, admin_channel_id, public_log_channel_id, admin_notifications_enabled, send_copy_to_admin_channel, thread_integration_enabled, thread_channel_id, thread_auto_create, thread_bidirectional_sync, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: developer_audit_log; Type: TABLE DATA; Schema: public; Owner: ticketbot
--

COPY public.developer_audit_log (id, developer_id, action, metadata, ip_address, user_agent, created_at) FROM stdin;
\.


--
-- Data for Name: developers; Type: TABLE DATA; Schema: public; Owner: ticketbot
--

COPY public.developers (id, discord_id, username, added_by, added_at, is_active) FROM stdin;
\.


--
-- Data for Name: discord_users; Type: TABLE DATA; Schema: public; Owner: ticketbot
--

COPY public.discord_users (id, username, discriminator, avatar, is_admin, server_id, onboarding_completed, first_login_at, last_seen_at, admin_guilds, connected_servers) FROM stdin;
368610753885896705	scarletredjoker	0	fbd290e9b8de5a7a9dd884fadf4c2cba	t	\N	t	2025-12-07 11:30:52.600229	2025-12-07 11:30:52.607	[{"id":"580136949042642965","name":"GumGumDabber's Hangout","icon":"52c8b513d4d07fa18078f06030b6828d","owner":false},{"id":"623281252451221515","name":"Joker's Evil Headquarters","icon":"4dbd75def87f71c642ddf6e0b00a6df4","owner":true},{"id":"692850100795473920","name":"Rig City","icon":"71c2883f332d45713907a4c81bc76572","owner":false},{"id":"714669653799993384","name":"The Bebop","icon":"a_631685ceb2a5e1051325f62cceb65723","owner":false},{"id":"756968466455461900","name":"Michigan dabbin's server","icon":"a8b11312466ee692ec3ebe54ae78d85d","owner":false},{"id":"756991798425026630","name":"Big Pusher Keys","icon":null,"owner":false},{"id":"848196877224771595","name":"OGHempRollers","icon":"818a72dcea960f4765849e68222c2b55","owner":false},{"id":"986995994791133224","name":"Mayo Monkeys","icon":"e72ee8619a54a0167ef7563b8a66404e","owner":false},{"id":"1094297748699889876","name":"Test svr","icon":null,"owner":true},{"id":"1205561598161457224","name":"Liquor & Legos","icon":"aa6105af11d8467d3dd43094c3210767","owner":false},{"id":"1277815656963637328","name":"Ambyr & Evin's Wedding","icon":"3a9dfa7e3158006e68ef7b583a5f35bc","owner":true},{"id":"1325638742232268831","name":"RigCityAutoClub","icon":"d4363ed4839aa908913be5d1376dd017","owner":false}]	["623281252451221515","692850100795473920"]
\.


--
-- Data for Name: escalation_history; Type: TABLE DATA; Schema: public; Owner: ticketbot
--

COPY public.escalation_history (id, ticket_id, server_id, rule_id, from_level, to_level, reason, triggered_by, previous_assignee_id, new_assignee_id, notification_sent, message_id, created_at) FROM stdin;
\.


--
-- Data for Name: escalation_rules; Type: TABLE DATA; Schema: public; Owner: ticketbot
--

COPY public.escalation_rules (id, server_id, name, description, trigger_type, trigger_value, escalation_level, target_role_id, notify_channel_id, priority, is_enabled, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: guild_provisioning_status; Type: TABLE DATA; Schema: public; Owner: ticketbot
--

COPY public.guild_provisioning_status (id, server_id, provisioning_started_at, provisioning_completed_at, categories_created, settings_created, welcome_sent, ticket_category_channel_id, support_channel_id, log_channel_id, status, error_message, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: interaction_locks; Type: TABLE DATA; Schema: public; Owner: ticketbot
--

COPY public.interaction_locks (interaction_id, user_id, action_type, created_at) FROM stdin;
\.


--
-- Data for Name: panel_template_buttons; Type: TABLE DATA; Schema: public; Owner: ticketbot
--

COPY public.panel_template_buttons (id, template_id, custom_id, label, emoji, button_style, url, action_type, action_data, "row", "position", is_enabled, requires_role, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: panel_template_fields; Type: TABLE DATA; Schema: public; Owner: ticketbot
--

COPY public.panel_template_fields (id, template_id, name, value, inline, sort_order, is_enabled, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: panel_templates; Type: TABLE DATA; Schema: public; Owner: ticketbot
--

COPY public.panel_templates (id, server_id, name, description, type, embed_title, embed_description, embed_color, embed_url, author_name, author_icon_url, author_url, thumbnail_url, image_url, footer_text, footer_icon_url, show_timestamp, is_enabled, is_ticket_panel, last_used, use_count, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: server_role_permissions; Type: TABLE DATA; Schema: public; Owner: ticketbot
--

COPY public.server_role_permissions (id, server_id, role_id, role_name, can_view_tickets, can_manage_tickets, can_delete_tickets, can_manage_settings, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: servers; Type: TABLE DATA; Schema: public; Owner: ticketbot
--

COPY public.servers (id, name, icon, owner_id, admin_role_id, support_role_id, is_active) FROM stdin;
\.


--
-- Data for Name: sla_configurations; Type: TABLE DATA; Schema: public; Owner: ticketbot
--

COPY public.sla_configurations (id, server_id, priority, response_time_minutes, resolution_time_minutes, escalation_time_minutes, notify_on_breach, notify_channel_id, is_enabled, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sla_tracking; Type: TABLE DATA; Schema: public; Owner: ticketbot
--

COPY public.sla_tracking (id, ticket_id, server_id, sla_config_id, response_deadline, resolution_deadline, first_responded_at, response_breached, resolution_breached, breach_notified_at, escalated_at, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: stream_notification_log; Type: TABLE DATA; Schema: public; Owner: ticketbot
--

COPY public.stream_notification_log (id, server_id, user_id, stream_title, stream_url, platform, message_id, notified_at) FROM stdin;
\.


--
-- Data for Name: stream_notification_settings; Type: TABLE DATA; Schema: public; Owner: ticketbot
--

COPY public.stream_notification_settings (id, server_id, notification_channel_id, is_enabled, mention_role, custom_message, auto_detect_enabled, auto_sync_interval_minutes, last_auto_sync_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: stream_tracked_users; Type: TABLE DATA; Schema: public; Owner: ticketbot
--

COPY public.stream_tracked_users (id, server_id, user_id, username, is_active, last_notified_at, auto_detected, connected_platforms, platform_usernames, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: thread_mappings; Type: TABLE DATA; Schema: public; Owner: ticketbot
--

COPY public.thread_mappings (id, server_id, thread_id, ticket_id, channel_id, status, sync_enabled, last_synced_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ticket_audit_log; Type: TABLE DATA; Schema: public; Owner: ticketbot
--

COPY public.ticket_audit_log (id, ticket_id, action, performed_by, performed_by_username, details, created_at, server_id) FROM stdin;
\.


--
-- Data for Name: ticket_categories; Type: TABLE DATA; Schema: public; Owner: ticketbot
--

COPY public.ticket_categories (id, name, emoji, color, server_id) FROM stdin;
\.


--
-- Data for Name: ticket_messages; Type: TABLE DATA; Schema: public; Owner: ticketbot
--

COPY public.ticket_messages (id, ticket_id, sender_id, content, sender_username, created_at) FROM stdin;
\.


--
-- Data for Name: ticket_panel_categories; Type: TABLE DATA; Schema: public; Owner: ticketbot
--

COPY public.ticket_panel_categories (id, server_id, ticket_category_id, name, description, emoji, button_style, is_enabled, sort_order, custom_id, requires_role, welcome_message, assign_to_role, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ticket_panel_settings; Type: TABLE DATA; Schema: public; Owner: ticketbot
--

COPY public.ticket_panel_settings (id, server_id, title, description, embed_color, footer_text, show_timestamp, thumbnail_url, author_name, author_icon_url, buttons_per_row, show_categories_in_description, max_categories, is_enabled, require_reason, cooldown_minutes, created_at, updated_at) FROM stdin;
2	623281252451221515	🎫 Support Ticket System	**Welcome to our support ticket system!**\n\nClick one of the buttons below to create a new support ticket. Our team will respond as quickly as possible.\n\n*Please provide as much detail as possible when creating your ticket to help us assist you better.*	#5865F2	Click a button below to get started • Support Team	t	\N	\N	\N	2	t	25	t	t	0	2025-12-07 11:31:04.65	2025-12-07 11:31:04.65
\.


--
-- Data for Name: ticket_resolutions; Type: TABLE DATA; Schema: public; Owner: ticketbot
--

COPY public.ticket_resolutions (id, ticket_id, resolution_type, resolution_notes, action_taken, resolved_by, resolved_by_username, resolved_at, server_id) FROM stdin;
\.


--
-- Data for Name: tickets; Type: TABLE DATA; Schema: public; Owner: ticketbot
--

COPY public.tickets (id, discord_id, title, description, status, priority, category_id, creator_id, assignee_id, server_id, mediation_actions, user_actions, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: ticketbot
--

COPY public.users (id, username, password) FROM stdin;
\.


--
-- Data for Name: webhook_configurations; Type: TABLE DATA; Schema: public; Owner: ticketbot
--

COPY public.webhook_configurations (id, server_id, name, description, webhook_url, webhook_secret, event_types, target_channel_id, is_inbound, is_enabled, last_triggered_at, failure_count, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: webhook_event_log; Type: TABLE DATA; Schema: public; Owner: ticketbot
--

COPY public.webhook_event_log (id, webhook_id, server_id, event_type, payload, direction, status_code, response, success, error_message, processed_at) FROM stdin;
\.


--
-- Name: bot_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ticketbot
--

SELECT pg_catalog.setval('public.bot_settings_id_seq', 1, false);


--
-- Name: developer_audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ticketbot
--

SELECT pg_catalog.setval('public.developer_audit_log_id_seq', 1, false);


--
-- Name: developers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ticketbot
--

SELECT pg_catalog.setval('public.developers_id_seq', 1, false);


--
-- Name: escalation_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ticketbot
--

SELECT pg_catalog.setval('public.escalation_history_id_seq', 1, false);


--
-- Name: escalation_rules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ticketbot
--

SELECT pg_catalog.setval('public.escalation_rules_id_seq', 1, false);


--
-- Name: guild_provisioning_status_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ticketbot
--

SELECT pg_catalog.setval('public.guild_provisioning_status_id_seq', 1, false);


--
-- Name: panel_template_buttons_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ticketbot
--

SELECT pg_catalog.setval('public.panel_template_buttons_id_seq', 1, false);


--
-- Name: panel_template_fields_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ticketbot
--

SELECT pg_catalog.setval('public.panel_template_fields_id_seq', 1, false);


--
-- Name: panel_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ticketbot
--

SELECT pg_catalog.setval('public.panel_templates_id_seq', 1, false);


--
-- Name: server_role_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ticketbot
--

SELECT pg_catalog.setval('public.server_role_permissions_id_seq', 1, false);


--
-- Name: sla_configurations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ticketbot
--

SELECT pg_catalog.setval('public.sla_configurations_id_seq', 1, false);


--
-- Name: sla_tracking_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ticketbot
--

SELECT pg_catalog.setval('public.sla_tracking_id_seq', 1, false);


--
-- Name: stream_notification_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ticketbot
--

SELECT pg_catalog.setval('public.stream_notification_log_id_seq', 1, false);


--
-- Name: stream_notification_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ticketbot
--

SELECT pg_catalog.setval('public.stream_notification_settings_id_seq', 1, false);


--
-- Name: stream_tracked_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ticketbot
--

SELECT pg_catalog.setval('public.stream_tracked_users_id_seq', 1, false);


--
-- Name: thread_mappings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ticketbot
--

SELECT pg_catalog.setval('public.thread_mappings_id_seq', 1, false);


--
-- Name: ticket_audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ticketbot
--

SELECT pg_catalog.setval('public.ticket_audit_log_id_seq', 1, false);


--
-- Name: ticket_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ticketbot
--

SELECT pg_catalog.setval('public.ticket_categories_id_seq', 1, false);


--
-- Name: ticket_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ticketbot
--

SELECT pg_catalog.setval('public.ticket_messages_id_seq', 1, false);


--
-- Name: ticket_panel_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ticketbot
--

SELECT pg_catalog.setval('public.ticket_panel_categories_id_seq', 1, false);


--
-- Name: ticket_panel_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ticketbot
--

SELECT pg_catalog.setval('public.ticket_panel_settings_id_seq', 2, true);


--
-- Name: ticket_resolutions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ticketbot
--

SELECT pg_catalog.setval('public.ticket_resolutions_id_seq', 1, false);


--
-- Name: tickets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ticketbot
--

SELECT pg_catalog.setval('public.tickets_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ticketbot
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: webhook_configurations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ticketbot
--

SELECT pg_catalog.setval('public.webhook_configurations_id_seq', 1, false);


--
-- Name: webhook_event_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ticketbot
--

SELECT pg_catalog.setval('public.webhook_event_log_id_seq', 1, false);


--
-- Name: bot_settings bot_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.bot_settings
    ADD CONSTRAINT bot_settings_pkey PRIMARY KEY (id);


--
-- Name: bot_settings bot_settings_server_id_unique; Type: CONSTRAINT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.bot_settings
    ADD CONSTRAINT bot_settings_server_id_unique UNIQUE (server_id);


--
-- Name: developer_audit_log developer_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.developer_audit_log
    ADD CONSTRAINT developer_audit_log_pkey PRIMARY KEY (id);


--
-- Name: developers developers_discord_id_unique; Type: CONSTRAINT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.developers
    ADD CONSTRAINT developers_discord_id_unique UNIQUE (discord_id);


--
-- Name: developers developers_pkey; Type: CONSTRAINT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.developers
    ADD CONSTRAINT developers_pkey PRIMARY KEY (id);


--
-- Name: discord_users discord_users_pkey; Type: CONSTRAINT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.discord_users
    ADD CONSTRAINT discord_users_pkey PRIMARY KEY (id);


--
-- Name: escalation_history escalation_history_pkey; Type: CONSTRAINT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.escalation_history
    ADD CONSTRAINT escalation_history_pkey PRIMARY KEY (id);


--
-- Name: escalation_rules escalation_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.escalation_rules
    ADD CONSTRAINT escalation_rules_pkey PRIMARY KEY (id);


--
-- Name: guild_provisioning_status guild_provisioning_status_pkey; Type: CONSTRAINT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.guild_provisioning_status
    ADD CONSTRAINT guild_provisioning_status_pkey PRIMARY KEY (id);


--
-- Name: guild_provisioning_status guild_provisioning_status_server_id_unique; Type: CONSTRAINT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.guild_provisioning_status
    ADD CONSTRAINT guild_provisioning_status_server_id_unique UNIQUE (server_id);


--
-- Name: interaction_locks interaction_locks_pkey; Type: CONSTRAINT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.interaction_locks
    ADD CONSTRAINT interaction_locks_pkey PRIMARY KEY (interaction_id);


--
-- Name: panel_template_buttons panel_template_buttons_pkey; Type: CONSTRAINT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.panel_template_buttons
    ADD CONSTRAINT panel_template_buttons_pkey PRIMARY KEY (id);


--
-- Name: panel_template_fields panel_template_fields_pkey; Type: CONSTRAINT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.panel_template_fields
    ADD CONSTRAINT panel_template_fields_pkey PRIMARY KEY (id);


--
-- Name: panel_templates panel_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.panel_templates
    ADD CONSTRAINT panel_templates_pkey PRIMARY KEY (id);


--
-- Name: server_role_permissions server_role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.server_role_permissions
    ADD CONSTRAINT server_role_permissions_pkey PRIMARY KEY (id);


--
-- Name: servers servers_pkey; Type: CONSTRAINT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.servers
    ADD CONSTRAINT servers_pkey PRIMARY KEY (id);


--
-- Name: sla_configurations sla_configurations_pkey; Type: CONSTRAINT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.sla_configurations
    ADD CONSTRAINT sla_configurations_pkey PRIMARY KEY (id);


--
-- Name: sla_tracking sla_tracking_pkey; Type: CONSTRAINT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.sla_tracking
    ADD CONSTRAINT sla_tracking_pkey PRIMARY KEY (id);


--
-- Name: stream_notification_log stream_notification_log_pkey; Type: CONSTRAINT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.stream_notification_log
    ADD CONSTRAINT stream_notification_log_pkey PRIMARY KEY (id);


--
-- Name: stream_notification_settings stream_notification_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.stream_notification_settings
    ADD CONSTRAINT stream_notification_settings_pkey PRIMARY KEY (id);


--
-- Name: stream_notification_settings stream_notification_settings_server_id_unique; Type: CONSTRAINT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.stream_notification_settings
    ADD CONSTRAINT stream_notification_settings_server_id_unique UNIQUE (server_id);


--
-- Name: stream_tracked_users stream_tracked_users_pkey; Type: CONSTRAINT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.stream_tracked_users
    ADD CONSTRAINT stream_tracked_users_pkey PRIMARY KEY (id);


--
-- Name: thread_mappings thread_mappings_pkey; Type: CONSTRAINT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.thread_mappings
    ADD CONSTRAINT thread_mappings_pkey PRIMARY KEY (id);


--
-- Name: thread_mappings thread_mappings_thread_id_unique; Type: CONSTRAINT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.thread_mappings
    ADD CONSTRAINT thread_mappings_thread_id_unique UNIQUE (thread_id);


--
-- Name: ticket_audit_log ticket_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.ticket_audit_log
    ADD CONSTRAINT ticket_audit_log_pkey PRIMARY KEY (id);


--
-- Name: ticket_categories ticket_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.ticket_categories
    ADD CONSTRAINT ticket_categories_pkey PRIMARY KEY (id);


--
-- Name: ticket_messages ticket_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.ticket_messages
    ADD CONSTRAINT ticket_messages_pkey PRIMARY KEY (id);


--
-- Name: ticket_panel_categories ticket_panel_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.ticket_panel_categories
    ADD CONSTRAINT ticket_panel_categories_pkey PRIMARY KEY (id);


--
-- Name: ticket_panel_settings ticket_panel_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.ticket_panel_settings
    ADD CONSTRAINT ticket_panel_settings_pkey PRIMARY KEY (id);


--
-- Name: ticket_panel_settings ticket_panel_settings_server_id_unique; Type: CONSTRAINT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.ticket_panel_settings
    ADD CONSTRAINT ticket_panel_settings_server_id_unique UNIQUE (server_id);


--
-- Name: ticket_resolutions ticket_resolutions_pkey; Type: CONSTRAINT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.ticket_resolutions
    ADD CONSTRAINT ticket_resolutions_pkey PRIMARY KEY (id);


--
-- Name: tickets tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_unique; Type: CONSTRAINT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_unique UNIQUE (username);


--
-- Name: webhook_configurations webhook_configurations_pkey; Type: CONSTRAINT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.webhook_configurations
    ADD CONSTRAINT webhook_configurations_pkey PRIMARY KEY (id);


--
-- Name: webhook_event_log webhook_event_log_pkey; Type: CONSTRAINT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.webhook_event_log
    ADD CONSTRAINT webhook_event_log_pkey PRIMARY KEY (id);


--
-- Name: escalation_history escalation_history_rule_id_escalation_rules_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.escalation_history
    ADD CONSTRAINT escalation_history_rule_id_escalation_rules_id_fk FOREIGN KEY (rule_id) REFERENCES public.escalation_rules(id);


--
-- Name: escalation_history escalation_history_ticket_id_tickets_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.escalation_history
    ADD CONSTRAINT escalation_history_ticket_id_tickets_id_fk FOREIGN KEY (ticket_id) REFERENCES public.tickets(id) ON DELETE CASCADE;


--
-- Name: panel_template_buttons panel_template_buttons_template_id_panel_templates_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.panel_template_buttons
    ADD CONSTRAINT panel_template_buttons_template_id_panel_templates_id_fk FOREIGN KEY (template_id) REFERENCES public.panel_templates(id) ON DELETE CASCADE;


--
-- Name: panel_template_fields panel_template_fields_template_id_panel_templates_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.panel_template_fields
    ADD CONSTRAINT panel_template_fields_template_id_panel_templates_id_fk FOREIGN KEY (template_id) REFERENCES public.panel_templates(id) ON DELETE CASCADE;


--
-- Name: sla_tracking sla_tracking_sla_config_id_sla_configurations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.sla_tracking
    ADD CONSTRAINT sla_tracking_sla_config_id_sla_configurations_id_fk FOREIGN KEY (sla_config_id) REFERENCES public.sla_configurations(id);


--
-- Name: sla_tracking sla_tracking_ticket_id_tickets_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.sla_tracking
    ADD CONSTRAINT sla_tracking_ticket_id_tickets_id_fk FOREIGN KEY (ticket_id) REFERENCES public.tickets(id) ON DELETE CASCADE;


--
-- Name: thread_mappings thread_mappings_ticket_id_tickets_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.thread_mappings
    ADD CONSTRAINT thread_mappings_ticket_id_tickets_id_fk FOREIGN KEY (ticket_id) REFERENCES public.tickets(id) ON DELETE CASCADE;


--
-- Name: ticket_panel_categories ticket_panel_categories_ticket_category_id_ticket_categories_id; Type: FK CONSTRAINT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.ticket_panel_categories
    ADD CONSTRAINT ticket_panel_categories_ticket_category_id_ticket_categories_id FOREIGN KEY (ticket_category_id) REFERENCES public.ticket_categories(id);


--
-- Name: webhook_event_log webhook_event_log_webhook_id_webhook_configurations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: ticketbot
--

ALTER TABLE ONLY public.webhook_event_log
    ADD CONSTRAINT webhook_event_log_webhook_id_webhook_configurations_id_fk FOREIGN KEY (webhook_id) REFERENCES public.webhook_configurations(id);


--
-- PostgreSQL database dump complete
--

\unrestrict dzwbFdPpMF2rmYeQb77GAS4bhAqLyocEHuDLnBfctzefdtmugsX2jIsL0O9ykqX

--
-- PostgreSQL database cluster dump complete
--

